# Kanban Dispatch Protocol

How the **lead** session of Kanban Mode moves a card across the board: what admits work, who is told to do it, how completion is judged, and when the operator is asked to `/clear`.

> **Loading scope**: Intentionally always-loaded. A session learns it is the kanban lead from the SessionStart context, not from a file path, so a `paths:`-restricted rule would never reach it.

> **Detail companion**: `kanban-dispatch-detail.md` owns the long tables, dispatch-cycle walkthrough, incident narratives, and rationale — now also per-card fan-out, Factory in-lane 3-stage, and the `manager-lead` working mode. The stub keeps every [HARD] rule and pointer; load the companion when moving or classifying a card, or choosing review lenses.

> **Mechanics companion**: `kanban-dispatch-mechanics.md` owns the board-and-lens bodies relocated from this file — § The board (the five fixed columns and their owning roles) · § The dispatch cycle walkthrough · § Review lens selection (`--deep --patch` is opt-in twice over, and is never added on the lead's own initiative) · § Serializing a heavy run across lanes (`moai slot` lease) · § Factory Mode mechanics · § Boundaries · § Cross-references. Load it when moving or classifying a card, choosing review lenses, or serializing a heavy run.

## Scope — when this rule is live

This rule binds a session whose SessionStart context declares **Kanban Mode** with the `lead` role. In every other session it is inert: a companion session (`plan` / `run` / `sync`) receives instructions, it does not dispatch them, and a session outside Kanban Mode has no board to move.

Kanban Mode is entered with `moai cc -k` (or `moai glm -k`), which elects one lead and prints one launch command per companion role. Companion sessions are launched **by hand, one per terminal** — a session cannot launch another, and no peer-spawning mechanism exists or is wanted.

The lead session works through the `manager-lead` agent: it holds the operator dialogue (the session's `AskUserQuestion` stays the user channel) while dispatching parallel work in the background — neither blocks the other. Lead and lane sessions orchestrate only; real work runs in sub-agents (design intent + spawn rules: `kanban-dispatch-detail.md` § Design intent, § The lead works through manager-lead).

One boundary: nudge delivery rides on cross-session messaging, absent on native Windows and off under some providers, versions, and flags (`cross-session-messaging.md` § Availability constraints) — an absent channel fails quietly; the lead surfaces it, and the queue keeps working without it.

## Entry into the board is an operator act

`backlog` has no owning session, so a lead admitting cards on its own initiative would be **generating** work rather than scheduling it. Every card's origin is the operator's request.

[HARD] **The lead is the queue's sole producer.** The operator asks; the lead turns the request into a card with `moai gtd add "<description>"` (`moai gtd` alone lists the queue). Production is the one queue mutation the lead performs on its own authority — translation, not invention: nothing enters the queue the operator did not ask for.

[HARD] **Standing sources are the other producers, and they produce on the operator's prior authorization.** `/moai project` issues one card when it completes, prefixed `[PROJECT] `; the codemaps-debt trigger in `moai integration release` issues one card per debt period, prefixed `[GRAPH] `. Neither is the lead admitting a card on its own initiative: the operator authorized each source in advance, and each derives its card from what it already measured or was already told rather than inventing work. The full conditions — one per occasion, derived not invented, marked, id reported, starting still a separate pick — are the SSOT at `.claude/skills/moai/workflows/gtd.md` § Standing sources, and that set is **conditional, not closed**: a workflow becomes a standing source by meeting all five, never by resembling one that already did. Nothing else produces; a report milestone, an audit finding, or an open issue still reaches the queue only as a card request the operator approves.

[HARD] **Promotion is the operator's act, always.** After a `/clear`, the lead presents the queued cards through `AskUserQuestion` and the operator picks; only then does the lead dispatch according to the card class: Class A direct close, Class B `run`, Class C `plan`. The lead never picks for the operator, never reorders by inferred priority, and never silently promotes a backlog item. An empty queue is a state to report, not a prompt to invent work.

A card the operator chose to start when it was issued is not a silent promotion: that answer IS the promotion, given explicitly before anything moved, and the same class-based entry follows. What stays forbidden is unchanged — promoting because a card looks ready, because the queue holds only one, or because no answer came back.

[HARD] **The lead may attach a finding; it may not act on one.** Analysis runs automatically and records a relation between two cards — a near-duplicate the machine measured on `add` or `analyze`, or a `contains` / `absorbs` / `replaces` / `conflicts` the lead judged and wrote with `moai gtd relate`. The record is evidence the operator reads, never a mandate: the lead never folds the related card away, never reorders the queue around it, and never drops or edits it. Analysis changes exactly one thing on its own authority — it refuses the admission of a card whose normalized text is identical to one already queued or picked, which creates no card and leaves the queue file byte-identical. Everything a finding suggests beyond that refusal is the operator's act.

[HARD] **The pre-dispatch PR cross-check.** Before dispatching a card out of `backlog`, the lead reads that card's pull-request and landed state and reports what it read in the same turn. `moai gtd pr <id>` answers both; by hand it is `gh pr list` plus a `git log` against the integration branch. An unchecked card is a gap, not a clean card (§ Completion is read, never trusted).

[HARD] **The cross-check also asks whether a completed SPEC already covers the work.** A card id answers "did THIS card land"; it cannot answer "has someone else already done this", because the delivering commit carries the OTHER card's id — so an id-keyed read returns a correct `no-link` for work that is finished. Where the card names an issue or a subsystem, the lead also reads whether a SPEC covering it is already `completed` and reports that alongside the PR and landed state. Neither read is conclusive: the final discriminator stays reproduction (§ Completion is read, never trusted).

[HARD] **The cross-check reports; it never vetoes.** Where the card carries an open pull request or is already landed, the lead surfaces that and the operator **confirms or withdraws** it. The lead never withholds a picked card on its own authority — promotion is the operator's act, always. Why the wording is the only available control, and the incident it closes: `kanban-dispatch-detail.md` § The pre-dispatch cross-check.

## Report milestones ↔ queue cards

[HARD] **A milestone-bearing report under `.moai/reports/` carries a `## Card Cross-Check` section** — one table row per milestone, a `card` column holding the delivering card id or an explicit new-card marker. A mapping claim is verified against the queue (`moai gtd`), never remembered. Before the lead turns a report into card requests, the request message states the full comparison — `N milestones → N cards` — naming every milestone with no card in the live queue. Detail: `kanban-dispatch-detail.md` § Report milestones ↔ queue cards.

## Card classes — not every card needs every column

The lead classifies each card as it leaves `backlog` and names the class in the dispatch: **A — direct close** (one file, one line, no design judgement, CI catches the regression; one session carries the card to a pull request, `plan` skipped), **B — defect, cause unknown** (`run → sync`; `plan` is skipped, so no SPEC exists), **C — design change** (a decision, or spans subsystems; all three working columns). Full table and rationale: `kanban-dispatch-detail.md` § Card classes.

[HARD] **Class A is admitted on checked evidence, not on an assertion.** Two of its three properties are mechanically checkable, and are checked and cited: the diff is measured (`git diff --stat` against the base, showing the one file) and CI is green **on the head that will merge**. The third — no design judgement in it — is a judgement, stated in the dispatch where the operator can disagree with it. A card that cannot cite both measurements is not Class A.

The justification is never "it is faster" — speed is the effect of skipping the columns, not the reason; a card justified by speed alone is a Class C card being rushed.

**Class B skips `plan`, not the sync gate's review** — an unestablished cause is precisely what a review catches. The `run` session owns the investigation and the fix; before the card leaves `run` the cause-establishing evidence (the reproducing command and what it printed) goes into the card's progress record, and the completion report names that path so the lead reads the cause rather than trusting it.

**Work in progress: one card per worktree — two cards sharing a worktree run serially whatever columns they sit in, because they share a working tree and a branch.** A lane holding several cards in one column does it by per-card fan-out: parallel `Agent()` workers whose writes each stay inside their own card directory (`kanban-dispatch-detail.md` § Per-card fan-out; parallelism per class: § Card classes).

## The dispatch cycle

### The delegation channel is the queue

[HARD] Work is delegated through the queue on disk, not through messages. The queue file resolves against the primary checkout from every linked worktree — one repository, one queue — so a card admitted from anywhere is visible everywhere, and that single-file visibility is what makes the queue a channel rather than a shared opinion.

A cross-session message is a nudge, never the delegation itself: delivery is not guaranteed, and a delivered message consumes the recipient's quota like a typed prompt. No dispatch depends on a message arriving. The disk record — card admitted, picked, done — moves the board; an unanswered message changes nothing.

Two properties of that nudge channel bear on dispatch. **A lane can be asked to report when it next goes idle** (`SendMessage` `notify_when_idle`, opt-in and one-shot), which spares the lead a polling loop — but [HARD] the notice is not the completion signal. A lane goes idle when it finishes, when it stops at a permission prompt, and when it dies; the notice cannot separate those, so it tells the lead *when to read the evidence* and nothing about what the evidence says — a scheduling hint (`cross-session-messaging.md` § An idle notice is a scheduling hint). The card still advances on the evidence, per § Completion is read, never trusted. **And a nudge can be refused outright under fan-out**: nudging every lane inside one turn is a rapid burst, and the runtime refuses past the inbox's capacity rather than dropping silently (`cross-session-messaging.md` § Configuration surface). Read the send result; a refusal costs the board nothing, because the queue already carries the delegation.

### Dispatch language

[HARD] A dispatch is written in the operator's `conversation_language` — the operator watches it scroll past, which makes it user-facing output rather than internal agent traffic. The boundary is **who reads it**: an `Agent()` subagent prompt reaches no human and stays English. (Why this classifies rather than exempts: `kanban-dispatch-detail.md` § Dispatch language.)

What stays verbatim in every language: SPEC IDs, command names and their flags, file paths, session names, and technical identifiers. They are addresses rather than prose; a translated address does not resolve.

### Dispatch format

[HARD] A dispatch is a fixed-field address block, not prose. The fields:

```
card: <id>
spec: <SPEC-ID>
cmd: /moai run <SPEC-ID>
wt: .claude/worktrees/<name>
evidence: .moai/specs/<SPEC-ID>/progress.md
lens: --security --deep
```

- `card`, `cmd`, `wt`, and `evidence` are always present. `spec` joins once a SPEC exists; a Class B card, which skips `plan`, carries none, and its `evidence` names whatever record the lead will read instead. `lens` appears only in a `sync` dispatch — the review lenses the sync gate will run, the choice itself stated as an address rather than a sentence.
- `wt` names the new card's worktree, never a previous card's tree; where the lane may still be anchored elsewhere, it carries the exit-first instruction (`ExitWorktree` → `EnterWorktree(<card-id>)` → `git branch -m WT-<slug>`). The tree keeps the card id; the branch takes a descriptive slug — see the naming rule below.
- **No explanatory prose.** Procedure, background, and justification live in the card text and the SPEC artifacts the block points at; a dispatch that restates them makes the operator read the same thing twice. What does not fit a field belongs in the card, not around the block.
- **Ceiling: the block is at most 10 lines.** A dispatch that does not fit is trying to be a handoff; move the payload into the card and send the block.
- **[HARD] The send is read, not assumed.** The result has three shapes and only one of them delivered:
  a `routing` object means an in-process mailbox took the block and it is lost (re-send to `name [ref]`);
  a following `[Cross-session delivery notice]` means the lane's permission policy is holding the block for
  its operator or refused it (surface it — re-sending hits the same policy); anything else queued it.
  None of the three establishes that the lane's Claude read it, and a Remote Control or cloud lane reports
  nothing at all. The card still advances on evidence, never on a send result. Conditional:
  `cross-session-messaging.md` § A send result has three shapes.

## Deputy dispatch surface

[HARD] **The deputy is resident, not optional.** Before the batch's first lane dispatch, the `-k`/`-f` lead session spawns exactly one UNNAMED background `Agent()` running manager-lead as its **coordination deputy** and keeps it for the batch. Its delegable/retained matrix lives in the agent itself (`manager-lead.md` § Deputy dispatch surface); this stub carries only the boundary that binds the board.

[HARD] **A completion report reaches the lead as a `RECOMMEND:` summary, not as raw reading batches** — the deputy does the raw-tree read and names the paths it read. Turn occupancy moves; the lead's own evidence-read before advancing a card does not (§ Completion is read, never trusted).

[HARD] **Round-report measurement and drafting are the deputy's; the asserted figures are the lead's** — every figure names its measurer, and an unattributed one is a defect. The report is per-round files plus an index, each round touching only its own file and the index.

[HARD] **The deputy never holds a power of consequence.** Final PASS/FAIL verdicts, final merge approval (`LEAD-MERGE-APPROVED`), operator gates, card issuance and `done` (`moai gtd` mutations), CodeRabbit slot-wait adjudication, and cross-session dispute coordination stay with the lead session. A deputy recommendation (`RECOMMEND:`-prefixed) is never a verdict; a delegation requesting a retained act is refused and returned as a blocker report.

[HARD] **Nothing structural moves with the delegation.** The queue stays the channel, completion stays evidence the lead read, and the verdict's home stays the lead. The deputy reads and reports; the lead decides.

Background work, what returns to the lead's turn, the idle-notice request replacing a polling loop, and the delivery-shape verification: `kanban-dispatch-detail.md` § The lead works through manager-lead.

## Completion is read, never trusted

[HARD] The lead advances a card on **evidence it read**, not on a companion's reply. Reply routing is not guaranteed to arrive, and a reply is a claim rather than an observation.

Before moving a card out of a working column, the lead reads the card's `progress.md` and the verification evidence path the phase declares, and confirms the phase closed. A missing, unreadable, or stale evidence file is a **gap** — the card stays put and the lead reports why; absence of a failure signal is not a pass. The same applies to the operator: a report that a column advanced names what was read.

Where the phase's declared evidence includes an audit verdict, the lead reads the verdict **file** under `.moai/reports/<card-id>/` per `.moai/docs/audit-artifact-convention.md`. An absent, unreadable, or uncommitted verdict file is a gap exactly like a missing progress record.

**The final PASS/FAIL verdict is the lead's**, read from the evidence on disk and never delegated to the lane that produced the work — the executor judging its own output is the failure shape this section prevents. Why the division is structural: `kanban-dispatch-detail.md` § The verdict's home.

### CodeRabbit is not read from `gh pr checks`

[HARD] A `gh pr checks` row naming CodeRabbit is not evidence that a review happened: the status is `success` **even when no review ran**, and the row prints `pass` byte-identically in both cases — only the description separates reviewed from unreviewed. A row counts only when BOTH hold:

1. The **combined** endpoint `/commits/{sha}/status` shows `state == "success"` **and** description `Review completed`:

    ```bash
    gh api "repos/$REPO/commits/$HEAD_SHA/status" \
      --jq '.statuses[] | select(.context == "CodeRabbit" and .state == "success") | .description'
    ```

2. A `Merge Risk:` line exists whose `` up to `<prefix>` `` matches the current `headRefOid`.

Anything else is a gap, not a pass. `Review rate limited` means the review never started, and a card carrying it does not leave `sync`. (Endpoint choice, and why branch protection is not the lever: `kanban-dispatch-detail.md` § CodeRabbit endpoint measurement.)

## The `/clear` handoff between phases

[HARD] A companion session does not carry one card's context into the next card. When a phase completes and the lead has read its evidence, the lead **asks the operator to `/clear` that session** — `/clear` is a user-typed command and cannot be sent as an instruction. The lead's message states, in order: what closed (card, phase, evidence read), which session to `/clear` (by name), and what happens next (the next column, and which session is instructed once the clear is done).

Where the next phase reuses a just-cleared session, the lead re-sends the full pointer instruction rather than assuming the session remembers.

The lead's own session is cleared the same way, between cards rather than phases: once a card reaches `done`, the operator is asked to `/clear` the lead session, and the next turn presents the queue again.

## Isolation is provisioned by MoAI, then entered through a launcher

[HARD] A card's work happens inside a worktree, and that worktree is **entered through the launcher** — never created with a bare `git worktree add`.

| Need | Form |
|---|---|
| Create a harness-neutral L1 worktree | `moai worktree new <name>` |
| Start a Claude Code session in the tree | `moai cc -w <name>` (`--spawn` for a new window) |
| Re-enter or leave in the current Claude Code session | `EnterWorktree(<path>)` / `ExitWorktree` |
| Start a Codex app chat in a new tree | Select Worktree and the starting branch in the new chat |
| Start a Codex CLI session in an existing tree | `moai codex -w <name>`; the flag never creates a tree |
| Work in a tree from the current Codex session | `git -C <absolute-worktree-path>` and direct file operations there |
| Dispose it once the card's work has merged on the remote | L2 tree (`~/.moai/worktrees/…`) only: `moai worktree done`. An L1 tree (`.claude/worktrees/…`) is disposed via the session-end keep/remove prompt — `moai worktree` never registers it |

`moai worktree new <name>` is the harness-neutral L1 creation verb — it materializes a tree without entering it. A Codex factory lane uses it for each card, then launches the interactive card session with `codex -C <absolute-worktree-path>`; it does not use `moai codex -w` to create the tree. The Codex app's Worktree selector creates a Codex-managed tree separately. A raw `git worktree add` bypasses MoAI's name validation, base selection, and post-create Git configuration.

[HARD] A Codex factory agent must never call `moai cc -w`, `EnterWorktree`, or `ExitWorktree`; those are Claude Code entry mechanisms. `moai codex -w` starts another Codex process and only accepts an existing tree, so an agent already running in Codex works through its current session instead of nesting a launcher.

[HARD] **`moai worktree done` closes L2 trees only.** A worktree entered by short name (`moai cc -w <name>` → `.claude/worktrees/<name>/`) is L1 and is never in `moai worktree`'s registry — `done` on it is a category error, not a disposal. L1 disposal is the session-end keep/remove prompt, or `git worktree unlock` + `git worktree remove` once the session is done. The full L1/L2 boundary lives in `worktree-integration.md` § Terminology Glossary.

[HARD] **The card's branch is unpushed, so its worktree is the work's only instance.** Dispose of no worktree — L1 or L2 — until the lead has integrated the branch and the remote merge has landed; disposal before that destroys the only copy.

[HARD] **A new card starts in a new worktree.** A Claude Code lane anchored in the previous card's tree MUST `ExitWorktree` before entering the next one. A Codex factory lane ends the previous interactive card session and the launcher starts the next one with `codex -C <new-tree>`; the agent does not call Claude's entry tools. The fresh tree is created from the configured base rather than reused — reuse carries the old card's context and untracked artifacts into the new card. Where the new card depends on a prior card's unmerged code, merge the prior branch inside the new worktree; a dependency is a reason to merge, never to reuse the tree.

[HARD] **Card worktree branches carry the `WT-` prefix and a descriptive slug — never the card id.** `EnterWorktree(<name>)` auto-names its branch `worktree-<name>`, which is unwieldy and invisible to the worktree lifecycle tooling. Immediately after creating a card worktree, rename in place with `git branch -m WT-<slug>`: safe inside a worktree (tree, lock, anchoring unaffected); `moai cc -w <name>` re-entry resolves by tree name, not branch name, and the rename switches the disposal path (`worktree-integration.md` § Terminology Glossary).

The slug says what the card **does**, so a reader of `git branch` or a pull-request list learns the change without a lookup — `WT-t0` says nothing, `WT-branch-naming` says what landed. Its shape:

| Property | Rule |
|---|---|
| Source | The card's title, not its id |
| Tokens | At most 3, hyphen-separated |
| Length | At most 24 characters (the slug alone; `WT-` brings the branch to at most 27) |
| Alphabet | Lowercase `a-z`, `0-9`, and `-` |
| Card id | MUST NOT appear — not as a prefix, a suffix, or a token |

The **worktree directory keeps the card id** (`.claude/worktrees/<card-id>`) — only the branch takes the slug, and the tree path is what the disposal tooling and the evidence path key on.

[HARD] **Dropping the id from the branch moves traceability onto three other carriers, and all three are mandatory.** The branch name no longer answers "which card was this?", so nothing may rely on reading it back:

- The dispatch's `card:` field carries the card id — it is the address, and it is never omitted.
- Every commit on the branch names the card id in its message, so `git log` recovers the card without the branch name.
- The evidence path keeps the card id (`.moai/reports/<card-id>/verdict.md`).

A lane reporting a branch name without its card id has not reported the card. Merges reference the `WT-` name; the lead maps it back through the dispatched `card:` field.

[HARD] **A card-delivering pull request's PR title MUST carry the delivering card id** — and this does not contradict the branch-name rule above: the branch name is read by a human scanning `git branch` and wants a slug; the PR title is read by a machine and wants the id. Traceability therefore rests on **four** carriers rather than the three above — the dispatch `card:` field, the commit message, the evidence path, and the PR title — the only one a resolver can read off the pull-request surface itself, where the dispatch `card:` field (also machine-readable) does not reach.

It binds card-delivering pull requests only — a release, batch, or maintenance PR delivers no card and carries none — and only those opened after it landed; nothing is retitled. Rationale and carrier measurements: `kanban-dispatch-detail.md` § The PR-title carrier.

The lead dispatches this rather than assuming it: each instruction names the worktree and says to drive it with `git -C <path>` rather than `cd` — a `cd` inside a compound command lasts for that invocation only, so the next command silently reads the wrong tree. A companion reporting it worked in the shared checkout is a fault to report (rationale: `kanban-dispatch-detail.md` § Isolation rationale).

[HARD] **Inside a worktree session that `<path>` is the worktree's own absolute path**, and the dispatch writes it that way. Measured on Claude Code 2.1.275: the guard refuses `-C .`, a relative path, a path computed at runtime, and a path outside this worktree — three distinct refusal messages, none of them a runtime defect. Plain git (pipes and `&&` chains included), `git -C <own absolute path>`, and `--git-dir=<own .git>` pass; so does `cd <own worktree> && git …`, which the rule above still advises against for the reason it gives. The refusal is git-scoped: a command carrying no git passes with substitution, loops, redirects, or a heredoc body naming a git command.

## Verification load is lane-local

[HARD] **Lane-local verification is scoped to the card.** A lane runs the tests its own change can affect, then pushes and lets CI run the full suite — the better evidence: the full suite, in a clean environment, against the actual pull-request head. A full-suite run on a loaded developer machine measures the machine, not the code. (Incident record — load 413, orphaned spin loops, the contention↔flakiness loop: `kanban-dispatch-detail.md` § Verification load incident record.)

[HARD] **Never spawn background load.** Where a verification genuinely needs contention, the load must be cleanup-guaranteed — kills registered with the test framework's cleanup hook, or a `timeout` wrapper that bounds the process from outside. A trailing `kill` is not cleanup; it is a line the process may never reach, and every path that ends early leaves the load running.

**A verification recipe that spawns processes is itself a hazard, and gets reviewed as one.** The fault belongs to the dispatcher who wrote and approved the recipe, not to the lane that ran it as given.

### The env-isolated verification form

[HARD] Inside a worktree, an environment-scrubbed verification runs as one compound `unset … && <command>` invocation:

```bash
unset MOAI_KANBAN MOAI_KANBAN_ID MOAI_KANBAN_LABEL MOAI_KANBAN_LEAD_ADDR MOAI_KANBAN_SETTINGS_INJECTED && go test ./...
```

The load-bearing property is **one invocation**: each Bash call is a fresh process, so an `unset` issued as its own call does not carry into the next command — the scrub and the command travel together, or the scrub does nothing. This is a property of the shell, not of any guard, and it is what a "simplification" into two calls silently destroys.

`env -u VAR <command>` scrubs identically and is **not** refused; it is excluded to keep one recipe across lanes, which is a convention rather than a runtime constraint. Do not rewrite the standard form into it, and do not cite a guard as the reason — the reason is uniformity.

**The subshell is the form that actually breaks, and only sometimes.** `( unset …; <command> )` runs when the command carries no git, and is refused when it does, because the worktree guard cannot statically verify a git call inside one. Since a verification recipe may acquire a git step later, the compound form above is the one that keeps working either way.

Measured on Claude Code 2.1.276, inside a worktree session: `env -u FOO echo ok` and `env -u FOO git rev-parse --short HEAD` both ran; `( unset FOO; echo ok )` ran; `( unset FOO; git rev-parse --short HEAD )` and `git -C . rev-parse --short HEAD` were both refused. The last one is the control — it shows the guard was live while `env` was passing.

Moving the command into a script file is not a workaround — the guard cannot read inside a script, so every check is bypassed for that payload. Where a verification cannot be expressed as one compound invocation, reduce the verification rather than route it around the guard.

## Integration into the release branch is self-served

[HARD] A lane whose card has passed verification does not wait for the lead to integrate it: the lane merges its own branch into the batch's release branch (`release/vX.Y.Z`) itself. The lead provisions the release branch and its worktree at batch start; from then on, every integration is lane work.

Two measured constraints make the lane enter the release worktree rather than drive it remotely: git checks one branch out in exactly one worktree, and the worktree-session guard refuses a cross-tree `git -C`.

- **One integration surface.** The release branch lives in exactly one worktree — the one the lead provisioned; a lane never checks it out in its own tree.
- **Enter, do not redirect.** The lane switches in with `EnterWorktree(<release-worktree-path>)` and runs a plain `git merge --no-ff <WT-branch>` there. A cross-tree `git -C <release-worktree> merge` is refused by the worktree-session guard; entering is the sanctioned path.
- **Return the same way.** `ExitWorktree` returns to the primary checkout, not to the lane's own worktree — the lane re-enters its card worktree with `EnterWorktree(<own-path>)` before continuing.
- **One integrating session at a time — and an empty `MERGE_HEAD` does not establish that.** The release worktree is the serialization point. `git rev-parse -q --verify MERGE_HEAD` printing nothing is NECESSARY, never sufficient: it prints nothing just as readily while another lane is mid-resolution — between a `git merge --abort` and its retry, or before it has staged anything. Reading that silence as "the tree is free" is what lets two lanes overlap, invisibly until one commits.

    [HARD] **Serialize by the recorded hold and the announcement, not by probe.** A lane takes the window BEFORE entering the release worktree: `moai integration acquire --name <lane> --card <card-id>` records the hold, `moai integration status` says who has it, `moai integration release` gives it back when the completion report is sent. Taking a live holder's window needs `--force`, which records what it displaced — deliberate, never quiet. The recorded hold is what the PreToolUse guard reads to refuse a second lane's `git merge`; the deny layer is opt-in (`workflow.integration_lock.enabled`, default off), the record works either way. The announcement to the lead rides alongside it — the lead broadcasts the hold and names the holder, and no other session enters until that lane's completion report lands. The probe stays — a lane that finds a merge in progress anyway exits, waits, and retries — but it is the last check, never the first.

    [HARD] **`acquire` asserts the caller's tree first.** It checks tracked `.claude/settings.json`, preserves a modified copy outside that tree, and reports — every time; only the refusal is opt-in, and nothing is ever restored. Detail: `kanban-dispatch-detail.md` § The pre-merge settings-drift assertion.

    [HARD] **Re-read `HEAD` immediately before the commit and again before the push.** `AGENTS.md` §2 binds this everywhere; the release worktree is where it has already earned its keep. A repair commit landing from another lane moves the release `HEAD` mid-resolution, and the pre-commit re-read is the only thing between that and a merge built on a tree that no longer exists.
- **Conflicts belong to the lane that owns the change.** The integrating lane resolves what its own merge raises. A conflict it cannot resolve — a semantic clash with another lane's merged change — is a blocker report to the lead, not a forced merge.
- **Push the release branch; the batch pull request stays with the lead.** The lane pushes `git push origin release/vX.Y.Z`. A rejected push means another lane pushed first — fetch, integrate, push again; never force. Until that branch's batch PR merges, the disposal rule above still binds.

The completion signal is the branch name, merge SHA, and evidence path.

## Factory Mode — the card travels whole

`moai cc -f <N>` launches one lead plus lane sessions labelled `worker-1..worker-N`; the lead routes each card WHOLE to a free lane, which carries it `plan → run → sync` in-session and owns it end to end. Mechanics, label convention, and the A/B/C collapse: `kanban-dispatch-mechanics.md` § Factory Mode mechanics · `kanban-dispatch-detail.md` § Factory in-lane 3-stage.

**Lane spawn authority (standing).** A lane is an orchestrator for its card: it spawns, with the Agent tool and WITHOUT asking, the specialist the Status Transition Ownership Matrix names for the stage at hand — plan-phase artifacts to `manager-spec`, implementation to `manager-develop`, sync-phase docs to `manager-docs`, plus the chain's prescribed auditors. Depth-1 only: agents a lane spawns are leaf workers and never spawn further agents. This authority is part of the lane's bootstrap context (the SessionStart join notice carries it verbatim), and it is deliberately NOT a per-dispatch grant: the runtime's default "don't spawn unless the user asks" guidance does not bind a lane, and a lead's approval can neither grant nor revoke what the bootstrap already grants — the lead is not the lane's user. The same authority binds kanban companion sessions. Observed defect this closes: two lanes refused to spawn `manager-spec` under the default guidance and fell back to editing SPEC bodies directly, routing artifact writes around the ownership matrix.

## Boundaries — what this protocol does not do

- **No gate bypass.** Kickoff approval before run-phase entry, and every other approval gate, is unchanged by being inside a dispatch cycle.
- **No question delegation.** Companion sessions return blocker reports; the operator is asked by the lead, through `AskUserQuestion`.

The three remaining boundaries — no board state store, no session spawning, and an empty role being a fault rather than a wait: `kanban-dispatch-mechanics.md` § Boundaries.

## Cross-references

- `.claude/rules/moai/core/askuser-protocol.md` — the question channel the lead uses for card selection and `/clear` prompts
- `.claude/rules/moai/core/verification-claim-integrity.md` — why completion is read rather than trusted
- The remaining four (blocker-report format, worktree tiers, the queue surface, `manager-lead`): `kanban-dispatch-mechanics.md` § Cross-references

---

Classification: Evolvable operational rule — applies to the lead session of Kanban Mode. Detail companion: `kanban-dispatch-detail.md` (stub + lazy-companion split).
