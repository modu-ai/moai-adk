# AGENTS.md — standing contract for agents in this repository

Every clause here binds a turn regardless of which agent harness drives it. The file is
**self-sufficient**: it does not depend on another instruction file. If a nested `AGENTS.md`
exists, Codex loads it as an additional, more-specific contract; the merged byte budget must cover
the whole discovery chain.

**Budget warning.** Codex charges its instruction byte budget against
project instruction files only; a personal `~/.codex/AGENTS.md` does not shrink it. Overflow is
truncated from the **tail**, silently — no warning, no stderr, exit 0. Clauses below are ordered
most-critical-first for that reason.

This file is the canonical cross-harness contract. `.claude/rules/moai/**` and `CLAUDE.md` expand
Claude-only mechanisms; they do not override a cross-harness clause here. Compression removed
rationale and incident records, never an obligation.

**Capability bindings.** Names below are the neutral tool classes; a row exists only where a
harness driving this contract lacks the capability.

| Capability | Claude implementation | If this harness lacks it |
|---|---|---|
| question-channel | `AskUserQuestion` | Return a blocker report naming the missing input instead of asking in prose |
| task-list | `TaskCreate` / `TaskUpdate` / `TaskList` / `TaskGet` | Track the work and report progress in prose |
| design-sync | `DesignSync` | Skip the design-sync surface; say so in the report |
| worktree-entry | Claude Code: `moai cc -w <name>`; Codex app: select Worktree when starting a chat; Codex CLI: `moai codex -w <existing-worktree>` starts a new session there but never creates a tree | In an active Codex session, use `git -C <absolute-worktree-path>`; report missing isolation instead of editing the shared checkout |

**`Skill("<name>")` instructions carry no row, and are read literally.** Every harness driving
this contract can load a skill, so it earns no row above; what is Claude-only is the per-agent
grant, not the reach. The deploy mirrors every skill to `.agents/skills/<name>/SKILL.md` alongside
`.claude/skills/<name>/SKILL.md`, so `Skill("moai-workflow-tdd")` names
`.agents/skills/moai-workflow-tdd/SKILL.md` — an address, not a Claude-only instruction.

---

## 1. Evidence and verification claims

**No unobserved claim.** An actor MUST NOT assert a verification, a completion, **a defect / debt /
drift, OR the premise underlying a recommendation** it did not actually verify with the domain's
mechanical tooling. Evidence absent is not evidence of success — nor of failure. The absence of a
failure signal never establishes that a check passed; a text-pattern inference is a hypothesis, not
a verified defect; a reference existing does not establish that the referenced capability is still
live. Reachability is not justification.

**Baseline-integrity attribution.** Every verification claim MUST be attributed to an
actually-measured baseline — the command that was run plus the output observed, in this run,
against this tree. A figure carried over from another package, tree, or point in time is not a
baseline; using it as a fresh measurement violates this. Anything unattributed is a Gap, not a
Claim.

**Evidence-bearing report format.** Verification and completion reports SHOULD carry five sections:
**Claim**, **Evidence** (command plus verbatim output), **Baseline-attribution** (tree measured in
this run), **Gaps** (explicitly unobserved), and **Residual-risk**. An empty Gaps section claims
nothing was left unobserved and is valid only when true.

---

## 2. Git, branches, and the shared checkout

The primary checkout is shared — several sessions may work in it at once, and branch state there is
global.

**Never change branch state in the primary checkout.** Forbidden there: `git checkout <branch>` /
`git switch` (relocates every concurrent session's tree); `git checkout -b` / `git switch -c` /
`git branch` (same, plus an unexpected branch); `git reset --hard` / `git checkout -- <path>`
(discards work of unknown provenance); `git stash` (repository-global — absorbs another session's
uncommitted changes); `git rebase` / `git merge` onto the checked-out branch (rewrites or advances
shared history mid-operation). Read-only inspection, `git fetch`, commits to the
already-checked-out branch, and pushing it are permitted.

**Re-read branch and commit state immediately before any commit or push** — never a value read
earlier in the turn, never the branch reported at session start:

```bash
git rev-parse --short HEAD
git branch --show-current
```

A difference from what the turn assumed means another actor is writing the same tree: stop and
report the divergence instead of proceeding.

**Never sweep-stage.** In the primary checkout, never `git add -A`, `git add .`, or
`git commit -a`. Stage by explicit pathspec and re-read `git status --short` immediately before
staging, so another session's files are visible and excluded. This binds **even when no foreign
session was detected** — one can arrive after the check.

**Detect parallel sessions before a non-trivial direct edit** to a shared path (`.claude/`,
`.moai/`, `internal/`, `pkg/`, `cmd/`, repo-root config), and surface any divergence:

```bash
default_ref="$(git symbolic-ref --quiet --short refs/remotes/origin/HEAD)"
test -n "$default_ref"
git fetch origin "${default_ref#origin/}" 2>&1
git rev-list --count --left-right "$default_ref"...HEAD
```

`0 0` or `0 N` proceeds; `N 0` or `N M` means resolve before editing. Where another live session
shares the checkout, isolate into a worktree rather than editing in the shared tree. The check
decays — re-run it before any commit and after a long pause. If `origin/HEAD` is unresolved, stop
and resolve the remote default branch instead of assuming `main`.

---

## 3. Worktrees

**Work inside an isolated worktree.** Claude Code uses `moai cc -w <name>` (`--spawn` for a new
window), `EnterWorktree(<path>)` to re-enter, and `ExitWorktree` to leave. Codex app users select
Worktree when starting a chat; Codex creates and owns that checkout. A Codex factory lane creates
each card tree with `moai worktree new <name>` and launches its next interactive session with
`codex -C <absolute-worktree-path>`. In an already-running Codex session, drive the tree with
`git -C <absolute-worktree-path>` and direct file operations there. `moai codex -w <worktree>`
only launches a new Codex session in an existing tree; it never creates one. **Codex agents must
not invoke `moai cc -w`, `EnterWorktree`, or `ExitWorktree`.** Never create a tree with bare
`git worktree add`.

**From inside a worktree session, `<path>` must be that worktree's absolute path.** Measured on
Claude Code 2.1.275: the guard refuses `-C .`, a relative path, a runtime-computed path, and any
path outside this worktree; plain git, `git -C <own absolute path>` and `--git-dir=<own .git>` pass.
`cd <own worktree> && git …` also passes, which does NOT make it advisable. A refusal here is the
guard reading the command, not a runtime defect.

**`moai worktree done` closes L2 trees only.** A tree under `.claude/worktrees/` is L1, is absent
from the registry, and is disposed by the session-end prompt or by `git worktree unlock` +
`git worktree remove`.

**A card's branch is unpushed, so its worktree holds the only copy of the work.** Dispose of no
worktree — L1 or L2 — until the branch is integrated and the remote merge has landed.

**Start a new card in a new worktree.** Exit any previous worktree back to the primary checkout
first, or the new card's work lands on the old card's branch. Create the fresh tree from the remote
default branch; never reuse the previous card's tree. Where the new card depends on a prior card's
unmerged code, merge that branch inside the new worktree.

**Card worktree branches carry the `WT-` prefix and a descriptive slug, never the card id.** Rename
in place immediately after creating the tree: `git branch -m WT-<slug>`; re-entry resolves by tree
name, and the worktree directory keeps the card id.

**Three traceability carriers are then mandatory**, because the branch name no longer identifies
the card: the dispatch's `card:` field, the card id in every commit message on the branch, and the
card id in the evidence path (`.moai/reports/<card-id>/verdict.md`).

---

## 4. How verification is run

**Scope verification to the change**: run the tests the change can affect, then push and let CI run
the full suite. A full-suite run on a loaded developer machine measures the machine, not the code.

**Never spawn background load.** Where a verification needs contention, the load must be
cleanup-guaranteed — kills registered with the test framework's cleanup hook, or a `timeout`
wrapper bounding the process from outside. A trailing `kill` is not cleanup.

**Scrub the environment in one compound invocation.** Inside a worktree, an environment-scrubbed
verification runs as a single `unset <VARS> && <command>` call; a separate `unset` does not carry
into the next command — each invocation is a fresh process.

**Batch independent read-only verifications rather than serializing them** across turns. Serialize
only for a genuine dependency: one command's output feeding another, writes to the same path, or
shared-state mutation.

**A CodeRabbit row in `gh pr checks` is not evidence that a review ran** — the status reads
`success` and prints `pass` identically whether or not one did. Count the row only when BOTH hold:
(1) `gh api "repos/$repo/commits/$head_sha/status"` reports the `CodeRabbit` context with
`state == "success"` and description `Review completed`; (2) a `Merge Risk:` line exists whose
commit prefix matches the current `headRefOid`. Anything else is a gap, not a pass; `Review rate
limited` means the review never started.

---

## 5. Core behaviors

**1. Surface assumptions.** Before implementing anything non-trivial, list assumptions explicitly
as a short list, invite correction, and wait for confirmation.

**2. Manage confusion actively.** On an inconsistency, a conflicting requirement, or an unclear
specification: STOP — do not guess; name the confusion, present the tradeoff or question, and wait.

**3. Push back when warranted.** Say so directly when an approach has a concrete downside,
contradicts an established convention without justification, or breaks a tested invariant. State
the issue, quantify the downside ("adds ~200 ms latency", not "might be slower"), propose an
alternative, accept an override once the user has full information.

**4. Enforce simplicity.** Actively resist overcomplexity; generation tends toward
over-engineering. Before completing, ask: fewer lines without losing clarity? are these
abstractions earning their complexity? would a staff engineer ask "why didn't you just…"? Apply the
ladder in order, cheapest capability first: (1) does this need building at all? (2) does a helper,
type, or pattern already exist here — reuse it; (3) does the standard library do it; (4) a native
platform feature; (5) an already-installed dependency; (6) can it be one line; (7) only then, the
minimum code that works. The ladder is language-neutral. **Never simplify away safety**: it MUST
NOT be used to drop input validation at trust boundaries, error handling that prevents data loss,
security measures, accessibility, or one runnable check behind non-trivial logic. If an
implementation exceeds 3× the estimated minimum viable line count, stop and simplify first.

**5. Maintain scope discipline.** Touch only what you were asked to touch. Do NOT remove comments
you do not understand, clean up code orthogonal to the task, refactor adjacent systems as a side
effect, delete seemingly-unused code without explicit approval, or add unrequested features because
they seem useful. Match the existing style of the file being modified — naming, error handling,
import organization; consistency within a file outranks personal preference.

**6. Verify, don't assume.** Every task requires evidence of completion; "seems right" is never
sufficient. Tests passing means showing the test output; a build succeeding, the build output; a
file created, reading it back; behavior correct, the runtime evidence. For ad-hoc work without a
spec, define the goal as a testable assertion first — "done when X produces Y" — then verify it.

---

## 6. Output, language, and format

**Respond in the user's configured `conversation_language`.** Code, identifiers, paths, commands,
and flags stay in their original form.

**Non-English output must be native idiom, not English mapped word-for-word.** When
`conversation_language ≠ en`, every user-facing surface — chat, reports, README, docs, generated
sites, question text — MUST read as natural native prose. Translation-style calques (carry-over of
English syntax, metaphor, and figurative stock) are prohibited; native idiom is required. Chat uses
the colloquial native register, artifacts the clean native written register. Deliberately-coined
brand terms and established loanwords are not calques.

**Write non-ASCII payloads as native UTF-8.** Every tool-call payload carrying
`conversation_language` text — command strings, file content, question text — MUST be native UTF-8;
hand-authored `\uXXXX` escapes are PROHIBITED, because a malformed escape corrupts the payload into
a validation error and tends to be copied forward. On such a failure, re-author the text from its
intended meaning rather than repairing the escape.

**User-facing output is Markdown**; never display XML tags to users. **XML is reserved for
agent-to-agent data transfer** — use semantic XML sections for structured data exchange between
agents, never in user-facing output.

**Never use time predictions in plans or reports.** Use priority labels (High / Medium / Low) and
phase ordering ("complete A, then start B"). Prohibited: "2-3 days", "1 week", "as soon as
possible".

---

## 7. Tools and command output

**Follow tool usage patterns optimized for accuracy and efficiency.** Read a file before editing
it. Locate before reading — find the file by pattern, find the line by content, then read that
region rather than the whole file. Use absolute paths and verify a path exists rather than
constructing it from an assumption. Prefer a targeted edit over rewriting a file, and a dedicated
tool over a shell equivalent. Retry safety is asymmetric: read-only and idempotent calls may be
retried, but a side-effecting one (write, commit, push, PR, deploy, external mutation) that fails
ambiguously requires observing current state first and retrying only when the effect is confirmed
absent — no success signal is not evidence the effect did not land. After three failures on one
operation, report the blocker.

**Maintain effectiveness without MCP servers.** Where one is unavailable, fall back to web search
and fetch for library documentation and established patterns, then continue — analysis quality must
not depend on MCP availability.

**Keep command output bounded**: quiet flags, targeted queries, or redirect-to-file with the exit
code and a bounded tail. A runtime output limit is a backstop, not the target. **Prefer the quiet
form of routine commands** — `--no-progress`, `-q`, machine-readable output plus a targeted filter
— not forms emitting spinners, banners, tables, or color noise.

**Weigh session length as a cost axis.** Prefer one warm session for the same work; a new or cold
session re-pays the always-loaded prefix. Split only when the benefit justifies that cost.

---

## 8. Harness-local instructions

`AGENTS.local.md` is the user-owned local instruction file both harnesses read; `CLAUDE.local.md`
is its legacy predecessor. Claude Code reaches `AGENTS.local.md` through the final
`@AGENTS.local.md` import in `CLAUDE.md`; this contract never imports either local file, which
keeps them out of Codex's discovered chain. In a linked worktree that import points outside the
project and is skipped silently, so a worktree session does not receive `AGENTS.local.md`.

For every local launch shape (bare, `cli`, `app`, `--spawn`, and `-w`), `moai codex` reads the
non-empty regular files from the project root — `AGENTS.local.md`, then `CLAUDE.local.md` —
prefixes each body with its own provenance header, and passes the combined text as one session
`developer_instructions` override. A `-w` child still reads the original project root. The
launcher refuses links and non-regular inputs, reads through the descriptor it inspected, and fails
before launch on an operator-supplied `developer_instructions` collision or an oversized
direct/spawn argument. Codex Web sessions do not run the local MoAI launcher, so this injection is
local-CLI-only.

## 9. Hook Event Coverage

Codex currently wires SessionStart, SessionEnd, UserPromptSubmit, PreToolUse, PostToolUse, Stop,
SubagentStart, and SubagentStop. It does not wire PreCompact, PostCompact, PermissionRequest, or
Interrupt; Claude-only Notification, PostToolUseFailure, TeammateIdle, and TaskCompleted never fire
under Codex. Verify coverage before relying on a hook.

## 10. Configuration Map

Project configuration lives in `.moai/config/sections/*.yaml`. Harness, TRUST 5, and phase LSP
thresholds come from `harness.yaml`, `quality.yaml`, `lsp.yaml`, and evaluator profiles; never
duplicate those values inline.

## 11. moai CLI Verbs

| Verb | Purpose |
|------|---------|
| `moai init <project> --llm claude\|codex\|both` | Scaffold a project and select its LLM harness |
| `moai update` | Sync templates and refresh already-enabled wiring |
| `moai tool enable codex` | Add or refresh Codex wiring in an existing project |
| `moai hook <event>` | Hook dispatcher entry point (drives hooks.json / settings.json) |
| `moai doctor` | Diagnose installation and wiring health |
| `moai worktree` | Worktree lifecycle (sync / remove / clean / recover / done / snapshot / verify / restore) |
| `moai cc` / `moai glm` / `moai gpt` | Explicit Claude, GLM, or GPT session launchers |
| `moai migrate cg` | Preview legacy CG migration; role changes require explicit acceptance |
| `moai version` | Print build version and provenance |
| `moai codex` | Codex session launcher — `cli` launch, `status` readout, `app` web; `-w <worktree>` enters an existing tree and never creates one |

Run `moai --help` for the generated, current command surface.

## 12. Status Line Tokens

`moai statusline` reads `.moai/state/` and honors `MOAI_STATUSLINE_CONTEXT_SIZE`. Read
`internal/statusline` for the current token set; do not duplicate it here.
