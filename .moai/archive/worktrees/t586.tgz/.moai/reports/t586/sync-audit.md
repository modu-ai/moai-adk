# Sync-Phase Independent Audit — SPEC-INIT-TUX-I18N-001 (card t586)

Auditor: sync-auditor (independent) · Date: 2026-09-13
Tree: worktree `.claude/worktrees/t586`, branch `WT-init-tux-i18n`, HEAD `533cf5fa4`
Card base: `git merge-base develop HEAD` = `03a48b0df`
Mode: flat weighted-percentage scoring (harness.yaml sets no `evaluator_mode: hierarchical`); Tier L → thorough.

---

## Claim

1. The run-phase claim "all 22 ACs PASS" holds under independent skeptical sampling: every sampled AC re-verified green on this tree in this run, with run counts matching selector counts.
2. progress.md §E.2/§E.3/§E.4 claims are supported by their cited evidence files; spot-checked citations exist and their contents match what progress.md asserts.
3. The sync corrections landed in `33d81b8ff` (research §14 pattern, spec §D D4 ground, design §9 allowlist) are consistent with the artifacts they corrected and with the raw evidence files.
4. Cross-phase identifiers are consistent: 22 ACs across acceptance.md / progress.md / CHANGELOG; spec.md frontmatter transitioned `in-progress → completed` with `status` + `updated` only.
5. Overall verdict: **PASS**, score 0.92.

## Evidence

### 1. Sampled-AC re-verification (this run, this tree, HEAD `533cf5fa4`)

| AC | Command (selector) | Verbatim observed output | Run count vs selector | Verdict |
|----|--------------------|--------------------------|----------------------|---------|
| AC-ITI-008 (golden + leak) | `go test ./internal/cli/ -run 'TestProfileWizardGolden_LocaleFrames\|TestProfileWizardGolden_NoEnglishLeak' -count=1 -v` | `--- PASS: TestProfileWizardGolden_LocaleFrames (0.49s)` with subtests `ko/ja/zh` PASS; `--- PASS: TestProfileWizardGolden_NoEnglishLeak (0.44s)` with `ko/ja/zh` PASS; `ok github.com/modu-ai/moai-adk/internal/cli 1.963s` | 2 selectors → 2 top-level PASS (8 subtests) | PASS |
| AC-ITI-014 (sweep + equivalence) | `go test ./internal/cli/wizard/ -run 'TestWizardTranslationKeys_ReferencedAndLocaleEquivalent' -count=1 -v` | `--- PASS: TestWizardTranslationKeys_ReferencedAndLocaleEquivalent (0.00s)` · `ok ... 0.428s` | 1 → 1 | PASS |
| AC-ITI-018 / 021 / 022 (grouping, denominator, label guard) | `go test ./internal/cli/wizard/ -run 'TestGroupLabel_NotRendered\|TestInitRegroup_TwoPages\|TestInitStepper_Denominator4' -count=1 -v` | `--- PASS` ×3 (`TestInitRegroup_TwoPages 0.00s`, `TestInitStepper_Denominator4 0.08s`, `TestGroupLabel_NotRendered 0.09s`) · `ok ... 0.438s` | 3 → 3 | PASS |
| AC-ITI-005 (save persistence) | `go test ./internal/cli/ -run 'TestProfileSetupAbsorbed_SavePersistsAcrossSurfaces' -count=1 -v` | `--- PASS: TestProfileSetupAbsorbed_SavePersistsAcrossSurfaces (0.04s)` with 2 subtests PASS · `ok ... 0.856s` | 1 → 1 (2 subtests) | PASS |
| AC-ITI-013 (help labels) | `go test ./internal/cli/wizard/ -run 'TestHelpLabels_LocaleGoldenSurfaces' -count=1 -v` | `--- PASS: TestHelpLabels_LocaleGoldenSurfaces` incl. `downgrade-en/ko/ja/zh` subtests PASS · `ok ... 0.471s` | 1 → 1 (locale subtests PASS) | PASS |
| AC-ITI-013 mech | `git grep -n -E 'HelpSelect\|HelpInput' -- '*.go'` → count | `0`; control `ConfirmYes\|ConfirmNo` → `26` | — | PASS |
| AC-ITI-001 mech | `git grep -n 'No profile found' -- '*.go' ':!*_test.go'` → count | `0`; control `Initialization cancelled` → `1`; `runProfileSetup(` in `init.go`/`update.go` → `0` | — | PASS |
| AC-ITI-022 mech | `git grep -n -E '\.Group([^A-Za-z0-9_.]\|$)' -- 'internal/cli/wizard/*.go' ':!*_test.go'` | 10 lines, every line either a `huh.Group` type name or a binding compare/assign inside `buildFormGroups` (`wizard.go:185,188`) or `buildProfileForm` (`profile_wizard.go:75,78`) — exactly the 4-line allowlist design.md §9 records | — | PASS |

Final-gate evidence re-read (not re-run; run-phase measurements): `m7-final-cli-suite.txt` = `ok ... internal/cli 990.931s` / `cli-exit=0`; `m8-final-cli-suite.txt` = `ok ... 992.844s` / `cli-exit=0`; `m8-pty-capture-suite.txt` pty-exit=0; `m8-wizard-suite.txt` wizard-exit=0.

### 2. Fresh mechanical verification (Craft)

```
$ golangci-lint run ./internal/cli/...     → "0 issues."            (this run, this tree)
$ go test ./internal/cli/wizard/ -count=1 -cover
  → "ok  github.com/modu-ai/moai-adk/internal/cli/wizard  4.071s  coverage: 93.6% of statements"
```

Coverage ≥ 85% threshold: PASS (93.6% ≥ 85).

### 3. Claim integrity (VCI §1.1 spot-checks)

| progress.md claim | Cited evidence | Observed |
|---|---|---|
| AC-ITI-008 RED original `m5-ac008-red.txt` | exists (1,343 B) | exists — present |
| AC-ITI-014 mutants `m8-ac014-mutants.txt`, RED `m8-ac014-red.txt` | both exist | present |
| Final gate suites `m7/m8-final-cli-suite.txt` | `ok ... cli-exit=0` | matches claim "rem FAIL 0" |
| research §14 correction `sync-research14-recheck.txt` | recheck grep hits seam call `internal/cli/init.go:858` (`applyAutonomyTierBundleFn(`) | matches corrected pattern `[Aa]pplyAutonomyTierBundle(Fn)?\(`; 11-line claim consistent |
| spec §D D4 re-measurement `sync-d4-recheck.txt` + `sync-d4-recheck-frame/init-first-screen.txt` | frame line 14: `● ○ ○ ○ 1 / 4` visible on 80×30 pty | matches D4 re-judgment text ("ground falsified, exclusion survives on the AC-ITI-021 allocation") |
| design §9 allowlist 4 lines | my grep reproduces exactly `wizard.go:185,188` + `profile_wizard.go:75,78` | matches |
| §E.4 `sync_commit_sha: pending-backfill-sync` | HEAD `533cf5fa4` is the sync commit itself | sanctioned D3 self-reference placeholder; backfill owed in a follow-up commit — see Gaps |

### 4. Cross-phase consistency

- AC identifiers `AC-ITI-001..022` — 22 live identifiers in acceptance.md; progress.md matrix covers 001–022 with no identifier gap; CHANGELOG entry names "22 acceptance criteria (AC-ITI-001..022), all PASS". Consistent.
- CHANGELOG entry (CHANGELOG.md:12) matches implementation reality on every point I could check mechanically (profile path gone from init/update — grep 0; HelpSelect/HelpInput gone — grep 0; 3-phase close; plan-artifact corrections; placeholder SHA policy).
- spec.md frontmatter: `status: completed`, `updated: 2026-09-13`, version 0.2.3, tier L — matches §E.4 (c).
- Sync commit `533cf5fa4` and correction commit `33d81b8ff` present in `git log` lineage M1 `4d985fe48` → … → M8 `e561b162e` → `33d81b8ff` → `533cf5fa4`. §E.3 lineage verified against git log.

### 5. Security probes

- Secret-pattern scan over the branch diff (`git diff 03a48b0df..HEAD -- internal/`): all `token` hits are TUI color-token identifiers/comments; no credential-shaped strings. Exit 0 on scan, 0 credential hits.
- No new trust boundaries: the change is wizard rendering/localization + test harness; no network, no exec-of-input, no file writes outside the established profile/config paths (which retain their existing validation, e.g. `filepath.Abs` handling per repo conventions).
- No Critical/High findings.

### 6. MX tag hygiene (advisory)

Card-touched production files with `@MX` count: `wizard.go` 3, `ptycaptest/harness.go` 2 — but `profile_wizard.go`, `translations.go`, `help_surfaces.go`-family and `ptycaptest/{doc,formdriver,render,homewatch}.go` carry 0. The new package `ptycaptest` has a `doc.go` (package documentation present). Missing-where-required: none found (no high-fan-in exported function left un-anchored in the sampled files); partial coverage is advisory, not blocking.

## Baseline-attribution

All sampled commands were run by this auditor, in this session, against this tree at HEAD `533cf5fa4` (verbatim outputs in §Evidence). Coverage/lint figures re-measured fresh (93.6%, "0 issues.") — not carried over. Full-suite and pty figures (`m8-final-cli-suite.txt` exit 0) are run-phase measurements re-read, not re-run — attributed as such.

## Gaps

1. **Not all 22 ACs re-verified.** Sample = 8 ACs (mechanical + golden + guard classes, incl. all dispatch-named highest-risk ACs). The remaining 14 rely on the run-phase evidence, which I read but did not re-execute.
2. **Full suite not re-run locally** (per constraint: no `go test ./...`; CI on `origin/develop` after the lead's batch push is the full-suite verdict surface).
3. **AC-ITI-019/020 pty-guard ACs not re-executed** (tmux-dependent, heavy); their evidence files (`ac019/`, `ptycap-all/`) were read, not re-produced.
4. **Cross-model second opinion not taken.** `mcp__moai__audit_multi` was skipped: the only commit-scoped targets it accepts resolve against the remote default branch, which in this git-flow topology would review the wrong diff (develop is the integration base); `uncommittedChanges` has no code diff (untracked evidence only). Fail-open, non-blocking.
5. **`sync_commit_sha` backfill not yet landed** — HEAD is the sync commit itself, so the placeholder `pending-backfill-sync` still stands. Per doctrine (spec-frontmatter-schema.md § D3) a follow-up commit must backfill `533cf5fa4`. Owed work; verify it lands before the card is archived.
6. **ptycaptest direct coverage 38.3%** (recorded in progress.md as residual; the package is a child-process test harness whose effective coverage is exercised via the parent `internal/cli` suite, where its direct-run capture tests SKIP). Advisory.

## Residual-risk

- The carried REQ-ITI-007 option-label locale-fix residual and the AC-ITI-011(3) truecolor-ANSI TERM sensitivity are already declared in §E.4(b) and the CHANGELOG; both are operator-report items, not defects of this close. A re-run of the axis goldens under a different color profile could red a passing AC without any code change.
- The 14 unsampled ACs could in principle contain a regression invisible to this sample; the risk is bounded by the exit-0 full-package suite (M7+M8 evidence) and the lint/coverage re-measurement.

---

## Dimension Scores

| Dimension | Weight | Score | Verdict | Evidence (mechanical, this run) |
|-----------|--------|-------|---------|--------------------------------|
| Functionality | 40% | 95/100 | PASS | 8 sampled ACs re-verified green with run-count parity; final-gate suites exit 0 (`m8-final-cli-suite.txt`); AC count 22 consistent across 3 artifacts |
| Security | 25% | 90/100 | PASS | secret-pattern diff scan: 0 credential hits; no new trust boundary; grep guards clean — no dedicated SAST scanner run (gap, fail-open) |
| Craft | 20% | 90/100 | PASS | `golangci-lint run ./internal/cli/...` → `0 issues.`; fresh `go test -cover` → 93.6% ≥ 85; RED-first + mutant discipline evidenced throughout §E.2 (advisory: ptycaptest direct 38.3%) |
| Consistency | 15% | 92/100 | PASS | sync corrections in `33d81b8ff` match their evidence files and target paragraphs; §E.3 lineage matches git log; MX tag partial coverage (advisory) |

**Must-pass firewall**: Functionality PASS, Security PASS — firewall satisfied.

**Harmonic mean**: 4/(1/95 + 1/90 + 1/90 + 1/92) ≈ **91.7 → 0.92** ≥ Tier L/thorough threshold 0.85.

## Overall Verdict: **PASS (0.92)**

## Findings (defect-list)

- F1 [Info] [optional] progress.md §E.4 / `.moai/specs/SPEC-INIT-TUX-I18N-001/progress.md` — `sync_commit_sha` holds the sanctioned `pending-backfill-sync` placeholder; the backfill to `533cf5fa4` has not landed yet. Required fix: land the backfill commit (phase-owning agent scope, D3 exemption) before card archival.
- F2 [Low] [optional] `internal/cli/wizard/profile_wizard.go`, `internal/cli/wizard/translations.go`, `internal/cli/ptycaptest/{doc,formdriver,render,homewatch}.go` — 0 `@MX` annotations on card-authored files. Required fix (advisory): consider `@MX:NOTE` on `buildProfileForm` (absorbed-wizard entry point) and `ptycaptest` harness entry; no blocking requirement found.
- F3 [Low] [optional] `internal/cli/ptycaptest/` — direct coverage 38.3% vs the 85% package bar; structurally explained (child-process harness, capture tests SKIP in direct runs) and already recorded as residual in §E.2. Required fix: none for this SPEC; a follow-up could move the bar or document the exclusion formally.
- F4 [Low] [optional] AC-ITI-011(3) axis goldens embed truecolor ANSI — environment-sensitive PASS. Already carried to the operator report (§E.4(b)); no action in this SPEC.

All findings are optional per the finding-consumption discipline; none is blocking, and no all-blocking finding exists, so the PASS stands on the must-pass firewall + threshold.
