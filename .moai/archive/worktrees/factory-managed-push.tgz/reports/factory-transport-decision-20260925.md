# Factory lead·agent 통신 방식 재검토

기준: 2026-09-25. 문서 확인과 macOS 개발 트리 조사. Windows·WSL2 실세션은 실행하지 않았다. 이 보고서는 구현 승인이나 릴리스 판정이 아니다.

## 결론

카드 원장과 영수증은 모든 조합에서 MoAI 브로커 하나로 통일한다. 수신 세션을 깨우는 경로만 호스트별로 둔다. 현 단계에서 `Claude 전용 run = 네이티브 메시지만 사용` 예외를 제품 기본 정책으로 확정하지 않는다. 네이티브 메시지만으로는 MoAI의 배차·수락·완료·재시도 기록이 자동으로 남지 않기 때문이다. Claude 전용 run의 네이티브 경로는 브로커 알림 어댑터로 검증한 뒤 선택 기능으로 판단한다.

## 경우의 수

| lead → agent | macOS/Linux | Windows WSL2 같은 배포판 | Windows 네이티브 | 판정 |
|---|---|---|---|---|
| Claude/GLM → Claude/GLM | Claude 직접 메시지 문서상 가능 | Claude 직접 메시지 문서상 가능 | Claude 직접 메시지 문서상 가능 | MoAI 카드는 브로커 원장 권장. 직접 메시지는 알림 경로 후보 |
| Claude/GLM → Codex | Claude 직접 메시지로 Codex를 깨우는 계약 없음 | 동일 | 동일 | 브로커 + Codex 호스트 입력 필요 |
| Codex → Claude/GLM | Codex 직접 메시지로 Claude를 깨우는 계약 없음 | 동일 | 동일 | 브로커 + Claude 호스트 입력 필요 |
| Codex → Codex | Claude 직접 메시지 해당 없음 | 동일 | 동일 | 브로커 + Codex 호스트 입력 필요 |

WSL2 Claude와 Windows 네이티브 Claude는 같은 컴퓨터여도 서로 직접 메시지를 주고받지 못한다. WSL2 전제는 두 세션과 MoAI 상태 저장소가 **같은 WSL2 배포판·사용자·프로젝트 상태**를 공유한다는 뜻으로 한정해야 한다. 네이티브 Windows와 WSL2를 섞은 경우는 별도 교량이 필요하고 미검증이다.

## 근거와 관찰

- Claude 공식 문서: macOS/Linux/WSL2는 2.1.224+, 네이티브 Windows는 2.1.234+에서 세션 간 메시지를 지원한다. 같은 컴퓨터의 다른 세션은 소켓/파이프를 사용하며, WSL2 ↔ Windows 네이티브는 직접 도달하지 않는다. 같은 컴퓨터의 제공자별 지원은 일부 경우 2.1.248+가 필요하다. 수신자는 `accept`/`hold`/`refuse` 설정에 영향을 받는다.
- Claude 공식 문서: 수신 중인 세션은 활성 턴의 도구 호출 사이 또는 유휴 상태의 새 턴에서 메시지를 읽는다. 자체 세션 소켓 주소는 훅에 공개되지만, 외부 프로세스가 보낸 메시지의 인증·수신 정책이 적용된다. MoAI가 이를 안전하게 사용하는 구현은 아직 실측하지 않았다.
- Codex App Server 공식 문서: `thread/start`/`thread/resume`, `turn/start`, 활성 턴용 `turn/steer`, 완료 알림이 있다. 이는 MoAI가 소유한 Codex 세션에 입력을 넣는 제어 경로다. 기존 임의 TUI 세션을 외부에서 깨우는 보장은 이 문서만으로 확립되지 않는다.
- 현재 macOS에서 `uname -s` → `Darwin`, `claude --version` → `2.1.282 (Claude Code)`, `codex --version` → `codex-cli 0.156.1`. `codex queue --help`는 기존 세션에 메시지를 대기시키는 명령을 보여 준다. 명령 성공과 모델 수신·실행은 별도 판정이다.
- 현재 개발 트리 `internal/cli/launch_exec_posix.go:31-32`, `launch_exec_windows.go:34-35`는 모든 Claude Factory 세션을 관리형 `stream-json`으로 실행한다. `internal/cli/mcp_factory_msg.go:45-63`은 Codex에 `codex queue` 알림을 보내고 Claude에 `next-turn`을 보고한다. 별도 실측 보고서에서는 macOS Codex lead → 관리형 GLM agent 카드 수신·회신·영수증을 관찰했지만 Windows 및 실제 작업 완료·병합은 미검증이다.

## 선택 기준과 구현 순서

1. **High — 공통 계약:** run/slot `lead`, `agent-1…n`, 카드 ID, 메시지 ID, 세대, 수신·처리 영수증, 중복 방지, 만료·재배차를 브로커 기준으로 고정한다. `-f worker`는 새 CLI에서 거부하고, 이전 `worker-n` 저장 기록만 읽기 호환으로 둔다.
2. **High — Codex 제어:** 관리형 Codex App Server 세션의 `turn/start`/`turn/steer`를 1차 경로로 검증한다. `codex queue`는 기존 TUI용 보조 경로로 두고 입력 수락과 모델 처리 완료를 구별한다.
3. **High — Claude 제어:** 현재 관리형 `stream-json`의 양방향 macOS 실측을 보존한다. Claude TUI 유지가 필요하면 공식 소켓의 자체 세션 알림을 별도 실세션에서 인증·수신·영수증까지 검증한다. 검증 전 네이티브 전용 모드를 제공하지 않는다.
4. **High — 조합 시험:** Claude↔Claude, Claude↔Codex, Codex↔Codex에서 양방향 배차, ACK, 작업 보고, 완료·병합 요청, 재시작, 중복, 만료를 각각 확인한다. WSL2도 같은 배포판에서 실행한다. Windows 네이티브는 접속 가능한 호스트가 생긴 뒤 실측한다.
5. **Medium — 사용자 표면:** 도움말·훅·스킬·보고 문구를 `lead`/`agent`로 맞추고, 수신 상태를 `queued`와 `delivered/accepted`로 분리해 표시한다.

## 미해결 위험

공식 문서는 호스트 API의 가능성을 설명하지만 MoAI의 교차 호스트 자동 카드 처리 성공을 보증하지 않는다. 현재 이름 변경은 격리 작업 트리에서 진행 중이며 테스트 갱신 전이다. 사용자 실행 파일이나 주 작업 트리에 반영되지 않았다.

## 출처

- Claude 세션 간 메시지: https://code.claude.com/docs/en/cross-session-messaging
- Claude 비대화형 실행: https://code.claude.com/docs/en/headless
- Codex App Server: https://learn.chatgpt.com/docs/app-server
- MCP 서버 기능 개요: https://modelcontextprotocol.io/specification/draft/server/index
- 이전 macOS 실측: reports/factory-bidirectional-push-20260925.md
