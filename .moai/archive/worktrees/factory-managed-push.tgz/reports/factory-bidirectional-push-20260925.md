# MoAI Factory 양방향 수신 조사

기준: 2026-09-25, macOS 실측, `WT-factory-managed-push` 작업 트리의 `a0b78213d` 기반 미커밋 소스. 사용자 프로젝트의 `tlw2bg`와 카드 `t10`에는 접근하거나 변경하지 않았다.

## Claim

1. 사용자 로그의 `factory_msg_send: ok`, 메시지 ID `833987069ca46e884498e43d62e58336`, `Pending: 1`은 브로커 저장을 보여준다. Claude Code worker-1의 자동 수신, 본문 조회, 처리 성공은 보여주지 않는다.
2. Claude Code의 일반 MCP 서버는 Claude가 턴 중 도구로 조회하는 방식이다. 공식 문서는 일반 MCP 서버에는 세션으로 푸시가 없다고 명시한다. `UserPromptSubmit`은 사용자가 프롬프트를 제출할 때, `Stop`은 응답 종료 때 실행된다. 따라서 기존 일반 TUI와 턴 경계 훅만으로 대기 중인 worker를 외부 메시지로 깨우는 기능은 없다.
3. 기술적으로 자동 수신은 가능하다. Claude Code의 Channels는 기존 실행 세션에 MCP 서버 알림을 푸시한다. 연구 미리보기이며 Anthropic 인증, 세션별 채널 활성화, 커스텀 채널의 개발 플래그 또는 조직 허용 목록이 필요하다. GLM 로그인 환경은 이 공식 지원 조건에 포함되지 않는다.
4. GLM에는 MoAI가 Claude Code `--print --input-format stream-json --output-format stream-json` 프로세스를 소유하고 입력을 지속 공급하는 관리 세션 경로가 가능하다. Codex에는 `codex queue`를 사용한다. 두 호스트 모두 MoAI MCP로 발신하고, 브로커에서 본문과 영수증을 관리한다.
5. 새 관리 세션과 Codex 실세션에서 양방향 자동 메시지 처리를 실측했다. 이는 새 개발 빌드와 격리 프로젝트의 결과이며, 구스~오뽜가 실행한 기존 worker-1에 소급 적용되지 않는다.

## Evidence

사용자 제공 로그:

```text
moai.factory_msg_send(... to_slot=worker-1, kind=dispatch_notice, task_ref=t10 ...)
factory_msg_send: ok
message_id: 833987069ca46e884498e43d62e58336
Pending: 1
```

격리 실세션: `/var/folders/kt/nq2q81cn4gx3y41r7x47ggmr0000gn/T/moai-managed-probe-zi8zb8dg`, Factory run `tlw2ob`. 관리형 GLM Claude Code는 `lead`, Codex CLI `0.156.1`은 `worker-1`로 시작했다. Codex가 `factory_msg_send`로 `status_request`를 발신한 뒤 GLM에는 터미널 입력을 하지 않았다. GLM이 본문을 읽고 `status_report`를 발신했다. Codex가 수신 본문을 읽고 영수증을 남겼다.

```text
sqlite3 .../factory/messages/tlw2ob/broker.db \
  'select id,kind,sender_slot,state,disposition,task_ref from messages;'
2b086f4f8d8503d13744d591379181bd|status_request|worker-1|acknowledged|accepted|probe-tlw2ob
289c91a213427eeb4d5866f9aacfdac1|status_report|lead|acknowledged|accepted|probe-tlw2ob
```

관리형 GLM 출력에는 `메타데이터를 확인했으니 본문을 읽겠습니다`, `ACK 응답 전송이 완료되었으므로... 처리 결과... 기록하겠습니다`가 표시됐다. Codex TUI에는 회신 메시지의 `factory_msg_body` 호출이 보였다. 두 프로세스는 시험 뒤 `/exit`으로 종료했다.

같은 격리 프로젝트의 두 번째 실세션은 역할을 바꿨다. Codex `lead`와 관리형 GLM `worker-1`이 Factory run `tlw35i`에 연결됐다. 테스트 카드 `t1`을 `moai todo add ... --pick`으로 발행한 뒤 Codex가 `dispatch_notice`를 보냈다. 대기 중인 GLM worker에는 수동 입력을 하지 않았다. GLM이 배차를 읽고 `status_report`를 보냈고, Codex lead가 본문 조회와 `accepted` 영수증을 남겼다.

```text
MOAI_HOME=... /tmp/moai-factory-managed-live todo add '[FACTORY-TEST] worker-1 배차 수신 뒤 ACK 회신만 수행; 파일 수정 없음' --pick
picked t1 [FACTORY-TEST] worker-1 배차 수신 뒤 ACK 회신만 ...

sqlite3 .../factory/messages/tlw35i/broker.db \
  'select id,kind,sender_slot,state,disposition,task_ref from messages;'
6ed43a574e54c38f7bd35c6cf78ecd79|dispatch_notice|lead|acknowledged|accepted|t1
f62821c138e41ee2a2d1a8c688d65d56|status_report|worker-1|acknowledged|accepted|t1
```

Codex lead 세션 `01a0d57c-d663-7f33-a49d-72b08d9d079d`의 JSONL에는 `f62821c138e41ee2a2d1a8c688d65d56`에 대한 `factory_msg_body` 완료, worker의 `t1` 배차 수신 확인 본문, `factory_msg_receipt`의 `acknowledged:true`가 남았다.
두 번째 시험의 Codex는 `/exit`으로 종료했다. GLM worker는 `/exit` 입력 뒤에도 프로세스가 남아 있어 Ctrl-C로 종료했고, PID `57325`가 사라진 것을 `ps -p 57325 -o pid=,command=`의 빈 출력으로 확인했다.

```text
go test ./internal/cli ./internal/factorymsg -run '^(TestManagedFactory|TestFactoryMsg)' -count=1
ok  github.com/modu-ai/moai-adk/internal/cli  2.886s
ok  github.com/modu-ai/moai-adk/internal/factorymsg  0.321s [no tests to run]

GOOS=windows GOARCH=amd64 go build -o /tmp/moai-factory-managed-win.exe ./cmd/moai
exit 0, output 없음

git diff --check
exit 0, output 없음
```

## Baseline-attribution

- 소스: `/Users/goos/MoAI/moai-adk-go/.claude/worktrees/factory-managed-push`, 브랜치 `WT-factory-managed-push`, 기반 커밋 `a0b78213d`.
- 실세션: 위 격리 프로젝트와 별도 `MOAI_HOME`, 개발 빌드 `/tmp/moai-factory-managed-live`. 사용자 프로젝트의 Factory run `tlw2bg`를 수정하지 않았다.
- 정확한 역할 시험: 같은 격리 프로젝트의 run `tlw35i`, 테스트 카드 `t1`, Codex lead 세션 `01a0d57c-d663-7f33-a49d-72b08d9d079d`. 사용자 카드 `t10`과 별개다.
- GLM 키는 자식 프로세스 환경으로만 전달했다. 값은 보고서에 기록하지 않았다.

## Gaps

- 사용자 `tlw2bg`의 Claude worker-1은 기존 TUI다. 해당 세션에 `t10`이 자동 수신됐다는 증거는 없다. 새 관리 방식은 새 Factory 세션으로 시작해야 적용된다.
- Codex `lead` → GLM `worker-1`의 카드 배차와 수신 보고는 실측했다. 실제 카드 작업 수행, 완료·병합 요청까지의 전 과정은 실측하지 않았다.
- Windows 네이티브 실행은 미실측이다. Windows 교차 빌드만 성공했다.
- 사용자 로그의 `Hook failed: invalid user prompt submit JSON output` 원인은 별도 조사 대상이다. 브로커 `Pending: 1`만으로 이 훅 오류와 미수신의 인과관계를 단정하지 않는다.
- Claude Channels를 MoAI MCP에 통합하거나 GLM 인증에서 사용 가능한지는 실측하지 않았다. 공식 지원 조건상 GLM을 Channels 경로로 판정하지 않는다.

## Residual-risk

- 브로커 저장 및 `codex queue` 수락은 모델의 처리 완료가 아니다. `factory_msg_body`와 `factory_msg_receipt`의 `accepted`까지 확인해야 한다.
- 관리형 Claude/GLM은 일반 TUI 화면이 아니라 출력 스트림 기반 화면이다. 도구 승인 정책이 막으면 자동 처리가 중단될 수 있다.
- 두 번째 실세션의 GLM worker에서는 `/exit`이 즉시 종료되지 않았다. 종료 입력과 진행 중인 턴의 상호작용을 재현·수정해야 한다.
- 현재 개발 소스의 `factory_msg_status`는 여전히 `hook-boundary`로 표시하므로 관리형 자동 수신 상태 표현이 낡았다. 이 표기를 수정하고 관련 검증을 추가해야 한다.
- Channels는 공식 문서상 알림 전송 완료를 모델 처리 완료로 보장하지 않는다. MoAI 영수증이 필요하다.

## 개선 순서

1. **High**: GLM Factory의 관리 세션을 안정화하고 사용자에게 수신 상태·오류·승인 대기를 표시한다. Codex는 큐 알림을 유지한다. 각 호스트가 `factory_msg_send`, 본문 조회, 영수증을 수행하도록 공통 프로토콜을 둔다.
2. **High**: 검증된 배차·수신 보고를 실제 카드 작업, 완료와 병합 요청까지 확장해 격리된 실제 세션에서 각각 확인한다. 완료 기준은 브로커 `accepted`와 카드 상태 증거다.
3. **High**: `factory_msg_status`와 송신 결과의 `queued`/`next-turn`/`managed-poll` 의미를 실제 수신 방식에 맞춘다. 부팅 때 수신 방식과 인증 제한을 보여준다.
4. **Medium**: Anthropic 인증 Claude Code에는 공식 Channels 통합을 별도 후보로 검토한다. 미리보기 허용 목록과 조직 정책을 충족한 세션에서만 사용한다. GLM에는 관리 세션을 유지한다.
5. **Medium**: 훅 JSON 오류를 재현하고 입력·출력 계약에 맞춰 수정한다. Windows는 접속 가능한 네이티브 러너에서 별도 실측한다.

## 공식 문서

- [Claude Code Channels](https://code.claude.com/docs/en/channels): 일반 MCP와 푸시 채널의 차이, 인증·조직 정책.
- [Claude Code Channels reference](https://code.claude.com/docs/en/channels-reference): `claude/channel` capability, `notifications/claude/channel`, 처리 확인 한계.
- [Claude Code CLI reference](https://code.claude.com/docs/en/cli-reference): `--input-format stream-json`, `--output-format stream-json`.
- [Claude Code Hooks reference](https://code.claude.com/docs/en/hooks): `UserPromptSubmit`, `Stop` 실행 시점.
