# MoAI Factory 교차 호스트 푸시 실측 및 수정 보고

- 기준: macOS, 실세션 당시 `develop` `e38c20d4e`, 이후 병합된 현재 `develop` `a0b78213d`, Codex CLI `0.156.1`, Claude Code `2.1.281`, 2026-09-24.
- 판정: **부분 성공**. GLM으로 실행한 실제 Claude Code 모델의 MCP 송신 → 대기 중 Codex TUI 자동 기동 → MCP 본문 조회 → `accepted` 영수증을 실측했다. 대기 중인 일반 Claude/GLM TUI의 역방향 자동 기동은 구현·실측되지 않았다.

## Claim

1. 기존 `factory_msg_send`는 브로커 저장만 수행하고 Codex 세션에 턴을 시작시키지 않았다. 기존 Factory 훅은 Claude/GLM에서 다음 턴 경계에만 우편함을 확인한다.
2. 개발 빌드에서 Codex 수신자에게는 `codex queue --thread`로 메시지 ID만 포함한 알림을 보낸다. 본문은 MoAI MCP에서 조회한다. 중복 전송은 추가 턴을 만들지 않는다.
3. MCP 결과의 TextContent와 StructuredContent 모두에 JSON을 제공해야 Codex가 `ClaimToken`을 읽고 본문 조회·영수증을 이어갈 수 있었다.
4. Claude/GLM CLI의 지속 `stream-json` 입력은 동일 프로세스에서 두 번째 턴을 실행했다. 이는 관리형 세션의 가능성만 입증하며 Factory 브로커 연결은 미구현이다.

## Evidence

```text
go test ./internal/cli ./internal/factorymsg -run '^(TestFactoryMsgSendQueuesCodexInboxWithoutPeerBody|TestFactoryMsgNotifyReportsDeliveryBoundary|TestFactoryMCPIdentityAttribution)$' -count=1
ok  github.com/modu-ai/moai-adk/internal/cli  1.642s
ok  github.com/modu-ai/moai-adk/internal/factorymsg  0.348s [no tests to run]

go test ./internal/cli -run '^TestFactoryMsg' -count=1
ok  github.com/modu-ai/moai-adk/internal/cli  2.139s

go test ./internal/hook -run '^TestFactory' -count=1
ok  github.com/modu-ai/moai-adk/internal/hook  65.877s

go build -o /tmp/moai-codex-push-kddbYr/moai-push-verify ./cmd/moai
exit 0, output 없음

git diff --check
exit 0, output 없음
```

격리된 실세션에서 Go 프로세스가 GLM 역할 피어로 송신한 초기 시험은 `notification:queued`, `broker acknowledged=1 pending=0 claimed=0`, `PASS`를 기록했다. Codex 세션 `01a0d2b7-51cb-7cb0-ad8e-97e0829c8f7f`의 JSONL에는 `factory_msg_list`, `factory_msg_body`, `factory_msg_receipt` 완료와 본문 마커 `LIVE_MCP_PUSH_RECEIVED`를 포함한 응답이 남았다.

송신자를 실제 GLM 기반 Claude Code로 바꾼 시험은 `factory_msg_send` 결과 `notification: queued`와 메시지 ID `f7db4a2d0a4ac5f9df74236c6ede1d20`을 기록했다. Codex 세션 `01a0d314-ca2c-77e3-af60-4523e8c03cc9`의 JSONL에서 같은 ID에 대한 `factory_msg_list`, `factory_msg_body` (`LIVE_GLM_TO_CODEX_RECEIVED`), `factory_msg_receipt` (`accepted`) 호출이 확인됐다. 실행 전 영수증 수 1건에서 `broker acknowledged=2 pending=0 claimed=0`으로 늘었고 `TestFactoryMsgCodexWakeLive`는 `PASS (33.88s)`였다. 이때 Codex 터미널에 수동 입력은 없었다.

한 차례 테스트는 이전 영수증 1건을 새 도착으로 잘못 세어 거짓 PASS였다. 이후 테스트를 실행 전 영수증 수보다 증가해야 통과하도록 수정했고, 재실행으로 위 새 메시지 ID를 확인했다.

Claude/GLM 관리형 입력 별도 실험에서는 `moai glm -- -p --verbose --input-format stream-json --output-format stream-json` 프로세스에 첫 사용자 메시지 완료 뒤 두 번째 JSON 사용자 메시지를 넣었다. 같은 프로세스가 `STREAM_READY_4J2`, 이어서 `STREAM_PUSH_6Q8`에 응답했고 드라이버가 `TWO_TURNS_DELIVERED`를 출력했다.

## Baseline-attribution

- 소스와 테스트: `/Users/goos/MoAI/moai-adk-go/.claude/worktrees/develop`, `develop` HEAD `e38c20d4e`, 위 명령을 이 트리에서 실행.
- 작업 중 다른 세션의 병합으로 HEAD가 `a0b78213d`로 이동했다. 그 상태에서 `go build -o /tmp/moai-codex-push-kddbYr/moai-push-current ./cmd/moai`와 `go test ./internal/cli ./internal/factorymsg -run '^TestFactoryMsg' -count=1`을 다시 실행했고 둘 다 exit 0이었다. 이 재검증은 GLM→Codex 실세션 재실행을 뜻하지 않는다.
- 개발 빌드: `/tmp/moai-codex-push-kddbYr/moai-push-verify`; 전역 설치 `moai`는 교체하지 않음.
- Codex 실세션: 독립 프로젝트 `/tmp/moai-codex-push-kddbYr/project`, 독립 `MOAI_HOME`, 최종 수신 스레드 `01a0d314-ca2c-77e3-af60-4523e8c03cc9`. `--dangerously-bypass-approvals-and-sandbox` 사용. GLM 키는 시험 자식 프로세스 환경에만 주입하고 출력에서는 가렸다.
- `-a never` 세션에서는 `factory_msg_list`가 `MCP tool call requires approval, but approval policy is never`로 실패했다. 승인 정책별 자동 처리까지 검증된 것은 아니다.

## Gaps

- Codex → 대기 중 일반 Claude/GLM TUI를 깨우는 경로는 없다. 현재 소스는 `next-turn`을 반환한다.
- Claude/GLM `stream-json` 제어 프로세스와 Factory 브로커의 연결, 카드 배차·완료·병합 요청 왕복은 구현·실측되지 않았다.
- Windows 네이티브 실측은 하지 않았다.
- `develop` HEAD가 작업 중 다른 세션의 병합으로 이동했다. 수정 파일은 커밋·푸시하지 않았다.

## Residual-risk

- `codex queue` 성공은 큐 수락이며 수신 완료가 아니다. 완료 판정은 브로커 영수증으로 해야 한다.
- `codex` 실행 파일이 MCP 서버의 PATH에 없거나 수신 프로세스가 종료되면 알림은 `queue-failed`가 되고 메시지는 우편함에 남는다.
- 사용자 승인 정책이 MCP 도구 호출을 막으면 자동 수신이 중단된다.
- 서로 다른 호스트의 대기 중 턴 전달 지연과 도착 보장은 아직 정의·측정되지 않았다.

## 개선 순서

1. **High**: Claude/GLM Factory 세션의 수신 방식을 결정한다. 일반 TUI 유지 시 `next-turn` 의미를 UI와 상태에 명확히 표시한다. 대기 중 푸시를 요구하면 CLI의 지속 `stream-json`을 MoAI가 관리하고 브로커 알림을 JSON 입력으로 전달한다.
2. **High**: 관리형 경로를 선택하면 양방향 실세션에서 배차 → 본문 조회 → 처리 결과 → 영수증 → 완료 보고 → 병합 요청을 각각 확인한다. 승인 정책과 재시작·중복·만료도 검증한다.
3. **Medium**: `factory_msg_status`의 단일 `hook-boundary` 표기를 수신자별 `queued`/`next-turn`/`queue-failed`와 맞춘다. 브로커의 기록과 실제 도착을 분리해 표시한다.
4. **Medium**: 설치 바이너리 교체는 양방향 검증과 별도로 진행한다. 현재 소스 수정은 `develop` 작업 트리에만 있다.

## 공식 문서

- [Codex App Server](https://learn.chatgpt.com/docs/app-server)
- [Codex MCP](https://learn.chatgpt.com/docs/extend/mcp)
- [Claude Code Hooks](https://code.claude.com/docs/en/hooks)
- [Claude Code CLI](https://code.claude.com/docs/en/cli-reference)
