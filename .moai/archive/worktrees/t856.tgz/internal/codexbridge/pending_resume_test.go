package codexbridge

import (
	"context"
	"encoding/json"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codexapp"
)

type pendingResumeRPC struct {
	*fakeRPC
	arguments    string
	replyID      string
	notification string
}

func (f *pendingResumeRPC) Call(ctx context.Context, method string, params any, out any) error {
	if err := f.fakeRPC.Call(ctx, method, params, out); err != nil {
		return err
	}
	if method == "thread/resume" {
		f.events <- usageEvent("turn-thread-1", 100, 20, 10)
		f.events <- codexapp.Message{Method: "serverRequest/resolved", Params: json.RawMessage(`{"threadId":"thread-1","requestId":"old-rpc"}`)}
		if f.notification != "" {
			f.events <- codexapp.Message{Method: f.notification, Params: json.RawMessage(`{"threadId":"thread-1","turnId":"turn-thread-1","delta":"MUST_NOT_DROP","turn":{"id":"turn-thread-1","status":"completed"}}`)}
		}
		raw, _ := json.Marshal(map[string]any{"threadId": "thread-1", "turnId": "turn-thread-1", "callId": "call-thread-1", "tool": "echo", "arguments": json.RawMessage(f.arguments)})
		f.events <- codexapp.Message{ID: json.RawMessage(`"replacement-rpc"`), Method: "item/tool/call", Params: raw}
	}
	return nil
}

func (f *pendingResumeRPC) Respond(ctx context.Context, id json.RawMessage, result any) error {
	f.replyID = string(id)
	return f.fakeRPC.Respond(ctx, json.RawMessage(`"thread-1"`), result)
}

func TestPendingResumeMatchesReissuedCallBeforeReturningResult(t *testing.T) {
	for _, mode := range []string{"matching", "arguments-changed", "schema-changed", "public-id-changed", "reply-started", "metadata-missing", "public-text", "terminal", "error"} {
		t.Run(mode, func(t *testing.T) {
			e, _, store := fixture(t)
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			q := request("pending-resume")
			first, err := e.Step(ctx, q)
			if err != nil || first.Tool == nil {
				t.Fatal(first, err)
			}
			e.Close()
			q.ResumePending = true
			q.Input = nil
			q.ExpectedPrefix, q.PrefixDigest = "prefix-1", "prefix-2"
			q.Results = []ToolResult{{ID: first.Tool.ID, Content: []Content{{Type: "inputText", Text: "already executed"}}, Success: true}}
			rpc := &pendingResumeRPC{fakeRPC: &fakeRPC{events: make(chan codexapp.Message, 16), currentTurn: map[string]string{"thread-1": "turn-thread-1"}}, arguments: `{"text":"hello"}`}
			switch mode {
			case "public-text":
				rpc.notification = "item/agentMessage/delta"
			case "terminal":
				rpc.notification = "turn/completed"
			case "error":
				rpc.notification = "error"
			case "arguments-changed":
				rpc.arguments = `{"text":"different"}`
			case "schema-changed":
				q.Tools[0].InputSchema = json.RawMessage(`{"type":"object"}`)
			case "public-id-changed":
				q.Results[0].ID = "foreign"
			case "reply-started", "metadata-missing":
				rec, _, err := store.load(q.Owner)
				if err != nil {
					t.Fatal(err)
				}
				if mode == "reply-started" {
					rec.Pending[0].ReplyStarted = true
				} else {
					rec.Pending = nil
				}
				if err := store.save(rec); err != nil {
					t.Fatal(err)
				}
			}
			fresh, err := New(ctx, rpc, Config{Store: store})
			if err != nil {
				t.Fatal(err)
			}
			defer fresh.Close()
			last, err := fresh.Step(ctx, q)
			if mode == "matching" {
				if err != nil || !last.Done || rpc.responses != 1 || rpc.replyID != `"replacement-rpc"` || len(rpc.resumes) != 1 || rpc.next != 0 || len(rpc.models) != 0 {
					t.Fatalf("restore result=%+v err=%v replies=%d", last, err, rpc.responses)
				}
			} else if err == nil || rpc.responses != 0 || rpc.next != 0 || len(rpc.models) != 0 {
				t.Fatal("unmatched pending call sent a result or started generation", err)
			}
		})
	}
}
