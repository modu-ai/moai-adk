package codexbridge

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"time"

	"github.com/modu-ai/moai-adk/internal/codextools"
)

type pendingRecoveryError string

func (e pendingRecoveryError) Error() string     { return string(e) }
func (e pendingRecoveryError) CauseCode() string { return string(e) }
func (pendingRecoveryError) Unwrap() error       { return ErrRecovery }

func pendingResumeBindings(rec record, q Request) ([]*pending, error) {
	if len(q.Input) != 0 || rec.TurnID == "" || len(rec.Pending) == 0 || len(rec.Pending) != len(q.Results) {
		return nil, pendingRecoveryError("pending_resume_shape")
	}
	results := map[string]string{}
	for _, result := range q.Results {
		hash := sha256.Sum256([]byte(result.ID))
		key := hex.EncodeToString(hash[:])
		if result.ID == "" || results[key] != "" {
			return nil, ErrScope
		}
		results[key] = result.ID
	}
	seen := map[string]bool{}
	var restored []*pending
	for _, b := range rec.Pending {
		id := results[b.PublicIDDigest]
		if b.ReplyStarted || id == "" || b.CallID == "" || seen[b.CallID] || b.NativeTool == "" || b.PublicTool == "" || b.SchemaDigest == "" || len(b.ArgumentsDigest) != 64 {
			return nil, pendingRecoveryError("pending_resume_binding")
		}
		seen[b.CallID] = true
		delete(results, b.PublicIDDigest)
		restored = append(restored, &pending{callID: b.CallID, publicID: id, binding: b})
	}
	return restored, nil
}

// A saved waiting barrier is insufficient on its own. Only a fresh server
// request with matching binding may receive the caller's existing tool result.
func (e *Engine) reattachPending(ctx context.Context, c *conversation, q Request, segment *Segment) error {
	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	c.mu.Lock()
	pendingCalls := append([]*pending(nil), c.pending...)
	c.mu.Unlock()
	refs := []codextools.Reference{}
	seenNames := map[string]bool{}
	for _, p := range pendingCalls {
		if p.binding.Epoch > 0 && !seenNames[p.binding.PublicTool] {
			refs = append(refs, codextools.Reference{Type: "tool_reference", ToolName: p.binding.PublicTool})
			seenNames[p.binding.PublicTool] = true
		}
	}
	if len(refs) > 0 {
		if err := c.registry.Discover(c.owner, refs, q.Tools); err != nil {
			return pendingRecoveryError("pending_resume_discovery")
		}
	}
	var resumed struct {
		Thread struct {
			ID string `json:"id"`
		} `json:"thread"`
	}
	if err := e.rpc.Call(ctx, "thread/resume", map[string]any{"threadId": c.owner.ThreadID}, &resumed); err != nil {
		return err
	}
	if resumed.Thread.ID != c.owner.ThreadID {
		return ErrScope
	}
	matched := 0
	for matched < len(pendingCalls) {
		event, err := e.nextEvent(ctx, c)
		if err != nil {
			return err
		}
		if event.Method != "item/tool/call" {
			// No public output is silently lost while waiting for reissued calls.
			if informationalEvent(event) || event.Method == "thread/started" || event.Method == "turn/started" {
				continue
			}
			if event.Method == "thread/tokenUsage/updated" && len(event.ID) == 0 {
				c.mu.Lock()
				c.observeUsage(event.Params, segment)
				c.mu.Unlock()
				continue
			}
			// Match the ordinary turn consumer's treatment of notifications:
			// unknown notifications carry no supported public output. Never drop
			// known text, terminal/error events or a server request, however.
			if len(event.ID) == 0 && event.Method != "item/agentMessage/delta" && event.Method != "turn/completed" && event.Method != "error" {
				continue
			}
			return pendingRecoveryError("pending_resume_event")
		}
		var call struct {
			ThreadID, TurnID, CallID, Tool string
			Arguments                      json.RawMessage
		}
		if json.Unmarshal(event.Params, &call) != nil || call.ThreadID != c.owner.ThreadID || call.TurnID != c.turn {
			return ErrScope
		}
		var expected *pending
		for _, p := range pendingCalls {
			if p.callID == call.CallID {
				expected = p
				break
			}
		}
		if expected == nil || len(expected.rpcID) != 0 || call.Tool != expected.binding.NativeTool {
			return ErrScope
		}
		invocation, err := c.registry.Begin(c.owner, codextools.Call{TurnID: call.TurnID, CallID: call.CallID, Tool: call.Tool, Arguments: call.Arguments}, q.Tools)
		if err != nil {
			return pendingRecoveryError("pending_resume_schema")
		}
		hash := sha256.Sum256(invocation.Arguments)
		if invocation.Name != expected.binding.PublicTool || invocation.SchemaDigest != expected.binding.SchemaDigest || hex.EncodeToString(hash[:]) != expected.binding.ArgumentsDigest {
			return ErrScope
		}
		c.mu.Lock()
		if c.failure != nil {
			c.mu.Unlock()
			return ErrRecovery
		}
		expected.rpcID = append(json.RawMessage(nil), event.ID...)
		c.mu.Unlock()
		matched++
	}
	c.mu.Lock()
	c.attach = false
	c.mu.Unlock()
	return nil
}
