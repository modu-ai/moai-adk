package codexbridge

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codextools"
)

func TestPendingBindingContainsNoArgumentsResultsOrRPCIdentity(t *testing.T) {
	p := pendingWithBinding(json.RawMessage(`"PRIVATE_RPC"`), "call", "public", "native", codextools.Invocation{Name: "public-tool", Arguments: json.RawMessage(`{"text":"PRIVATE_ARGUMENT"}`), SchemaDigest: "schema", Epoch: 3})
	raw, err := json.Marshal(p.binding)
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(raw), "PRIVATE") || p.binding.ArgumentsDigest == "" || p.binding.PublicIDDigest == "" || p.binding.Epoch != 3 {
		t.Fatalf("unsafe or incomplete binding: %s", raw)
	}
}

func TestPendingBindingPersistsBeforeReplyAndMarksUncertainDelivery(t *testing.T) {
	for _, fail := range []bool{false, true} {
		name := "completed"
		if fail {
			name = "uncertain"
		}
		t.Run(name, func(t *testing.T) {
			e, rpc, store := fixture(t)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			q := request("pending-binding")
			first, err := e.Step(ctx, q)
			if err != nil || first.Tool == nil {
				t.Fatal(first, err)
			}
			rec, found, err := store.load(q.Owner)
			if err != nil || !found || len(rec.Pending) != 1 {
				t.Fatal("missing durable pending binding", err)
			}
			binding := rec.Pending[0]
			digest := sha256.Sum256(first.Tool.Arguments)
			publicDigest := sha256.Sum256([]byte(first.Tool.ID))
			if binding.PublicIDDigest != hex.EncodeToString(publicDigest[:]) || binding.PublicTool != first.Tool.Name || binding.CallID != rec.CallID || binding.ArgumentsDigest != hex.EncodeToString(digest[:]) || binding.SchemaDigest == "" || binding.NativeTool == "" || binding.ReplyStarted {
				t.Fatal("incorrect pending binding")
			}
			rpc.respondFailure = func() error {
				rec, _, err := store.load(q.Owner)
				if err != nil || rec.Phase != "responding" || len(rec.Pending) != 1 || !rec.Pending[0].ReplyStarted {
					t.Error("RPC response began before durable uncertain-delivery marker")
				}
				if fail {
					return io.EOF
				}
				return nil
			}
			// The fixture override returns before terminal events; only use it
			// on the failure branch. Validate the normal completion separately.
			if !fail {
				rpc.respondFailure = nil
			}
			q.Input = nil
			q.ExpectedPrefix = "prefix-1"
			q.PrefixDigest = "prefix-2"
			q.Results = []ToolResult{{ID: first.Tool.ID, Content: []Content{{Type: "inputText", Text: "done"}}, Success: true}}
			_, err = e.Step(ctx, q)
			if fail && !errors.Is(err, io.EOF) || !fail && err != nil {
				t.Fatal(err)
			}
			rec, _, err = store.load(q.Owner)
			if err != nil {
				t.Fatal(err)
			}
			if fail {
				if rec.Phase != "failed" || len(rec.Pending) != 1 || !rec.Pending[0].ReplyStarted {
					t.Fatal("uncertain reply evidence lost")
				}
			} else if rec.Phase != "idle" || len(rec.Pending) != 0 {
				t.Fatal("completed pending binding retained")
			}
		})
	}
}
