package codexbridge

import (
	"context"
	"encoding/json"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codexapp"
)

type batchResumeRPC struct {
	*fakeRPC
	issued  []codexapp.Message
	replies map[string]string
}

func (f *batchResumeRPC) Call(ctx context.Context, method string, params any, out any) error {
	if err := f.fakeRPC.Call(ctx, method, params, out); err != nil {
		return err
	}
	if method == "thread/resume" {
		for _, message := range f.issued {
			f.events <- message
		}
	}
	return nil
}

func (f *batchResumeRPC) Respond(ctx context.Context, id json.RawMessage, result any) error {
	f.replies[string(id)] = result.(map[string]any)["contentItems"].([]Content)[0].Text
	if len(f.replies) == 2 {
		return f.fakeRPC.Respond(ctx, json.RawMessage(`"thread-1"`), result)
	}
	return nil
}

func TestPendingResumeBatchValidatesAllBeforeAnyReply(t *testing.T) {
	for _, mode := range []string{"reverse-order", "duplicate-call", "second-arguments-changed", "second-missing"} {
		t.Run(mode, func(t *testing.T) {
			e, original, store := fixture(t)
			second := codexapp.Message{ID: json.RawMessage(`"second-rpc"`), Method: "item/tool/call", Params: json.RawMessage(`{"threadId":"thread-1","turnId":"turn-thread-1","callId":"second-call","tool":"echo","arguments":{"text":"second"}}`)}
			var first codexapp.Message
			original.transform = func(event codexapp.Message) codexapp.Message { first = event; original.events <- event; return second }
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			q := request("resume-batch")
			segment, err := e.Step(ctx, q)
			if err != nil || len(segment.Tools) != 2 {
				t.Fatal("two-tool boundary unavailable", err)
			}
			e.Close()
			first.ID, second.ID = json.RawMessage(`"new-first"`), json.RawMessage(`"new-second"`)
			rpc := &batchResumeRPC{fakeRPC: &fakeRPC{events: make(chan codexapp.Message, 16), currentTurn: map[string]string{"thread-1": "turn-thread-1"}}, issued: []codexapp.Message{second, first}, replies: map[string]string{}}
			switch mode {
			case "duplicate-call":
				rpc.issued = []codexapp.Message{first, first}
			case "second-arguments-changed":
				second.Params = json.RawMessage(`{"threadId":"thread-1","turnId":"turn-thread-1","callId":"second-call","tool":"echo","arguments":{"text":"changed"}}`)
				rpc.issued = []codexapp.Message{first, second}
			case "second-missing":
				rpc.issued = []codexapp.Message{first}
			}
			fresh, err := New(ctx, rpc, Config{Store: store})
			if err != nil {
				t.Fatal(err)
			}
			defer fresh.Close()
			q.ResumePending, q.Input, q.ExpectedPrefix, q.PrefixDigest = true, nil, "prefix-1", "prefix-2"
			q.Results = []ToolResult{{ID: segment.Tools[1].ID, Content: []Content{{Type: "inputText", Text: "second-result"}}, Success: true}, {ID: segment.Tools[0].ID, Content: []Content{{Type: "inputText", Text: "first-result"}}, Success: true}}
			last, err := fresh.Step(ctx, q)
			if mode == "reverse-order" {
				if err != nil || !last.Done || len(rpc.replies) != 2 || rpc.replies[`"new-first"`] != "first-result" || rpc.replies[`"new-second"`] != "second-result" {
					t.Fatal("batch mapping lost", err, rpc.replies)
				}
			} else if err == nil || len(rpc.replies) != 0 {
				t.Fatal("partially verified batch was sent", err, rpc.replies)
			}
			if rpc.next != 0 || len(rpc.models) != 0 {
				t.Fatal("batch recovery started new generation")
			}
		})
	}
}
