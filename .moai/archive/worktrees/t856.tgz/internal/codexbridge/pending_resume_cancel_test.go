package codexbridge

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codexapp"
)

type cancelPendingResumeRPC struct {
	*fakeRPC
	entered chan struct{}
	waitRPC bool
}

func (r *cancelPendingResumeRPC) Call(ctx context.Context, method string, params any, out any) error {
	if err := r.fakeRPC.Call(ctx, method, params, out); err != nil {
		return err
	}
	if method == "thread/resume" {
		close(r.entered)
		if r.waitRPC {
			<-ctx.Done()
			return ctx.Err()
		}
	}
	return nil
}

func TestPendingResumeCancellationDoesNotSendOrReplayResult(t *testing.T) {
	for _, mode := range []string{"resume-rpc", "reissued-call-wait"} {
		t.Run(mode, func(t *testing.T) {
			original, _, store := fixture(t)
			deadline, stop := context.WithTimeout(context.Background(), 4*time.Second)
			defer stop()
			q := request("cancel-pending-resume")
			first, err := original.Step(deadline, q)
			if err != nil || first.Tool == nil {
				t.Fatal(first, err)
			}
			original.Close()
			q.ResumePending, q.Input = true, nil
			q.ExpectedPrefix, q.PrefixDigest = "prefix-1", "prefix-2"
			q.Results = []ToolResult{{ID: first.Tool.ID, Content: []Content{{Type: "inputText", Text: "already executed"}}, Success: true}}
			rpc := &cancelPendingResumeRPC{fakeRPC: &fakeRPC{events: make(chan codexapp.Message, 8)}, entered: make(chan struct{}), waitRPC: mode == "resume-rpc"}
			fresh, err := New(deadline, rpc, Config{Store: store})
			if err != nil {
				t.Fatal(err)
			}
			defer fresh.Close()
			ctx, cancel := context.WithCancel(deadline)
			defer cancel()
			done := make(chan error, 1)
			go func() { _, err := fresh.Step(ctx, q); done <- err }()
			select {
			case <-rpc.entered:
			case <-deadline.Done():
				t.Fatal("resume RPC not reached")
			}
			cancel()
			select {
			case err := <-done:
				if !errors.Is(err, context.Canceled) {
					t.Fatalf("canceled recovery error=%v", err)
				}
			case <-deadline.Done():
				t.Fatal("canceled recovery did not return")
			}
			rec, _, err := store.load(q.Owner)
			if err != nil || rec.Phase != "failed" {
				t.Fatalf("canceled recovery barrier phase=%s err=%v", rec.Phase, err)
			}
			if _, err := fresh.Step(deadline, q); err == nil {
				t.Fatal("canceled barrier replayed an already executed result")
			}
			rpc.mu.Lock()
			defer rpc.mu.Unlock()
			if rpc.responses != 0 || rpc.next != 0 || len(rpc.models) != 0 || len(rpc.resumes) != 1 || len(rpc.interrupts) != 1 || rpc.interrupts[0] != "thread-1" {
				t.Fatalf("cancel boundary replies=%d starts=%d models=%v resumes=%v interrupts=%v", rpc.responses, rpc.next, rpc.models, rpc.resumes, rpc.interrupts)
			}
		})
	}
}
