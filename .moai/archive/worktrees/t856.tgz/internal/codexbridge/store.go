package codexbridge

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sync"

	"github.com/modu-ai/moai-adk/internal/atomicfile"
	"github.com/modu-ai/moai-adk/internal/codexapp"
	"github.com/modu-ai/moai-adk/internal/codextools"
)

// FileStore records recovery barriers, never credentials, reasoning or tool
// results. Its directory must be protected by the owner's App Server profile
// lease for the Engine lifetime; separate processes must not share a store.
// Since AS4 an idle barrier carries the owned thread identity and persists the
// pinned model, working directory and completed public prefix, so a new Engine
// can resume it through thread/resume. Barriers captured mid-turn (waiting,
// active, responding, starting, failed, canceled) stay non-resumable: an
// uncertain tool call or an old RPC identity is never replayed or re-executed.
// Legacy AS3 records (schema below storeSchema) are rejected on resume, never
// migrated: they deliberately omit the pinned binding fields a resume needs.
type FileStore struct {
	mu  sync.Mutex
	dir string
}

type Barrier struct {
	Phase, Prefix, Model, CWD string
}

const storeSchema = 2

type record struct {
	Schema                        int
	Owner                         codextools.Binding
	Phase, TurnID, CallID, Prefix string
	Model, CWD                    string
	// Optional for schema-2 compatibility. Older idle barriers update the
	// thread's developer instructions once when next attached.
	InstructionDigest string           `json:",omitempty"`
	Pending           []pendingBinding `json:",omitempty"`
}

// Recovery evidence only: no connection-local RPC IDs, arguments or results.
// Existing resume policy still rejects incomplete barriers. ReplyStarted means
// delivery can be uncertain and must never be interpreted as safe to replay.
type pendingBinding struct {
	CallID, PublicIDDigest, NativeTool, PublicTool string
	ArgumentsDigest, SchemaDigest                  string
	Epoch                                          uint64
	ReplyStarted                                   bool
}

func OpenStore(dir string) (*FileStore, error) {
	resolved, err := filepath.EvalSymlinks(dir)
	if err != nil {
		return nil, err
	}
	if err = codexapp.ValidatePrivatePath(resolved, true); err != nil {
		return nil, err
	}
	return &FileStore{dir: resolved}, nil
}
func storeKey(owner codextools.Binding) string {
	sum := sha256.Sum256([]byte(owner.AccountScope + "\x00" + owner.ConversationID))
	return hex.EncodeToString(sum[:])
}
func (s *FileStore) exists(owner codextools.Binding) (bool, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := codexapp.ValidatePrivatePath(s.dir, true); err != nil {
		return false, err
	}
	path := filepath.Join(s.dir, storeKey(owner)+".json")
	_, err := os.Lstat(path)
	if errors.Is(err, os.ErrNotExist) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	if err = codexapp.ValidatePrivatePath(path, false); err != nil {
		return false, err
	}
	return true, nil
}
func (s *FileStore) save(r record) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := codexapp.ValidatePrivatePath(s.dir, true); err != nil {
		return err
	}
	r.Schema = storeSchema
	raw, err := json.Marshal(r)
	if err != nil {
		return err
	}
	path := filepath.Join(s.dir, storeKey(r.Owner)+".json")
	if _, err := os.Lstat(path); err == nil {
		if err = codexapp.ValidatePrivatePath(path, false); err != nil {
			return err
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return err
	}
	file, err := os.CreateTemp(s.dir, ".phase-*")
	if err != nil {
		return err
	}
	tmp := file.Name()
	defer func() { _ = os.Remove(tmp) }() // temp file cleanup; the atomic replace owns the live file
	if _, err = file.Write(raw); err == nil {
		err = file.Sync()
	}
	closeErr := file.Close()
	if err != nil {
		return err
	}
	if closeErr != nil {
		return closeErr
	}
	if err = codexapp.ValidatePrivatePath(tmp, false); err != nil {
		return err
	}
	if err = atomicfile.Replace(tmp, path); err != nil {
		return err
	}
	if err = codexapp.ValidatePrivatePath(path, false); err != nil {
		return err
	}
	got, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if !bytes.Equal(got, raw) {
		return errors.New("bridge state readback mismatch")
	}
	if runtime.GOOS != "windows" {
		dir, err := os.Open(s.dir)
		if err != nil {
			return err
		}
		err = dir.Sync()
		closeErr = dir.Close()
		if err != nil {
			return err
		}
		return closeErr
	}
	return nil
}

// load reads the barrier record for an owner binding. found is false only when
// no record exists; a record that fails validation or decoding is an error.
func (s *FileStore) load(owner codextools.Binding) (r record, found bool, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err = codexapp.ValidatePrivatePath(s.dir, true); err != nil {
		return r, false, err
	}
	path := filepath.Join(s.dir, storeKey(owner)+".json")
	raw, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return r, false, nil
	}
	if err != nil {
		return r, false, err
	}
	if err = codexapp.ValidatePrivatePath(path, false); err != nil {
		return r, false, err
	}
	if err = json.Unmarshal(raw, &r); err != nil {
		return r, true, err
	}
	return r, true, nil
}

func (s *FileStore) Barrier(owner codextools.Binding) (Barrier, bool, error) {
	r, found, err := s.load(owner)
	if err != nil || !found {
		return Barrier{}, found, err
	}
	if r.Schema != storeSchema {
		return Barrier{}, true, fmt.Errorf("%w: barrier predates the resumable schema", ErrRecovery)
	}
	if r.Owner.ConversationID != owner.ConversationID || r.Owner.AccountScope != owner.AccountScope {
		return Barrier{}, true, ErrScope
	}
	return Barrier{Phase: r.Phase, Prefix: r.Prefix, Model: r.Model, CWD: r.CWD}, true, nil
}

// removeCompleted deletes only an acknowledged idle ephemeral owner's barrier.
// The profile lease excludes concurrent external writers; verify identity and
// file permissions again before removing the exact hashed regular file.
func (s *FileStore) removeCompleted(owner codextools.Binding) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := codexapp.ValidatePrivatePath(s.dir, true); err != nil {
		return err
	}
	path := filepath.Join(s.dir, storeKey(owner)+".json")
	if err := codexapp.ValidatePrivatePath(path, false); err != nil {
		return err
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	var r record
	if json.Unmarshal(raw, &r) != nil || r.Schema != storeSchema || r.Owner != owner || r.Phase != "idle" {
		return ErrScope
	}
	if err = os.Remove(path); err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		return nil
	}
	dir, err := os.Open(s.dir)
	if err != nil {
		return err
	}
	syncErr := dir.Sync()
	closeErr := dir.Close()
	if syncErr != nil {
		return syncErr
	}
	return closeErr
}
