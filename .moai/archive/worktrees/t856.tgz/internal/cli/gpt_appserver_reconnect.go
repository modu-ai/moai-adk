package cli

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/json"
	"net/http"
	"sync"
	"time"
)

// Rebuild only between HTTP requests and only after a terminal connection
// failure. Never replay a request, response, tool result or in-flight turn.
type managedGPTRecoveringHandler struct {
	mu           sync.RWMutex
	current      *gatewayOwnedHandler
	build        func(context.Context) (*gatewayOwnedHandler, error)
	closed       bool
	closeErr     error
	retryAfter   time.Time
	authenticate func(*http.Request) bool
}

func newGPTAppServerGatewayHandler(raw json.RawMessage) (http.Handler, error) {
	// Retain our own immutable configuration for later reauthentication.
	payload := append(json.RawMessage(nil), raw...)
	p, _, err := decodeGPTAppServerPayload(payload)
	if err != nil {
		return nil, errGatewayFactory
	}
	tokenHash := sha256.Sum256([]byte("Bearer " + p.SessionToken))
	build := func(ctx context.Context) (*gatewayOwnedHandler, error) {
		startup, cancel := context.WithTimeout(ctx, 15*time.Second)
		defer cancel()
		return newGPTAppServerGatewayInstance(startup, payload)
	}
	initial, err := build(context.Background())
	if err != nil {
		return nil, err
	}
	recovering := &managedGPTRecoveringHandler{current: initial, build: build, authenticate: func(r *http.Request) bool {
		values := r.Header.Values("Authorization")
		if len(values) != 1 {
			return false
		}
		provided := sha256.Sum256([]byte(values[0]))
		return subtle.ConstantTimeCompare(provided[:], tokenHash[:]) == 1
	}}
	ctx, cancel := context.WithCancel(context.Background())
	return &gatewayOwnedHandler{Handler: recovering, ctx: ctx, cancel: cancel, managed: recovering.Close}, nil
}

func (h *managedGPTRecoveringHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if h.authenticate == nil || !h.authenticate(r) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		_, _ = w.Write([]byte("{\"type\":\"error\",\"error\":{\"type\":\"authentication_error\",\"message\":\"Unauthorized\"}}\n"))
		return
	}
	h.mu.RLock()
	if !h.closed && h.current != nil && h.current.connectionErr() == nil {
		defer h.mu.RUnlock()
		h.current.ServeHTTP(w, r)
		return
	}
	h.mu.RUnlock()
	if !h.reconnect(r.Context()) {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Retry-After", "1")
		w.WriteHeader(http.StatusServiceUnavailable)
		_, _ = w.Write([]byte("{\"type\":\"error\",\"error\":{\"type\":\"api_error\",\"message\":\"appserver_connection_unavailable\"}}\n"))
		return
	}
	h.mu.RLock()
	defer h.mu.RUnlock()
	if h.closed || h.current == nil {
		http.Error(w, "gateway closed", http.StatusServiceUnavailable)
		return
	}
	h.current.ServeHTTP(w, r)
}

func (h *managedGPTRecoveringHandler) reconnect(ctx context.Context) bool {
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.closed || h.closeErr != nil || ctx.Err() != nil {
		return false
	}
	if h.current != nil && h.current.connectionErr() == nil {
		return true
	}
	if time.Now().Before(h.retryAfter) {
		return false
	}
	h.retryAfter = time.Now().Add(time.Second)
	if h.current != nil {
		// RWMutex has drained all requests before closing the old receipt lease.
		h.closeErr = h.current.Close()
		h.current = nil
		if h.closeErr != nil {
			return false
		}
	}
	next, err := h.build(ctx)
	if err != nil {
		return false
	}
	h.current = next
	return true
}

func (h *managedGPTRecoveringHandler) Close() error {
	h.mu.Lock()
	defer h.mu.Unlock()
	if !h.closed {
		h.closed = true
		if h.current != nil {
			h.closeErr = h.current.Close()
		}
	}
	return h.closeErr
}
