package cli

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func recoveringTestInstance(dead *atomic.Bool, serve http.HandlerFunc, closeFn func() error) *gatewayOwnedHandler {
	ctx, cancel := context.WithCancel(context.Background())
	return &gatewayOwnedHandler{Handler: serve, ctx: ctx, cancel: cancel, managed: closeFn, connectionErr: func() error {
		if dead.Load() {
			return io.EOF
		}
		return nil
	}}
}

func TestGPTProductionReconnectAfterSocketDisconnect(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix transport fixture; Windows exclusive transport requires separate runtime coverage")
	}
	home, err := filepath.EvalSymlinks(sharedGPTFixtureHome(t))
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(home, 0700); err != nil {
		t.Fatal(err)
	}
	t.Setenv("MOAI_HOME", home)
	binDir, protocolLog := installProductionWiringFakeCodex(t)
	t.Setenv("PATH", binDir+string(os.PathListSeparator)+os.Getenv("PATH"))
	disconnect := startSharedGPTWiringFixture(t, home, protocolLog)
	payload, err := marshalGatewayPrivatePayload("reconnect-test", gatewayGPTModels())
	if err != nil {
		t.Fatal(err)
	}
	handler, err := newGPTAppServerGatewayHandler(payload)
	if err != nil {
		t.Fatal(err)
	}
	defer handler.(io.Closer).Close()
	recovering := handler.(*gatewayOwnedHandler).Handler.(*managedGPTRecoveringHandler)
	disconnect()
	deadline := time.NewTimer(time.Second)
	defer deadline.Stop()
	ticker := time.NewTicker(time.Millisecond)
	defer ticker.Stop()
	for recovering.current.connectionErr() == nil {
		select {
		case <-deadline.C:
			t.Fatal("closed socket was not observed")
		case <-ticker.C:
		}
	}
	r := httptest.NewRequest("GET", "/v1/models", nil)
	r.Header.Set("Authorization", "Bearer reconnect-test")
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, r)
	if w.Code != 200 {
		t.Fatalf("reconnect response=%d %s", w.Code, w.Body.String())
	}
	raw, err := os.ReadFile(protocolLog)
	if err != nil {
		t.Fatal(err)
	}
	counts := map[string]int{}
	for _, line := range strings.Split(strings.TrimSpace(string(raw)), "\n") {
		var event struct {
			Method string `json:"method"`
		}
		if err := json.Unmarshal([]byte(line), &event); err != nil {
			t.Fatal(err)
		}
		counts[event.Method]++
	}
	if counts["initialize"] != 2 || counts["account/read"] != 2 || counts["thread/start"] != 0 || counts["turn/start"] != 0 {
		t.Fatalf("unexpected reconnect RPCs: %v", counts)
	}
	t.Log("socket disconnect recovered; initialize=2 account/read=2 thread/start=0 turn/start=0")
}

func TestGPTReconnectNeverReplaysFailedRequest(t *testing.T) {
	var dead, healthy atomic.Bool
	calls, closes, builds := 0, 0, 0
	old := recoveringTestInstance(&dead, func(w http.ResponseWriter, r *http.Request) {
		calls++
		dead.Store(true)
		w.WriteHeader(502)
	}, func() error { closes++; return nil })
	h := &managedGPTRecoveringHandler{current: old, authenticate: func(*http.Request) bool { return true }, build: func(context.Context) (*gatewayOwnedHandler, error) {
		builds++
		return recoveringTestInstance(&healthy, func(w http.ResponseWriter, r *http.Request) {
			calls++
			body, _ := io.ReadAll(r.Body)
			if string(body) != "second-request" {
				t.Errorf("replayed or modified request: %q", body)
			}
			w.WriteHeader(200)
		}, nil), nil
	}}
	defer h.Close()
	first := httptest.NewRecorder()
	h.ServeHTTP(first, httptest.NewRequest("POST", "/v1/messages", strings.NewReader("first-request")))
	if first.Code != 502 || calls != 1 || builds != 0 {
		t.Fatal("failed request was replayed")
	}
	second := httptest.NewRecorder()
	h.ServeHTTP(second, httptest.NewRequest("POST", "/v1/messages", strings.NewReader("second-request")))
	if second.Code != 200 || calls != 2 || closes != 1 || builds != 1 {
		t.Fatalf("status=%d calls=%d closes=%d builds=%d", second.Code, calls, closes, builds)
	}
}

func TestGPTReconnectConcurrentRequestsBuildOnce(t *testing.T) {
	var dead, healthy atomic.Bool
	dead.Store(true)
	var builds, closes, calls atomic.Int32
	h := &managedGPTRecoveringHandler{authenticate: func(*http.Request) bool { return true }}
	h.current = recoveringTestInstance(&dead, func(http.ResponseWriter, *http.Request) { t.Error("dead instance served") }, func() error { closes.Add(1); return nil })
	h.build = func(context.Context) (*gatewayOwnedHandler, error) {
		builds.Add(1)
		return recoveringTestInstance(&healthy, func(w http.ResponseWriter, _ *http.Request) { calls.Add(1); w.WriteHeader(200) }, nil), nil
	}
	defer h.Close()
	var wg sync.WaitGroup
	for range 20 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			w := httptest.NewRecorder()
			h.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", nil))
			if w.Code != 200 {
				t.Errorf("status=%d", w.Code)
			}
		}()
	}
	wg.Wait()
	if builds.Load() != 1 || closes.Load() != 1 || calls.Load() != 20 {
		t.Fatalf("builds=%d closes=%d calls=%d", builds.Load(), closes.Load(), calls.Load())
	}
}

func TestGPTReconnectKeepsPolicyRejectionsAndAuthBoundary(t *testing.T) {
	var alive atomic.Bool
	builds := 0
	h := &managedGPTRecoveringHandler{authenticate: func(r *http.Request) bool { return r.Header.Get("Authorization") == "fixture" }, build: func(context.Context) (*gatewayOwnedHandler, error) { builds++; return nil, errors.New("PRIVATE") }}
	h.current = recoveringTestInstance(&alive, func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(400) }, nil)
	defer h.Close()
	r := httptest.NewRequest("POST", "/v1/messages", nil)
	r.Header.Set("Authorization", "fixture")
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 400 || builds != 0 {
		t.Fatal("policy rejection triggered recovery")
	}
	alive.Store(true)
	w = httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", nil))
	if w.Code != 401 || builds != 0 {
		t.Fatal("unauthenticated request started recovery")
	}
	for range 2 {
		w = httptest.NewRecorder()
		h.ServeHTTP(w, r.Clone(context.Background()))
		if w.Code != 503 || strings.Contains(w.Body.String(), "PRIVATE") {
			t.Fatal("unsafe reconnect failure")
		}
	}
	if builds != 1 {
		t.Fatal("reconnect cooldown missing")
	}
}

func TestGPTReconnectStopsAfterCloseFailure(t *testing.T) {
	var dead atomic.Bool
	dead.Store(true)
	closeFailure := errors.New("fixture close failed")
	builds := 0
	h := &managedGPTRecoveringHandler{authenticate: func(*http.Request) bool { return true }, current: recoveringTestInstance(&dead, nil, func() error { return closeFailure }), build: func(context.Context) (*gatewayOwnedHandler, error) { builds++; return nil, nil }}
	for range 2 {
		w := httptest.NewRecorder()
		h.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", nil))
		if w.Code != 503 {
			t.Fatal(w.Code)
		}
	}
	if builds != 0 || !errors.Is(h.Close(), closeFailure) || !errors.Is(h.Close(), closeFailure) {
		t.Fatal("cleanup failure was discarded")
	}
}

func TestGPTReconnectCloseCancelsActiveRequest(t *testing.T) {
	var alive atomic.Bool
	started, finished := make(chan struct{}), make(chan struct{})
	inner := recoveringTestInstance(&alive, func(_ http.ResponseWriter, r *http.Request) {
		close(started)
		<-r.Context().Done()
	}, nil)
	recovering := &managedGPTRecoveringHandler{current: inner, authenticate: func(*http.Request) bool { return true }}
	ctx, cancel := context.WithCancel(context.Background())
	outer := &gatewayOwnedHandler{Handler: recovering, ctx: ctx, cancel: cancel, managed: recovering.Close}
	t.Cleanup(func() { _ = outer.Close() })
	go func() {
		defer close(finished)
		outer.ServeHTTP(httptest.NewRecorder(), httptest.NewRequest("POST", "/v1/messages", nil))
	}()
	select {
	case <-started:
	case <-time.After(time.Second):
		t.Fatal("request did not start")
	}
	closed := make(chan error, 1)
	go func() { closed <- outer.Close() }()
	select {
	case err := <-closed:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("close deadlocked with active request")
	}
	select {
	case <-finished:
	case <-time.After(time.Second):
		t.Fatal("request did not finish")
	}
}

func TestGPTReconnectCloseCancelsRebuild(t *testing.T) {
	var dead atomic.Bool
	dead.Store(true)
	started, finished := make(chan struct{}), make(chan struct{})
	var closes atomic.Int32
	recovering := &managedGPTRecoveringHandler{
		authenticate: func(*http.Request) bool { return true },
		current:      recoveringTestInstance(&dead, nil, func() error { closes.Add(1); return nil }),
		build: func(ctx context.Context) (*gatewayOwnedHandler, error) {
			close(started)
			<-ctx.Done()
			return nil, ctx.Err()
		},
	}
	ctx, cancel := context.WithCancel(context.Background())
	outer := &gatewayOwnedHandler{Handler: recovering, ctx: ctx, cancel: cancel, managed: recovering.Close}
	t.Cleanup(func() { _ = outer.Close() })
	w := httptest.NewRecorder()
	go func() {
		defer close(finished)
		outer.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", nil))
	}()
	select {
	case <-started:
	case <-time.After(time.Second):
		t.Fatal("rebuild did not start")
	}
	closed := make(chan error, 1)
	go func() { closed <- outer.Close() }()
	select {
	case err := <-closed:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("close did not cancel rebuild")
	}
	<-finished
	if w.Code != 503 || closes.Load() != 1 {
		t.Fatalf("status=%d closes=%d", w.Code, closes.Load())
	}
}

func TestGPTReconnectRecoversAfterTransientBuildFailure(t *testing.T) {
	var dead, alive atomic.Bool
	dead.Store(true)
	builds, closes, calls := 0, 0, 0
	h := &managedGPTRecoveringHandler{
		authenticate: func(*http.Request) bool { return true },
		current:      recoveringTestInstance(&dead, nil, func() error { closes++; return nil }),
		build: func(context.Context) (*gatewayOwnedHandler, error) {
			builds++
			if builds == 1 {
				return nil, io.EOF
			}
			return recoveringTestInstance(&alive, func(w http.ResponseWriter, r *http.Request) {
				calls++
				body, _ := io.ReadAll(r.Body)
				if string(body) != "new-request" {
					t.Error("failed request replayed")
				}
				w.WriteHeader(200)
			}, nil), nil
		},
	}
	defer h.Close()
	w := httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", strings.NewReader("failed-request")))
	if w.Code != 503 || w.Header().Get("Retry-After") != "1" || builds != 1 || closes != 1 || calls != 0 {
		t.Fatal("failed rebuild contract changed")
	}
	// Advance only the cooldown boundary, without sleeping or retrying old input.
	h.retryAfter = time.Now().Add(-time.Second)
	w = httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("POST", "/v1/messages", strings.NewReader("new-request")))
	if w.Code != 200 || builds != 2 || closes != 1 || calls != 1 {
		t.Fatalf("status=%d builds=%d closes=%d calls=%d", w.Code, builds, closes, calls)
	}
}
