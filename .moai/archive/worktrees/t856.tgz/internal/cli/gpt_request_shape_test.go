package cli

import (
	"crypto/sha256"
	"encoding/json"
	"sort"
	"strings"
	"testing"
)

type gptProbeRequestShape struct {
	fields   map[string][32]byte
	messages [][32]byte
	roles    []string
}

func TestGPTProbeShapeDoesNotExposeContent(t *testing.T) {
	before := gptProbeShape([]byte(`{"system":"PRIVATE-A","messages":[{"role":"user","content":"PRIVATE-B"}]}`))
	after := gptProbeShape([]byte(`{"system":"PRIVATE-C","PRIVATE-KEY":"PRIVATE-D","messages":[{"role":"user","content":"PRIVATE-B"},{"role":"system","content":[{"type":"text","text":"PRIVATE-E"}]}]}`))
	fields, prefix, oldRoles, newRoles := gptProbeShapeDifference(before, after)
	if fields != "system" || prefix != 1 || oldRoles != "user/scalar" || newRoles != "user/scalar,system/text" || strings.Contains(fields+oldRoles+newRoles, "PRIVATE") {
		t.Fatal("request-shape comparison leaked content or lost its structural delta")
	}
}

func gptProbeShape(raw []byte) gptProbeRequestShape {
	out := gptProbeRequestShape{fields: map[string][32]byte{}}
	var root map[string]json.RawMessage
	if json.Unmarshal(raw, &root) != nil {
		return out
	}
	for key, value := range root {
		if key != "messages" {
			out.fields[key] = sha256.Sum256(value)
		}
	}
	var messages []json.RawMessage
	_ = json.Unmarshal(root["messages"], &messages)
	for _, raw := range messages {
		var m struct {
			Role    string
			Content json.RawMessage
		}
		_ = json.Unmarshal(raw, &m)
		role := "unknown"
		if m.Role == "user" || m.Role == "assistant" || m.Role == "system" {
			role = m.Role
		}
		var blocks []struct{ Type string }
		if json.Unmarshal(m.Content, &blocks) == nil {
			for _, b := range blocks {
				switch b.Type {
				case "text", "tool_use", "tool_result", "image", "thinking", "redacted_thinking":
					role += "/" + b.Type
				}
			}
		} else {
			role += "/scalar"
		}
		out.messages = append(out.messages, sha256.Sum256(raw))
		out.roles = append(out.roles, role)
	}
	return out
}

func gptProbeShapeDifference(before, after gptProbeRequestShape) (string, int, string, string) {
	changed := []string{}
	// Only known field names are emitted, never caller-controlled names or values.
	for _, key := range []string{"model", "system", "tools", "metadata", "max_tokens", "thinking", "output_config", "context_management"} {
		if before.fields[key] != after.fields[key] {
			changed = append(changed, key)
		}
	}
	sort.Strings(changed)
	matched := 0
	for matched < len(before.messages) && matched < len(after.messages) && before.messages[matched] == after.messages[matched] {
		matched++
	}
	return strings.Join(changed, ","), matched, strings.Join(before.roles, ","), strings.Join(after.roles, ",")
}
