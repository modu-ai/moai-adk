package cli

import (
	"encoding/xml"
	"strings"
	"testing"
)

type gptForkCompletion struct {
	TaskID, CallID, Result string
}

func countGPTForkMatches(children map[string]bool, expected map[string]string, completions map[string]gptForkCompletion) int {
	matched := make(map[string]bool)
	for taskID, completion := range completions {
		want, known := expected[completion.CallID]
		if taskID == completion.TaskID && children[taskID] && known && completion.Result == want {
			matched[completion.CallID] = true
		}
	}
	return len(matched)
}

func TestGPTForkCompletionRejectsCrossedResults(t *testing.T) {
	children := map[string]bool{"left-child": true, "right-child": true}
	expected := map[string]string{"left-call": "marker:left", "right-call": "marker:right"}
	for _, mode := range []string{"matching", "swapped-results", "foreign-child", "repeated-call"} {
		t.Run(mode, func(t *testing.T) {
			left := gptForkCompletion{"left-child", "left-call", "marker:left"}
			right := gptForkCompletion{"right-child", "right-call", "marker:right"}
			want := 2
			switch mode {
			case "swapped-results":
				left.Result, right.Result = right.Result, left.Result
				want = 0
			case "foreign-child":
				right.TaskID = "foreign"
				want = 1
			case "repeated-call":
				right.CallID, right.Result = left.CallID, left.Result
				want = 1
			}
			if got := countGPTForkMatches(children, expected, map[string]gptForkCompletion{left.TaskID: left, right.TaskID: right}); got != want {
				t.Fatalf("matches=%d want=%d", got, want)
			}
		})
	}
}

func splitGPTForkNotifications(text string) []string {
	const open, close = "<task-notification>", "</task-notification>"
	var out []string
	for {
		start := strings.Index(text, open)
		if start < 0 {
			return out
		}
		text = text[start:]
		end := strings.Index(text, close)
		if end < 0 {
			return out
		}
		end += len(close)
		out = append(out, text[:end])
		text = text[end:]
	}
}

func TestGPTForkCompletionBatchPreservesBothNotifications(t *testing.T) {
	a := "<task-notification><task-id>a</task-id><tool-use-id>call-a</tool-use-id><status>completed</status><result>A</result></task-notification>"
	b := strings.ReplaceAll(strings.ReplaceAll(a, ">a<", ">b<"), "call-a", "call-b")
	batch := splitGPTForkNotifications("prefix" + a + "\n" + b + "suffix")
	if len(batch) != 2 {
		t.Fatalf("notifications=%d", len(batch))
	}
	first, ok1 := parseGPTForkCompletion(batch[0])
	last, ok2 := parseGPTForkCompletion(batch[1])
	if !ok1 || !ok2 || first.TaskID != "a" || last.TaskID != "b" || first.CallID == last.CallID {
		t.Fatal("batch correlation lost")
	}
}

// Parse the host-generated completion envelope, not marker text in a prompt or
// summary. This is a test observer, not a production authorization decision.
func parseGPTForkCompletion(text string) (gptForkCompletion, bool) {
	const open, close = "<task-notification>", "</task-notification>"
	start := strings.Index(text, open)
	if start < 0 {
		return gptForkCompletion{}, false
	}
	end := strings.Index(text[start:], close)
	if end < 0 {
		return gptForkCompletion{}, false
	}
	var n struct {
		TaskIDs  []string `xml:"task-id"`
		CallIDs  []string `xml:"tool-use-id"`
		Statuses []string `xml:"status"`
		Results  []string `xml:"result"`
	}
	if xml.Unmarshal([]byte(text[start:start+end+len(close)]), &n) != nil || len(n.TaskIDs) != 1 || len(n.CallIDs) != 1 || len(n.Statuses) != 1 || len(n.Results) != 1 || n.TaskIDs[0] == "" || n.CallIDs[0] == "" || n.Statuses[0] != "completed" {
		return gptForkCompletion{}, false
	}
	return gptForkCompletion{TaskID: n.TaskIDs[0], CallID: n.CallIDs[0], Result: strings.TrimSpace(n.Results[0])}, true
}

func TestGPTForkCompletionRequiresCorrelatableCompletedResult(t *testing.T) {
	valid := "<task-notification><task-id>child-a</task-id><tool-use-id>call-a</tool-use-id><status>completed</status><result>HOST_EXECUTED_856</result></task-notification>"
	for name, raw := range map[string]string{
		"valid":          valid,
		"failed":         strings.Replace(valid, "completed", "failed", 1),
		"missing-task":   strings.Replace(valid, "<task-id>child-a</task-id>", "", 1),
		"missing-call":   strings.Replace(valid, "<tool-use-id>call-a</tool-use-id>", "", 1),
		"duplicate-call": strings.Replace(valid, "</tool-use-id>", "</tool-use-id><tool-use-id>foreign</tool-use-id>", 1),
		"summary-only":   strings.ReplaceAll(strings.ReplaceAll(valid, "<result>", "<summary>"), "</result>", "</summary>"),
		"truncated":      strings.TrimSuffix(valid, "</task-notification>"),
		"plain-marker":   "HOST_EXECUTED_856",
	} {
		t.Run(name, func(t *testing.T) {
			got, ok := parseGPTForkCompletion(raw)
			if name == "valid" {
				if !ok || got.TaskID != "child-a" || got.CallID != "call-a" || got.Result != "HOST_EXECUTED_856" {
					t.Fatalf("completion=%+v ok=%t", got, ok)
				}
			} else if ok {
				t.Fatalf("invalid completion admitted: %s", name)
			}
		})
	}
}
