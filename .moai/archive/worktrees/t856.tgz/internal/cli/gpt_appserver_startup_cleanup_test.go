package cli

import (
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"
)

// Check the actual assembly's failure cleanup without owning a live server or
// borrowing operator authentication. The peer acknowledges connection closure.
func checkGPTStartupFailureCleanup(t *testing.T, missingLogin bool) {
	t.Helper()
	if runtime.GOOS == "windows" {
		t.Skip("SPEC-MOAI-GATEWAY-001 AS-022: Unix shared-peer fixture; Windows stdio runtime evidence remains separate")
	}
	home, err := filepath.EvalSymlinks(sharedGPTFixtureHome(t))
	if err != nil {
		t.Fatal(err)
	}
	t.Setenv("MOAI_HOME", home)
	binDir, protocolLog := installProductionWiringFakeCodex(t)
	t.Setenv("PATH", binDir+string(os.PathListSeparator)+os.Getenv("PATH"))
	account := map[string]any{"account": map[string]string{"type": "chatgpt", "planType": "test"}}
	if missingLogin {
		account["account"] = nil
	}
	closed := make(chan struct{}, 1)
	startSharedGPTWiringAccountFixture(t, home, protocolLog, account, closed)
	payload := gatewayPrivatePayload{Version: 1, SessionToken: "private-fixture", ModelIDs: []string{"gpt-5.6-sol"}}
	if !missingLogin {
		// Valid private configuration, but a file occupies the receipt directory.
		// This failure happens after account authorization and Engine creation.
		path := filepath.Join(home, "unavailable-receipts")
		if err := os.WriteFile(path, []byte("fixture"), 0600); err != nil {
			t.Fatal(err)
		}
		id := "11111111-1111-4111-8111-111111111111"
		payload.Conversation = &gatewayPrivateConversation{FamilyID: id, SessionID: id, ReceiptDir: path, CWD: home}
	}
	raw, err := json.Marshal(payload)
	if err != nil {
		t.Fatal(err)
	}
	h, err := productionGatewayHandlerFactory(raw)
	if h != nil {
		_ = h.(io.Closer).Close()
		t.Fatal("failed initialization exposed a usable handler")
	}
	if err == nil {
		t.Fatal("initialization failure was accepted")
	}
	select {
	case <-closed:
	case <-time.After(2 * time.Second):
		t.Fatal("failed initialization retained the App Server connection")
	}
	log, err := os.ReadFile(protocolLog)
	if err != nil {
		t.Fatal(err)
	}
	counts := map[string]int{}
	for _, line := range strings.Split(strings.TrimSpace(string(log)), "\n") {
		var msg struct {
			Method string `json:"method"`
		}
		if err := json.Unmarshal([]byte(line), &msg); err != nil {
			t.Fatal(err)
		}
		counts[msg.Method]++
		switch msg.Method {
		case "initialize", "initialized", "account/read":
		default:
			t.Fatalf("startup failure issued unexpected RPC %q", msg.Method)
		}
	}
	if counts["initialize"] != 1 || counts["account/read"] != 1 {
		t.Fatalf("failure boundary not reached: counts=%v", counts)
	}
	if _, err := os.Stat(filepath.Join(home, "gateway-auth")); !os.IsNotExist(err) {
		t.Fatal("startup touched the legacy authentication store")
	}
	if !missingLogin {
		if _, err := os.Stat(filepath.Join(home, "gpt-appserver", "moai-bridge")); err != nil {
			t.Fatal("late failure did not reach bridge initialization")
		}
	}
}
