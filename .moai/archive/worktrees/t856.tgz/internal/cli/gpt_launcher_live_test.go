package cli

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/paths"
)

// The ordinary launcher may start its persistent shared authentication owner.
// This test never shuts that owner down or copies credentials. Owner termination
// tests remain restricted to an independently authenticated test profile.
func TestGPTLauncherLiveNormalStartup(t *testing.T) {
	if os.Getenv("MOAI_GPT_LAUNCHER_LIVE") != "1" {
		t.Skip("SPEC-MOAI-GATEWAY-001: opt in to actual moai gpt startup and model generation")
	}
	managedGPTLauncherLive(t)
}

// The selected MoAI binary owns its gateway supervisor and Claude child;
// no installed executable is replaced.
func managedGPTLauncherLive(t *testing.T) {
	binary := os.Getenv("MOAI_GPT_LAUNCHER_BINARY")
	if binary == "" {
		t.Skip("set MOAI_GPT_LAUNCHER_BINARY to the built source executable")
	}
	if !filepath.IsAbs(binary) {
		t.Fatal("launcher binary must be absolute")
	}
	binaryBytes, err := os.ReadFile(binary)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("launcher binary sha256=%x", sha256.Sum256(binaryBytes))
	root, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	moaiHome, err := paths.MoaiHome()
	if err != nil {
		t.Fatal(err)
	}
	configDir := filepath.Join(root, "selected")
	projectDir := filepath.Join(root, "project")
	for _, dir := range []string{configDir, filepath.Join(projectDir, ".moai")} {
		if err := os.MkdirAll(dir, 0700); err != nil {
			t.Fatal(err)
		}
	}
	state, err := json.Marshal(map[string]any{"hasCompletedOnboarding": true, "theme": "dark", "projects": map[string]any{projectDir: map[string]bool{"hasTrustDialogAccepted": true}}})
	if err != nil {
		t.Fatal(err)
	}
	for _, dir := range []string{root, configDir} {
		if err := os.WriteFile(filepath.Join(dir, ".claude.json"), state, 0600); err != nil {
			t.Fatal(err)
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 75*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "gpt", "-p", "default", "--print", "--verbose", "--output-format", "stream-json", "--model", "gpt-5.6-sol", "--tools", "Bash", "--allowedTools", "Bash(echo LAUNCHER_TOOL_OK)", "--max-turns", "4", "Call Bash exactly once with echo LAUNCHER_TOOL_OK. After observing its result, reply only LAUNCHER_GATEWAY_OK.")
	cmd.Dir = projectDir
	cmd.Env = []string{"PATH=" + filepath.Dir(binary) + string(os.PathListSeparator) + os.Getenv("PATH"), "HOME=" + root, "USERPROFILE=" + root, "MOAI_HOME=" + moaiHome, "CLAUDE_CONFIG_DIR=" + configDir, "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1", "DISABLE_AUTOUPDATER=1"}
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		diagnostic := stderr.Bytes()
		if len(diagnostic) > 3000 {
			diagnostic = diagnostic[len(diagnostic)-3000:]
		}
		t.Fatalf("real launcher failed: %v stderr=%s", err, diagnostic)
	}
	session, err := verifyGPTLauncherStream(out)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("real moai gpt launcher completed: session=%s Bash calls=1 successful results=1 final=LAUNCHER_GATEWAY_OK", session)
}

func verifyGPTLauncherStream(out []byte) (string, error) {
	type streamEvent struct {
		Type      string `json:"type"`
		Result    string `json:"result"`
		IsError   bool   `json:"is_error"`
		SessionID string `json:"session_id"`
		Message   struct {
			Content []struct {
				Type      string          `json:"type"`
				ID        string          `json:"id"`
				Name      string          `json:"name"`
				ToolUseID string          `json:"tool_use_id"`
				IsError   bool            `json:"is_error"`
				Content   json.RawMessage `json:"content"`
				Input     struct {
					Command string `json:"command"`
				} `json:"input"`
			} `json:"content"`
		} `json:"message"`
	}
	decoder := json.NewDecoder(bytes.NewReader(out))
	callID, session := "", ""
	calls, results, finals := 0, 0, 0
	for {
		var event streamEvent
		if err := decoder.Decode(&event); err == io.EOF {
			break
		} else if err != nil {
			return "", fmt.Errorf("launcher stream JSON: %w", err)
		}
		if event.IsError || event.Type == "error" || finals != 0 {
			return "", fmt.Errorf("launcher error or event after terminal result")
		}
		for _, block := range event.Message.Content {
			switch block.Type {
			case "tool_use":
				calls++
				if event.Type != "assistant" || block.Name != "Bash" || block.Input.Command != "echo LAUNCHER_TOOL_OK" || block.ID == "" {
					return "", fmt.Errorf("unexpected launcher tool call")
				}
				callID = block.ID
			case "tool_result":
				results++
				var content string
				if event.Type != "user" || callID == "" || block.ToolUseID != callID || block.IsError || json.Unmarshal(block.Content, &content) != nil || strings.TrimSpace(content) != "LAUNCHER_TOOL_OK" {
					return "", fmt.Errorf("launcher tool result not successful or correlated")
				}
			}
		}
		if event.Type == "result" {
			finals++
			if calls != 1 || results != 1 || strings.TrimSpace(event.Result) != "LAUNCHER_GATEWAY_OK" || event.SessionID == "" {
				return "", fmt.Errorf("launcher final result incomplete: calls=%d results=%d session_present=%t final=%.512q", calls, results, event.SessionID != "", event.Result)
			}
			session = event.SessionID
		}
	}
	if calls != 1 || results != 1 || finals != 1 {
		return "", fmt.Errorf("launcher evidence incomplete: calls=%d results=%d finals=%d", calls, results, finals)
	}
	return session, nil
}

func TestVerifyGPTLauncherStream(t *testing.T) {
	call := `{"type":"assistant","message":{"content":[{"type":"tool_use","name":"Bash","id":"call-1","input":{"command":"echo LAUNCHER_TOOL_OK"}}]}}` + "\n"
	result := `{"type":"user","message":{"content":[{"type":"tool_result","tool_use_id":"call-1","content":"LAUNCHER_TOOL_OK\n"}]}}` + "\n"
	final := `{"type":"result","result":"LAUNCHER_GATEWAY_OK","session_id":"fixture"}` + "\n"
	for _, tc := range []struct {
		name   string
		stream string
		valid  bool
	}{
		{"complete", call + result + final, true},
		{"final-only", final, false},
		{"missing-result", call + final, false},
		{"duplicate-call", call + call + result + final, false},
		{"duplicate-result", call + result + result + final, false},
		{"duplicate-final", call + result + final + final, false},
		{"early-final", final + call + result, false},
		{"error-event", `{"type":"error"}` + "\n" + call + result + final, false},
		{"foreign-result", call + strings.ReplaceAll(result, "call-1", "foreign") + final, false},
		{"failed-result", call + strings.Replace(result, `"type":"tool_result"`, `"type":"tool_result","is_error":true`, 1) + final, false},
		{"wrong-command", strings.ReplaceAll(call, "echo LAUNCHER_TOOL_OK", "echo other") + result + final, false},
		{"malformed", call + "{", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			session, err := verifyGPTLauncherStream([]byte(tc.stream))
			if (err == nil) != tc.valid || (tc.valid && session != "fixture") {
				t.Fatalf("session=%q err=%v valid=%t", session, err, tc.valid)
			}
		})
	}
}
