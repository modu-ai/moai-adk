package cli

import (
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"
)

// Exercises real production assembly/receipt preparation/Engine over a local
// protocol peer. This is not a live-model or Claude UI acceptance test.
func TestGPTProductionUnsupportedFieldDoesNotStartTurn(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix peer fixture")
	}
	home, err := filepath.EvalSymlinks(sharedGPTFixtureHome(t))
	if err != nil {
		t.Fatal(err)
	}
	t.Setenv("MOAI_HOME", home)
	binDir, _ := installProductionWiringFakeCodex(t)
	t.Setenv("PATH", binDir+string(os.PathListSeparator)+os.Getenv("PATH"))
	peer := startClaudeGatewayPeer(t, home)
	payload, err := marshalGatewayPrivatePayload("invalid-input", gatewayGPTModels())
	if err != nil {
		t.Fatal(err)
	}
	handler, err := productionGatewayHandlerFactory(payload)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := handler.(io.Closer).Close(); err != nil {
			t.Error(err)
		}
	})
	recovering := handler.(*gatewayOwnedHandler).Handler.(*managedGPTRecoveringHandler)
	original := recovering.current
	for range 2 {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		r := httptest.NewRequest("POST", "/v1/messages", strings.NewReader(`{"model":"gpt-5.6-sol","max_tokens":10,"messages":[{"role":"user","content":[{"type":"text","text":"hello","PRIVATE_FIELD":1}]}]}`)).WithContext(ctx)
		r.Header.Set("Authorization", "Bearer invalid-input")
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, r)
		cancel()
		if w.Code != 400 || !strings.Contains(w.Body.String(), "request_unsupported_field") || strings.Contains(w.Body.String(), "PRIVATE_FIELD") {
			t.Fatalf("status=%d body=%s", w.Code, w.Body.String())
		}
	}
	peer.mu.Lock()
	defer peer.mu.Unlock()
	if peer.turnStarts != 0 || peer.threads != 0 || recovering.current != original {
		t.Fatal("invalid input started a thread/turn or rebuilt a healthy connection")
	}
}

func TestGPTProductionReconnectPreservesToolHistory(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("Unix peer fixture; Windows runtime verification remains separate")
	}
	for _, completed := range []bool{false, true} {
		name := "pending-tool"
		if completed {
			name = "completed-turn"
		}
		t.Run(name, func(t *testing.T) {
			home, err := filepath.EvalSymlinks(sharedGPTFixtureHome(t))
			if err != nil {
				t.Fatal(err)
			}
			t.Setenv("MOAI_HOME", home)
			binDir, _ := installProductionWiringFakeCodex(t)
			t.Setenv("PATH", binDir+string(os.PathListSeparator)+os.Getenv("PATH"))
			peer := startClaudeGatewayPeer(t, home)
			payload, err := marshalGatewayPrivatePayload("history-reconnect", gatewayGPTModels())
			if err != nil {
				t.Fatal(err)
			}
			handler, err := productionGatewayHandlerFactory(payload)
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() {
				if err := handler.(io.Closer).Close(); err != nil {
					t.Error(err)
				}
			})
			tools := []any{map[string]any{"name": "Agent", "input_schema": map[string]any{"type": "object"}}}
			messages := []any{map[string]string{"role": "user", "content": "delegate"}}
			send := func() *httptest.ResponseRecorder {
				t.Helper()
				raw, err := json.Marshal(map[string]any{"model": "gpt-5.6-sol", "max_tokens": 100, "tools": tools, "messages": messages})
				if err != nil {
					t.Fatal(err)
				}
				ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
				defer cancel()
				r := httptest.NewRequest("POST", "/v1/messages", strings.NewReader(string(raw))).WithContext(ctx)
				r.Header.Set("Authorization", "Bearer history-reconnect")
				w := httptest.NewRecorder()
				handler.ServeHTTP(w, r)
				return w
			}
			first := send()
			if first.Code != 200 {
				t.Fatalf("first status=%d body=%s", first.Code, first.Body.String())
			}
			var response struct {
				Content []map[string]any `json:"content"`
			}
			if err := json.Unmarshal(first.Body.Bytes(), &response); err != nil {
				t.Fatal(err)
			}
			if len(response.Content) != 1 || response.Content[0]["type"] != "tool_use" {
				t.Fatal("missing first tool")
			}
			toolID, ok := response.Content[0]["id"].(string)
			if !ok || toolID == "" {
				t.Fatal("missing tool ID")
			}
			messages = append(messages, map[string]any{"role": "assistant", "content": response.Content}, map[string]any{"role": "user", "content": []any{map[string]string{"type": "tool_result", "tool_use_id": toolID, "content": "CHILD_GATEWAY_OK"}}})
			if completed {
				second := send()
				if second.Code != 200 || !strings.Contains(second.Body.String(), "MAIN_GATEWAY_OK") {
					t.Fatalf("second status=%d body=%s", second.Code, second.Body.String())
				}
				// JSON decoding into reused maps retains omitted tool-use keys.
				// Claude sends a fresh text block, not a text block with stale id/input.
				response.Content = nil
				if err := json.Unmarshal(second.Body.Bytes(), &response); err != nil {
					t.Fatal(err)
				}
				messages = append(messages, map[string]any{"role": "assistant", "content": response.Content}, map[string]string{"role": "user", "content": "continue after reconnect"})
			}
			recovering := handler.(*gatewayOwnedHandler).Handler.(*managedGPTRecoveringHandler)
			peer.disconnect()
			deadline := time.NewTimer(time.Second)
			defer deadline.Stop()
			ticker := time.NewTicker(time.Millisecond)
			defer ticker.Stop()
			for recovering.current.connectionErr() == nil {
				select {
				case <-deadline.C:
					t.Fatal("disconnect not observed")
				case <-ticker.C:
				}
			}
			after := send()
			if after.Code >= 400 {
				logs, _ := filepath.Glob(filepath.Join(home, "gpt-appserver", "moai-rejections-*.jsonl"))
				for _, path := range logs {
					raw, _ := os.ReadFile(path)
					t.Logf("isolated rejection: %.2048s", raw)
				}
			}
			peer.mu.Lock()
			threads, turns, resumes, results := peer.threads, peer.turnStarts, peer.resumes, peer.toolResults
			peer.mu.Unlock()
			if completed {
				if after.Code != 200 || !strings.Contains(after.Body.String(), "MAIN_GATEWAY_OK") || threads != 1 || turns != 2 || resumes != 1 || results != 1 {
					t.Fatalf("completed reconnect status=%d threads=%d turns=%d resumes=%d results=%d body=%s", after.Code, threads, turns, resumes, results, after.Body.String())
				}
			} else if after.Code != 200 || !strings.Contains(after.Body.String(), "MAIN_GATEWAY_OK") || threads != 1 || turns != 1 || resumes != 1 || results != 1 {
				t.Fatalf("pending continuation not recovered exactly once: status=%d threads=%d turns=%d resumes=%d results=%d body=%s", after.Code, threads, turns, resumes, results, after.Body.String())
			}
			t.Logf("status=%d threads=%d turns=%d resumes=%d accepted_tool_results=%d", after.Code, threads, turns, resumes, results)
		})
	}
}
