package cli

import (
	"context"
	"encoding/json"
	"io"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/gateway/receipt"
)

func checkGPTAuthorizedHistory(t *testing.T, switchModel bool) {
	t.Helper()
	if runtime.GOOS == "windows" {
		t.Skip("SPEC-MOAI-GATEWAY-001 AS-022: Unix shared peer; Windows stdio runtime evidence remains separate")
	}
	home, err := filepath.EvalSymlinks(sharedGPTFixtureHome(t))
	if err != nil {
		t.Fatal(err)
	}
	t.Setenv("MOAI_HOME", home)
	binDir, _ := installProductionWiringFakeCodex(t)
	t.Setenv("PATH", binDir+string(os.PathListSeparator)+os.Getenv("PATH"))
	const session = "11111111-1111-4111-8111-111111111111"
	dir := filepath.Join(home, "receipt")
	if err := os.Mkdir(dir, 0700); err != nil {
		t.Fatal(err)
	}
	store, err := receipt.OpenStore(context.Background(), dir, session, true)
	if err != nil {
		t.Fatal(err)
	}
	if err := store.Close(); err != nil {
		t.Fatal(err)
	}
	peer := startClaudeGatewayPeer(t, home)
	payload, err := json.Marshal(gatewayPrivatePayload{Version: 1, SessionToken: "private", ModelIDs: []string{"gpt-5.6-sol", "gpt-6-astra"}, Conversation: &gatewayPrivateConversation{FamilyID: session, SessionID: session, ReceiptDir: dir, CWD: home}})
	if err != nil {
		t.Fatal(err)
	}
	h, err := productionGatewayHandlerFactory(payload)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := h.(io.Closer).Close(); err != nil {
			t.Error(err)
		}
	})
	identity, _ := json.Marshal(map[string]string{"account_uuid": "", "device_id": "device", "session_id": session})
	body := map[string]any{
		"model": "gpt-5.6-sol", "max_tokens": 2, "system": "MOAI_CHILD_PROBE",
		"thinking": map[string]string{"type": "adaptive"}, "output_config": map[string]string{"effort": "high"},
		"context_management": map[string]any{"edits": []any{map[string]string{"type": "clear_thinking_20251015", "keep": "all"}}},
		"metadata":           map[string]string{"user_id": string(identity)},
		"messages":           []any{map[string]string{"role": "user", "content": "hello"}},
	}
	send := func() map[string]any {
		t.Helper()
		raw, err := json.Marshal(body)
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		r := httptest.NewRequest("POST", "/v1/messages", strings.NewReader(string(raw))).WithContext(ctx)
		r.Header.Set("Authorization", "Bearer private")
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != 200 || !strings.Contains(w.Body.String(), "CHILD_GATEWAY_OK") {
			t.Fatalf("authorized request status=%d body=%s", w.Code, w.Body.String())
		}
		var response map[string]any
		if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil {
			t.Fatal(err)
		}
		return response
	}
	first := send()
	wantTurns := 1
	if switchModel {
		body["model"] = "gpt-6-astra"
		body["messages"] = []any{map[string]string{"role": "user", "content": "hello"}, map[string]any{"role": "assistant", "content": first["content"]}, map[string]string{"role": "user", "content": "continue"}}
		send()
		wantTurns = 2
	}
	peer.mu.Lock()
	defer peer.mu.Unlock()
	if peer.threads != 1 || len(peer.turnRequests) != wantTurns {
		t.Fatalf("history continuity: threads=%d turns=%d", peer.threads, len(peer.turnRequests))
	}
	for i, turn := range peer.turnRequests {
		want := `"gpt-5.6-sol"`
		if i == 1 {
			want = `"gpt-6-astra"`
		}
		if string(turn["model"]) != want || string(turn["effort"]) != `"high"` {
			t.Fatalf("turn %d model=%s effort=%s", i, turn["model"], turn["effort"])
		}
		if turn["max_output_tokens"] != nil || turn["max_tokens"] != nil {
			t.Fatal("Claude output cap escaped into App Server turn")
		}
		if i == 1 && (string(turn["threadId"]) != string(peer.turnRequests[0]["threadId"]) || !strings.Contains(string(turn["input"]), "continue") || strings.Contains(string(turn["input"]), "hello") || strings.Contains(string(turn["input"]), "CHILD_GATEWAY_OK")) {
			t.Fatal("model switch lost the owning thread or replayed acknowledged history")
		}
	}
}
