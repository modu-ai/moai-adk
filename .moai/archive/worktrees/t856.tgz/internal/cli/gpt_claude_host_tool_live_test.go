package cli

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/modu-ai/moai-adk/internal/codexapp"
	"github.com/modu-ai/moai-adk/internal/gateway"
	"github.com/modu-ai/moai-adk/internal/gateway/conversation"
	"github.com/modu-ai/moai-adk/internal/gateway/receipt"
)

// This smoke test joins an already running owner and never owns or terminates
// its lifetime. Destructive owner-recovery tests require a separate profile.
func TestSharedGPTLiveClaudeSession(t *testing.T) {
	if os.Getenv("MOAI_GPT_SHARED_SESSION_LIVE") != "1" {
		t.Skip("SPEC-MOAI-GATEWAY-001: opt in to a real model session on an existing managed server")
	}
	profile, err := managedGPTProfile()
	if err != nil {
		t.Fatal(err)
	}
	binary, err := exec.LookPath("codex")
	if err != nil {
		t.Fatal(err)
	}
	binary, err = filepath.Abs(binary)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	probe, err := codexapp.ConnectShared(ctx, managedGPTLiveConfig(t, binary, profile))
	if err != nil {
		t.Fatalf("existing shared owner required: %v", err)
	}
	if _, err := probe.Initialize(ctx, "moai-session-smoke", "1"); err != nil {
		_ = probe.Close()
		t.Fatal(err)
	}
	if err := probe.Close(); err != nil {
		t.Fatal(err)
	}
	t.Run("hosttool", managedGPTClaudeHostToolLive)
	t.Run("reconnect", func(t *testing.T) { managedGPTClaudeToolLive(t, "reconnect") })
	t.Run("deferred-reconnect", func(t *testing.T) { managedGPTClaudeToolLive(t, "deferred-reconnect") })
	t.Run("deferred", managedGPTClaudeDeferredToolLive)
	t.Run("agent", managedGPTClaudeAgentLive)
	t.Run("fork", func(t *testing.T) { managedGPTClaudeToolLive(t, "fork") })
	t.Run("fork-parallel", func(t *testing.T) { managedGPTClaudeToolLive(t, "fork-parallel") })
	t.Run("pty", managedGPTClaudePTYLive)
	t.Run("compact", managedGPTClaudeCompactLive)
}

// Called by explicit live probes; only the outer owner-recovery test may stop
// a server, and that test requires its own independently authenticated home.
func managedGPTClaudeHostToolLive(t *testing.T) {
	managedGPTClaudeToolLive(t, "bash")
}

func managedGPTClaudeDeferredToolLive(t *testing.T) {
	managedGPTClaudeToolLive(t, "deferred")
}

func managedGPTClaudeAgentLive(t *testing.T) {
	managedGPTClaudeToolLive(t, "agent")
}

func managedGPTClaudePTYLive(t *testing.T) { managedGPTClaudeToolLive(t, "pty") }

func managedGPTClaudeCompactLive(t *testing.T) { managedGPTClaudeToolLive(t, "pty-compact") }

func managedGPTClaudeToolLive(t *testing.T, mode string) {
	forkMode := mode == "fork" || mode == "fork-parallel"
	wantChildren := 1
	if mode == "fork-parallel" {
		wantChildren = 2
	}
	deferred := mode == "deferred" || mode == "deferred-reconnect"
	reconnect := mode == "reconnect" || mode == "deferred-reconnect"
	ptyMode := mode == "pty" || mode == "pty-compact"
	claude, err := exec.LookPath("claude")
	if err != nil {
		t.Fatal(err)
	}
	root, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	family := uuid.NewString()
	t.Logf("live Claude probe: mode=%s family=%s", mode, family)
	const token = "synthetic-host-tool-live-token"
	ledgerDir := filepath.Join(root, "receipts")
	if err := os.Mkdir(ledgerDir, 0700); err != nil {
		t.Fatal(err)
	}
	ledger, err := receipt.OpenStore(context.Background(), ledgerDir, family, true)
	if err != nil {
		t.Fatal(err)
	}
	if err := ledger.Close(); err != nil {
		t.Fatal(err)
	}
	payload, err := marshalGatewayPrivatePayloadWithConversation(token, gatewayGPTModels(), conversation.Descriptor{FamilyID: family, UUID: family, ReceiptDir: ledgerDir, CWD: root})
	if err != nil {
		t.Fatal(err)
	}
	handler, err := productionGatewayHandlerFactory(payload)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = handler.(io.Closer).Close() })
	var mu sync.Mutex
	results := make(map[string]bool)
	allResults := make(map[string]bool)
	discovered := false
	firstCatalog, initialSearch, initialTarget := false, false, false
	children := make(map[string]bool)
	forkCalls := make(map[string]bool)
	forkExpected := make(map[string]string)
	forkInherited := false
	forkCompletedNotification := false
	forkCompletions := make(map[string]gptForkCompletion)
	var lastParentShape gptProbeRequestShape
	compactRequests := 0
	var httpErrors atomic.Int32
	var refusedProbes atomic.Int32
	var disconnected atomic.Bool
	var activeChildren, peakChildren atomic.Int32
	errorRoutes := make(map[string]int)
	t.Cleanup(func() {
		if reconnect && !disconnected.Load() {
			t.Error("pending connection loss was not exercised")
		}
		if count := httpErrors.Load(); count != 0 {
			mu.Lock()
			t.Errorf("gateway returned HTTP errors during live roundtrip: %d routes=%v", count, errorRoutes)
			mu.Unlock()
		} else {
			t.Logf("unexpected gateway HTTP error responses=0; unauthenticated hello probes refused=%d", refusedProbes.Load())
		}
	})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var parentShape *gptProbeRequestShape
		if r.URL.Path == "/v1/messages" {
			if r.Header.Get("X-Claude-Code-Request-Class") == "compaction" {
				mu.Lock()
				compactRequests++
				mu.Unlock()
			}
			if child := r.Header.Get("X-Claude-Code-Agent-Id"); child != "" && r.Header.Get("X-Claude-Code-Request-Class") == "subagent" {
				active := activeChildren.Add(1)
				defer activeChildren.Add(-1)
				for peak := peakChildren.Load(); active > peak; peak = peakChildren.Load() {
					if peakChildren.CompareAndSwap(peak, active) {
						break
					}
				}
				mu.Lock()
				children[child] = true
				mu.Unlock()
			}
			raw, err := io.ReadAll(io.LimitReader(r.Body, 16<<20))
			if err != nil {
				http.Error(w, "probe read failed", 400)
				return
			}
			r.Body = io.NopCloser(strings.NewReader(string(raw)))
			if forkMode && r.Header.Get("X-Claude-Code-Agent-Id") == "" {
				shape := gptProbeShape(raw)
				parentShape = &shape
			}
			if forkMode && r.Header.Get("X-Claude-Code-Agent-Id") != "" && strings.Contains(string(raw), "HOST_EXECUTED_856") {
				mu.Lock()
				forkInherited = true
				mu.Unlock()
			}
			defs, _, returned, refs, deltaErr := managedGPTPublicDelta(raw)
			markerResult := false
			for _, result := range returned {
				for _, content := range result.Content {
					if strings.Contains(content.Text, "HOST_EXECUTED_856") {
						markerResult = true
					}
				}
			}
			if reconnect && deltaErr == nil && len(returned) > 0 && (!deferred || markerResult) && disconnected.CompareAndSwap(false, true) {
				// Only this test-owned gateway connection/Engine/receipt lease is
				// closed. The shared authentication owner remains alive.
				recovering := handler.(*gatewayOwnedHandler).Handler.(*managedGPTRecoveringHandler)
				recovering.mu.Lock()
				err := recovering.current.Close()
				recovering.mu.Unlock()
				if err != nil {
					t.Errorf("close test-owned pending connection: %v", err)
					http.Error(w, "test disconnect failed", 503)
					return
				}
				t.Log("test-owned pending gateway connection closed before matching tool result submission")
			}
			if deltaErr == nil {
				mu.Lock()
				if len(refs) > 0 {
					discovered = true
				}
				if !firstCatalog && len(defs) > 0 {
					firstCatalog = true
					for _, def := range defs {
						if mode == "agent" && def.Name == "Agent" {
							// Record only public schema property names, never prompts,
							// descriptions or argument values. This distinguishes the
							// observed tool contract from assumed native-fork support.
							var schema struct {
								Properties map[string]json.RawMessage `json:"properties"`
							}
							if err := json.Unmarshal(def.InputSchema, &schema); err != nil {
								t.Errorf("Agent schema could not be inspected: %v", err)
							}
							keys := make([]string, 0, len(schema.Properties))
							for key := range schema.Properties {
								keys = append(keys, key)
							}
							sort.Strings(keys)
							t.Logf("observed Claude Agent input property names: %v", keys)
						}
						if def.Name == "ToolSearch" {
							initialSearch = true
						}
						if def.Name == "mcp__probe__host_marker" && !def.Deferred {
							initialTarget = true
						}
					}
				}
				mu.Unlock()
			}
			var body struct {
				Messages []struct {
					Role    string
					Content json.RawMessage
				}
			}
			if json.Unmarshal(raw, &body) == nil {
				for _, message := range body.Messages {
					if forkMode && message.Role == "user" {
						var texts []string
						var scalar string
						if json.Unmarshal(message.Content, &scalar) == nil {
							texts = append(texts, scalar)
						} else {
							var blocks []struct{ Type, Text string }
							if json.Unmarshal(message.Content, &blocks) == nil {
								for _, block := range blocks {
									if block.Type == "text" {
										texts = append(texts, block.Text)
									}
								}
							}
						}
						for _, text := range texts {
							for _, text := range splitGPTForkNotifications(text) {
								completion, parsed := parseGPTForkCompletion(text)
								t.Logf("fork completion envelope: parsed=%t result_marker=%t", parsed, completion.Result == "HOST_EXECUTED_856")
								completed := strings.Contains(text, "<status>completed</status>")
								marker := strings.Contains(text, "HOST_EXECUTED_856")
								t.Logf("fork task notification: completed=%t marker=%t", completed, marker)
								mu.Lock()
								if parsed {
									forkCompletions[completion.TaskID] = completion
								}
								forkCompletedNotification = forkCompletedNotification || (completed && marker)
								mu.Unlock()
							}
						}
					}
					if forkMode && message.Role == "assistant" {
						var calls []struct {
							Type, Name, ID string
							Input          struct {
								SubagentType string `json:"subagent_type"`
								Prompt       string `json:"prompt"`
								Description  string `json:"description"`
							}
						}
						if json.Unmarshal(message.Content, &calls) == nil {
							for _, call := range calls {
								if call.Type == "tool_use" && call.Name == "Agent" {
									mu.Lock()
									forkCalls[call.ID] = call.Input.SubagentType == "fork" && !strings.Contains(call.Input.Prompt, "HOST_EXECUTED_856")
									if forkCalls[call.ID] {
										if mode != "fork-parallel" {
											forkExpected[call.ID] = "HOST_EXECUTED_856"
										} else if call.Input.Description == "left" || call.Input.Description == "right" {
											forkExpected[call.ID] = "HOST_EXECUTED_856:" + call.Input.Description
										}
									}
									mu.Unlock()
								}
							}
						}
					}
					if message.Role != "user" {
						continue
					}
					var blocks []struct {
						Type      string
						Content   json.RawMessage
						ToolUseID string `json:"tool_use_id"`
						IsError   bool   `json:"is_error"`
					}
					if json.Unmarshal(message.Content, &blocks) == nil {
						for _, block := range blocks {
							if block.Type == "tool_result" {
								mu.Lock()
								allResults[block.ToolUseID] = true
								if !block.IsError && strings.Contains(string(block.Content), "HOST_EXECUTED_856") {
									results[block.ToolUseID] = true
								}
								mu.Unlock()
							}
						}
					}
				}
			}
		}
		probe := &managedGPTProbeWriter{ResponseWriter: w, onError: func(code int) {
			// An unauthenticated reachability probe must not gain API access.
			if r.Method == http.MethodHead && r.URL.Path == "/api/hello" && r.Header.Get("Authorization") == "" && code == http.StatusUnauthorized {
				refusedProbes.Add(1)
				return
			}
			httpErrors.Add(1)
			mu.Lock()
			errorRoutes[r.Method+" "+r.URL.Path+" "+strconv.Itoa(code)]++
			mu.Unlock()
		}}
		handler.ServeHTTP(probe, r)
		if parentShape != nil {
			mu.Lock()
			if probe.status >= 400 {
				fields, prefix, before, after := gptProbeShapeDifference(lastParentShape, *parentShape)
				t.Logf("failed parent request shape: changed_fields=%s common_message_prefix=%d previous_roles=%s current_roles=%s", fields, prefix, before, after)
			} else {
				lastParentShape = *parentShape
			}
			mu.Unlock()
		}
		if probe.errorBody.Len() != 0 {
			var envelope struct {
				Error struct {
					Message string `json:"message"`
				} `json:"error"`
			}
			if json.Unmarshal([]byte(probe.errorBody.String()), &envelope) == nil {
				message := envelope.Error.Message
				// Only machine error labels; never log request bodies or headers.
				if len(message) > 80 || strings.IndexFunc(message, func(r rune) bool { return r != '_' && (r < 'a' || r > 'z') }) >= 0 {
					message = "non_machine_error"
				}
				t.Logf("gateway error response: status=%d cause=%s", probe.status, message)
			}
		}
	}))
	t.Cleanup(server.Close)
	budget := 50 * time.Second
	if mode == "pty-compact" {
		budget = 120 * time.Second
	} // Initial turn, summary, then recall.
	ctx, cancel := context.WithTimeout(context.Background(), budget)
	defer cancel()
	cmd := exec.CommandContext(ctx, claude, "--print", "--output-format", "json", "--session-id", family, "--model", "gpt-5.6-sol", "--tools", "Bash", "--allowedTools", "Bash(echo HOST_EXECUTED_856)", "--settings", `{"disableAllHooks":true}`, "--max-turns", "4", "Call Bash exactly once with command echo HOST_EXECUTED_856. After observing its result reply HOST_ROUNDTRIP_OK. Do not use any other command.")
	cmd.Dir = root
	cmd.Env = []string{"PATH=" + os.Getenv("PATH"), "HOME=" + root, "CLAUDE_CONFIG_DIR=" + filepath.Join(root, "native"), "ANTHROPIC_API_KEY=local-probe", "ANTHROPIC_AUTH_TOKEN=" + token, "ANTHROPIC_BASE_URL=" + server.URL, "CLAUDE_CODE_GATEWAY_HINT_HEADERS=1", "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1", "DISABLE_AUTOUPDATER=1"}
	var mcpCalls func() int
	if mode == "agent" {
		cmd.Args = []string{claude, "--print", "--output-format", "json", "--session-id", family, "--model", "gpt-5.6-sol", "--tools", "Agent", "--allowedTools", "Agent", "--agents", `{"probe":{"description":"synthetic read-only child","prompt":"Reply with only HOST_EXECUTED_856. Do not call any tools.","tools":[]}}`, "--settings", `{"disableAllHooks":true}`, "--max-turns", "5", "Call the probe Agent exactly once in the foreground. After observing its HOST_EXECUTED_856 result, reply only HOST_ROUNDTRIP_OK."}
	}
	if forkMode {
		cmd.Env = append(cmd.Env, "CLAUDE_CODE_FORK_SUBAGENT=1")
		cmd.Args = []string{claude, "--print", "--output-format", "json", "--session-id", family, "--model", "gpt-5.6-sol", "--tools", "Agent", "--allowedTools", "Agent(fork)", "--settings", `{"disableAllHooks":true}`, "--max-turns", "8", "Parent context marker: HOST_EXECUTED_856. Call Agent exactly once with subagent_type fork. The fork prompt must be: Return only the parent context marker inherited from the conversation; do not use tools or spawn agents. Do not put the marker value in that prompt. Wait for the fork to complete. Only after receiving its marker result reply HOST_ROUNDTRIP_OK."}
	}
	if mode == "fork-parallel" {
		cmd.Args[len(cmd.Args)-1] = "Parent context marker: HOST_EXECUTED_856. Call Agent exactly twice in the SAME response with subagent_type fork, descriptions exactly left and right. The left fork prompt must request: Return only the inherited parent context marker followed by :left; do not use tools or spawn agents. The right fork prompt must request the same but with :right. Do not put the marker value in either prompt. Wait for BOTH forks to complete and check each suffix matches its task. Only after receiving both results reply exactly HOST_ROUNDTRIP_OK with no other text."
	}
	if deferred {
		url, calls := managedGPTProbeMCP(t)
		mcpCalls = calls
		mcpConfig, err := json.Marshal(map[string]any{"mcpServers": map[string]any{"probe": map[string]string{"type": "http", "url": url}}})
		if err != nil {
			t.Fatal(err)
		}
		cmd.Args = []string{claude, "--print", "--output-format", "json", "--session-id", family, "--model", "gpt-5.6-sol", "--tools", "ToolSearch", "--allowedTools", "ToolSearch,mcp__probe__host_marker", "--strict-mcp-config", "--mcp-config", string(mcpConfig), "--settings", `{"disableAllHooks":true}`, "--max-turns", "6", "Use ToolSearch to discover the probe host_marker tool, then call it exactly once. After observing HOST_EXECUTED_856, reply only HOST_ROUNDTRIP_OK. Do not use another tool."}
	}
	if deferred || mode == "agent" || forkMode || ptyMode {
		catalog, err := gateway.NewSessionCatalog(nil)
		if err != nil {
			t.Fatal(err)
		}
		launch, err := prepareGatewayLaunch(gatewayPrepareInput{Mode: "gpt", Catalog: catalog, Address: strings.TrimPrefix(server.URL, "http://"), Inherited: cmd.Env, SessionEnv: []string{"ANTHROPIC_AUTH_TOKEN=" + token, "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1"}})
		if err != nil {
			t.Fatal(err)
		}
		cmd.Env = append(launch.ChildEnv, "MCP_CONNECTION_NONBLOCKING=0")
	}
	if ptyMode {
		managedGPTInteractiveBash(t, ctx, cmd, family, mode == "pty-compact")
		mu.Lock()
		observed, total := len(results), len(allResults)
		compactions := compactRequests
		mu.Unlock()
		if observed != 1 || total != 1 {
			t.Fatalf("PTY tool result mismatch: marker_results=%d total=%d", observed, total)
		}
		if mode == "pty-compact" && compactions == 0 {
			t.Fatal("no real compaction request observed")
		}
		if mode == "pty-compact" {
			t.Logf("real compaction requests=%d; post-compact recall displayed", compactions)
		}
		t.Log("interactive Claude PTY -> real GPT -> Claude Bash -> displayed final: tool_results=1")
		return
	}
	output, err := cmd.Output()
	if err != nil {
		if forkMode {
			mu.Lock()
			t.Logf("fork execution failed: context=%v calls=%d children=%d completions=%d active_child_requests=%d peak_child_requests=%d", ctx.Err(), len(forkCalls), len(children), len(forkCompletions), activeChildren.Load(), peakChildren.Load())
			mu.Unlock()
		}
		t.Fatalf("real Claude/GPT host tool execution: %v", err)
	}
	mu.Lock()
	observed := len(results)
	sawReference := discovered
	sawSearch, sawUpfrontTarget := initialSearch, initialTarget
	childCount := len(children)
	completedFork := forkCompletedNotification
	if forkMode {
		correlated := countGPTForkMatches(children, forkExpected, forkCompletions)
		expectedValues := make(map[string]bool)
		for _, value := range forkExpected {
			expectedValues[value] = true
		}
		if len(expectedValues) != wantChildren {
			t.Error("fork tasks did not request distinct expected results")
		}
		t.Logf("fork completion correlation: parsed=%d matched=%d", len(forkCompletions), correlated)
		if correlated != wantChildren {
			t.Error("fork completion did not match its observed child and Agent call")
		}
		t.Logf("native fork evidence: calls=%d inherited_marker=%t children=%d marker_results=%d completed_notification=%t", len(forkCalls), forkInherited, childCount, observed, forkCompletedNotification)
		if len(forkCalls) != wantChildren || !forkInherited {
			t.Error("native fork invocation or inherited parent context not observed")
		}
		for _, valid := range forkCalls {
			if !valid {
				t.Error("Agent call did not select fork or copied marker into prompt")
			}
		}
		if mode == "fork-parallel" && peakChildren.Load() < 2 {
			t.Error("two fork requests never overlapped")
		}
		t.Logf("fork child request concurrency: peak=%d", peakChildren.Load())
	}
	mu.Unlock()
	var final struct {
		Result  string `json:"result"`
		IsError bool   `json:"is_error"`
	}
	if err := json.Unmarshal(output, &final); err != nil {
		t.Fatal("Claude final output was not JSON")
	}
	resultDelivered := observed == 1
	if forkMode {
		// Native forks are background tasks: their final result arrives as a
		// completed task notification, not the launch call's tool_result.
		resultDelivered = completedFork
	}
	if strings.TrimSpace(final.Result) != "HOST_ROUNDTRIP_OK" || final.IsError || !resultDelivered {
		if (mode == "agent" || forkMode) && len(final.Result) <= 512 {
			t.Logf("synthetic agent final result=%q child_ids=%d", final.Result, childCount)
		}
		t.Fatalf("host tool roundtrip incomplete: marker=%t is_error=%t results=%d", strings.TrimSpace(final.Result) == "HOST_ROUNDTRIP_OK", final.IsError, observed)
	}
	if deferred {
		if !sawReference || !sawSearch || sawUpfrontTarget || mcpCalls() != 1 {
			t.Fatalf("deferred roundtrip incomplete: tool_reference=%t initial_search=%t upfront_target=%t mcp_calls=%d", sawReference, sawSearch, sawUpfrontTarget, mcpCalls())
		}
		t.Log("real Claude ToolSearch -> tool_reference -> real GPT dispatcher -> Claude MCP: calls=1 final=HOST_ROUNDTRIP_OK")
		return
	}
	if mode == "agent" || forkMode {
		if childCount != wantChildren {
			t.Fatalf("expected %d real Claude subagents, observed=%d", wantChildren, childCount)
		}
		if forkMode {
			t.Logf("real Claude native fork -> inherited parent context -> completed task notification -> parent final: child_ids=%d final=HOST_ROUNDTRIP_OK", childCount)
		} else {
			t.Log("real Claude Agent -> real GPT child -> parent result: child_ids=1 final=HOST_ROUNDTRIP_OK")
		}
		return
	}
	t.Logf("real Claude -> production gateway -> real GPT -> Claude Bash -> result: observed=%d final=HOST_ROUNDTRIP_OK", observed)
	// A new Claude process must reload the persisted host transcript without
	// replaying the completed Bash call or losing its result in the bridge.
	resume := exec.CommandContext(ctx, claude, "--print", "--output-format", "json", "--resume", family, "--model", "gpt-5.6-sol", "--tools", "Bash", "--allowedTools", "Bash(echo HOST_EXECUTED_856)", "--settings", `{"disableAllHooks":true}`, "--max-turns", "2", "Without calling any tool, reply with only the exact output of the Bash command from our previous turn.")
	resume.Dir, resume.Env = cmd.Dir, cmd.Env
	output, err = resume.Output()
	if err != nil {
		t.Fatalf("real Claude/GPT resume: %v", err)
	}
	final.Result, final.IsError = "", false
	if err := json.Unmarshal(output, &final); err != nil {
		t.Fatal("Claude resumed output was not JSON")
	}
	mu.Lock()
	observed = len(results)
	total := len(allResults)
	mu.Unlock()
	if strings.TrimSpace(final.Result) != "HOST_EXECUTED_856" || final.IsError || observed != 1 || total != 1 {
		t.Fatalf("host resume incomplete: recalled=%t is_error=%t unique_results=%d total=%d", strings.TrimSpace(final.Result) == "HOST_EXECUTED_856", final.IsError, observed, total)
	}
	t.Log("new Claude process resumed prior Bash result; unique tool result IDs=1")
}

type managedGPTProbeWriter struct {
	http.ResponseWriter
	onError   func(int)
	status    int
	errorBody strings.Builder
}

func (w *managedGPTProbeWriter) WriteHeader(code int) {
	w.status = code
	if code >= 400 {
		w.onError(code)
	}
	w.ResponseWriter.WriteHeader(code)
}

func (w *managedGPTProbeWriter) Write(p []byte) (int, error) {
	if w.status >= 400 && w.errorBody.Len() < 2048 {
		limit := min(len(p), 2048-w.errorBody.Len())
		w.errorBody.Write(p[:limit])
	}
	return w.ResponseWriter.Write(p)
}

func (w *managedGPTProbeWriter) Flush() { _ = http.NewResponseController(w.ResponseWriter).Flush() }
