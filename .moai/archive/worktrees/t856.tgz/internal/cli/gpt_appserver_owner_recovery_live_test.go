package cli

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codexapp"
	"github.com/modu-ai/moai-adk/internal/paths"
)

// A separate, independently authenticated test home is mandatory. An exclusive
// startup lease alone cannot prevent an operator joining a test-owned server
// later and losing their connection when the test cleans up.
func TestSharedGPTLiveManagedOwnerRecovery(t *testing.T) {
	if os.Getenv("MOAI_GPT_OWNER_RECOVERY_LIVE") != "1" {
		t.Skip("requires explicit managed owner recovery probe")
	}
	operatorHome, err := paths.MoaiHome()
	if err != nil {
		t.Fatal(err)
	}
	testHome, err := validateGPTRecoveryTestHome(operatorHome, os.Getenv("MOAI_GPT_OWNER_RECOVERY_HOME"))
	if err != nil {
		t.Fatal(err)
	}
	t.Setenv("MOAI_HOME", testHome)
	profile, err := managedGPTProfile()
	if err != nil {
		t.Fatal(err)
	}
	binary, err := exec.LookPath("codex")
	if err != nil {
		t.Fatal(err)
	}
	binary, err = filepath.Abs(binary)
	if err != nil {
		t.Fatal(err)
	}
	cfg := managedGPTLiveConfig(t, binary, profile)
	lifetime := 75 * time.Second
	if deadline, ok := t.Deadline(); ok {
		lifetime = time.Until(deadline) - 5*time.Second
	}
	ctx, cancel := context.WithTimeout(context.Background(), lifetime)
	done := make(chan error, 1)
	go func() { done <- codexapp.ServeShared(ctx, cfg) }()
	t.Cleanup(func() {
		if os.Getenv("MOAI_GPT_LEASE_DIAGNOSTICS") == "1" {
			probeCtx, probeCancel := context.WithTimeout(context.Background(), 3*time.Second)
			owners, probeErr := exec.CommandContext(probeCtx, "lsof", "-F", "pcf", filepath.Join(profile, ".moai-appserver.lock")).Output()
			probeCancel()
			if len(owners) <= 4096 {
				t.Logf("before owned server shutdown: lease holders=%s observation_error=%v", owners, probeErr)
			}
		}
		cancel()
		select {
		case <-done:
		case <-time.After(5 * time.Second):
			t.Error("test-owned App Server did not terminate")
		}
	})
	ticker := time.NewTicker(50 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case err := <-done:
			done <- err
			probeCtx, probeCancel := context.WithTimeout(context.Background(), 3*time.Second)
			probeStart := time.Now()
			owners, probeErr := exec.CommandContext(probeCtx, "lsof", "-F", "pc", filepath.Join(profile, ".moai-appserver.lock")).Output()
			probeContextErr := probeCtx.Err()
			probeCancel()
			if len(owners) <= 4096 {
				t.Logf("profile lease holder observation: elapsed=%s exit=%v context=%v owners=%s", time.Since(probeStart), probeErr, probeContextErr, owners)
			}
			t.Fatalf("managed owner startup: %v", err)
		case <-ctx.Done():
			t.Fatal(ctx.Err())
		case <-ticker.C:
			client, err := codexapp.ConnectShared(ctx, cfg)
			if err != nil {
				continue
			}
			err = initializeManagedGPT(ctx, client, binary, "moai-recovery-probe")
			closeErr := client.Close()
			if err != nil || closeErr != nil {
				t.Fatalf("managed version handshake: %v; close: %v", err, closeErr)
			}
			t.Log("managed owner started; selected binary and server versions match")
			t.Setenv("MOAI_GPT_HOOK_LIVE", "1")
			t.Run("hook-terminal", TestSharedGPTLiveHookAgentTerminal)
			t.Run("claude-host-tool", managedGPTClaudeHostToolLive)
			t.Run("claude-deferred-tool", managedGPTClaudeDeferredToolLive)
			t.Run("claude-agent", managedGPTClaudeAgentLive)
			t.Run("claude-pty", managedGPTClaudePTYLive)
			t.Run("claude-compact", managedGPTClaudeCompactLive)
			t.Run("launcher", managedGPTLauncherLive)
			return
		}
	}
}

func validateGPTRecoveryTestHome(operatorHome, requested string) (string, error) {
	if !filepath.IsAbs(requested) || codexapp.ValidatePrivatePath(requested, true) != nil {
		return "", errors.New("set MOAI_GPT_OWNER_RECOVERY_HOME to a private, independently authenticated test MoAI home; never copy operator credentials")
	}
	operator, err := filepath.EvalSymlinks(operatorHome)
	if err != nil || operator == filepath.Clean(requested) {
		return "", errors.New("owner recovery tests must not use the operator MoAI home")
	}
	testProfile := filepath.Join(requested, "gpt-appserver")
	if codexapp.ValidatePrivatePath(testProfile, true) != nil {
		return "", errors.New("isolated managed test profile is unavailable")
	}
	return filepath.Clean(requested), nil
}

func TestGPTRecoveryHomeIsolation(t *testing.T) {
	operator, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(operator, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(filepath.Join(operator, "gpt-appserver"), 0700); err != nil {
		t.Fatal(err)
	}
	isolated, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(isolated, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(filepath.Join(isolated, "gpt-appserver"), 0700); err != nil {
		t.Fatal(err)
	}
	for _, candidate := range []string{"", "relative", operator} {
		if _, err := validateGPTRecoveryTestHome(operator, candidate); err == nil {
			t.Fatalf("unsafe test home accepted: %q", candidate)
		}
	}
	if got, err := validateGPTRecoveryTestHome(operator, isolated); err != nil || got != isolated {
		t.Fatalf("isolated home rejected: %q %v", got, err)
	}
	if err := os.Chmod(isolated, 0755); err != nil {
		t.Fatal(err)
	}
	if _, err := validateGPTRecoveryTestHome(operator, isolated); err == nil {
		t.Fatal("public test home accepted")
	}
}
