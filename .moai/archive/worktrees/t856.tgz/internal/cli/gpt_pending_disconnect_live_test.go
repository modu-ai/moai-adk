package cli

import (
	"context"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/codexapp"
)

// Observes official behavior after losing only this synthetic tool's connection.
// It never executes the tool or stops the shared server. A synthetic result is
// returned once only after matching a reissued request on the new connection.
func TestGPTLivePendingConnectionLoss(t *testing.T) {
	if os.Getenv("MOAI_GPT_PENDING_DISCONNECT_LIVE") != "1" {
		t.Skip("SPEC-MOAI-GATEWAY-001: opt in to a real synthetic pending-tool probe")
	}
	profile, err := managedGPTProfile()
	if err != nil {
		t.Fatal(err)
	}
	binary, err := exec.LookPath("codex")
	if err != nil {
		t.Fatal(err)
	}
	binary, err = filepath.Abs(binary)
	if err != nil {
		t.Fatal(err)
	}
	cfg := managedGPTLiveConfig(t, binary, profile)
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	connect := func() *codexapp.Client {
		t.Helper()
		c, err := codexapp.ConnectShared(ctx, cfg)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() {
			if err := c.Close(); err != nil {
				t.Error(err)
			}
		})
		if _, err := c.Initialize(ctx, "moai-pending-probe", "1"); err != nil {
			t.Fatal(err)
		}
		return c
	}
	first, observer := connect(), connect()
	root, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	var started struct {
		Thread struct {
			ID string `json:"id"`
		} `json:"thread"`
	}
	err = first.Call(ctx, "thread/start", map[string]any{
		"model": "gpt-5.6-sol", "cwd": root, "approvalPolicy": "never", "sandbox": "read-only", "environments": []any{},
		"dynamicTools": []any{map[string]any{"name": "probe_pending", "description": "A synthetic no-op test. Call exactly once with no arguments.", "inputSchema": map[string]any{"type": "object", "properties": map[string]any{}, "additionalProperties": false}}},
	}, &started)
	if err != nil || started.Thread.ID == "" {
		t.Fatalf("start: %v", err)
	}
	var turn struct {
		Turn struct {
			ID string `json:"id"`
		} `json:"turn"`
	}
	err = first.Call(ctx, "turn/start", map[string]any{"threadId": started.Thread.ID, "model": "gpt-5.6-sol", "input": []any{map[string]string{"type": "text", "text": "Call probe_pending exactly once now with no arguments. Do not use any other tool. After it returns say DONE."}}, "environments": []any{}}, &turn)
	if err != nil || turn.Turn.ID == "" {
		t.Fatalf("turn: %v", err)
	}
	completed := false
	defer func() {
		if completed {
			return
		}
		cleanup, stop := context.WithTimeout(context.Background(), 5*time.Second)
		defer stop()
		var result any
		// Interrupt only the thread/turn created above, even on a failed assertion.
		if err := observer.Call(cleanup, "turn/interrupt", map[string]string{"threadId": started.Thread.ID, "turnId": turn.Turn.ID}, &result); err != nil {
			t.Errorf("owned turn cleanup: %v", err)
		}
	}()
	callID := ""
	for callID == "" {
		select {
		case <-ctx.Done():
			t.Fatal("synthetic pending tool not observed")
		case event, ok := <-first.Events():
			if !ok {
				t.Fatal("connection ended before pending call")
			}
			if event.Method != "item/tool/call" {
				continue
			}
			var call struct{ ThreadID, TurnID, CallID, Tool string }
			if json.Unmarshal(event.Params, &call) != nil || call.ThreadID != started.Thread.ID || call.TurnID != turn.Turn.ID || call.Tool != "probe_pending" || call.CallID == "" {
				t.Fatal("unexpected pending call binding")
			}
			callID = call.CallID
		}
	}
	if err := first.Close(); err != nil {
		t.Fatal(err)
	}
	replacement := connect()
	var snapshot struct {
		Thread struct {
			ID     string `json:"id"`
			Status struct {
				Type string `json:"type"`
			} `json:"status"`
			Turns []struct {
				ID, Status string
				Items      []struct{ ID, Type, Status, Tool string }
			} `json:"turns"`
		} `json:"thread"`
	}
	if err := replacement.Call(ctx, "thread/read", map[string]any{"threadId": started.Thread.ID, "includeTurns": true}, &snapshot); err != nil {
		t.Fatal(err)
	}
	if snapshot.Thread.ID != started.Thread.ID {
		t.Fatal("foreign snapshot")
	}
	found := false
	t.Logf("snapshot thread status=%s turns=%d", snapshot.Thread.Status.Type, len(snapshot.Thread.Turns))
	for _, observedTurn := range snapshot.Thread.Turns {
		t.Logf("snapshot turn matches=%t status=%s items=%d", observedTurn.ID == turn.Turn.ID, observedTurn.Status, len(observedTurn.Items))
		if observedTurn.ID != turn.Turn.ID {
			continue
		}
		for _, item := range observedTurn.Items {
			t.Logf("snapshot item type=%s status=%s call_matches=%t tool_matches=%t", item.Type, item.Status, item.ID == callID, item.Tool == "probe_pending")
			if item.Type == "dynamicToolCall" && item.ID == callID && item.Tool == "probe_pending" {
				found = true
				t.Logf("official post-disconnect snapshot: thread=%s turn=%s tool=%s; tool executed=0 result replies=0", snapshot.Thread.Status.Type, observedTurn.Status, item.Status)
			}
		}
	}
	if found {
		t.Log("tool also visible in snapshot; still require reissued request and terminal evidence")
	}
	{
		var resumed any
		if err := replacement.Call(ctx, "thread/resume", map[string]string{"threadId": started.Thread.ID}, &resumed); err != nil {
			t.Fatalf("pending tool absent from read; resume: %v", err)
		}
		observation, stop := context.WithTimeout(ctx, 3*time.Second)
		defer stop()
		for {
			select {
			case <-observation.Done():
				t.Fatal("pending tool absent from read; no matching reissued request observed within 3s after resume (recovery NOT verified)")
			case event, ok := <-replacement.Events():
				if !ok {
					t.Fatal("replacement closed during observation")
				}
				if event.Method != "item/tool/call" {
					continue
				}
				var call struct{ ThreadID, TurnID, CallID, Tool string }
				if json.Unmarshal(event.Params, &call) != nil {
					t.Fatal("invalid reissued call")
				}
				if call.ThreadID != started.Thread.ID || call.TurnID != turn.Turn.ID || call.CallID != callID || call.Tool != "probe_pending" {
					t.Fatal("replacement received a different call; not recovery of pending call")
				}
				if err := replacement.Respond(ctx, event.ID, map[string]any{"contentItems": []any{map[string]string{"type": "inputText", "text": "SYNTHETIC_PENDING_OK"}}, "success": true}); err != nil {
					t.Fatal(err)
				}
				for {
					select {
					case <-ctx.Done():
						t.Fatal("reissued call result sent but turn completion not observed")
					case terminal, ok := <-replacement.Events():
						if !ok {
							t.Fatal("replacement ended before completion")
						}
						if terminal.Method == "item/tool/call" {
							t.Fatal("unexpected second tool request")
						}
						if terminal.Method != "turn/completed" {
							continue
						}
						var done struct {
							ThreadID string
							Turn     struct{ ID, Status string }
						}
						if json.Unmarshal(terminal.Params, &done) != nil || done.ThreadID != started.Thread.ID || done.Turn.ID != turn.Turn.ID || done.Turn.Status != "completed" {
							t.Fatal("terminal identity or status mismatch")
						}
						completed = true
						t.Log("same pending call reissued on replacement; synthetic result replies=1; owned turn completed; tool executed=0")
						return
					}
				}
			}
		}
	}
}
