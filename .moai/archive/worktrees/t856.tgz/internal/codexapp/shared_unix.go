//go:build !windows

package codexapp

import (
	"errors"
	"os"
	"os/exec"
	"syscall"
	"time"
)

// Keep the same flock open-file description alive in the actual auth owner
// even if its supervisor is killed without running cleanup.
func inheritSharedLease(cmd *exec.Cmd, lease *os.File) { cmd.ExtraFiles = []*os.File{lease} }

// Let the official server drain its workers before releasing the owner lease.
// CommandContext still kills an unresponsive child after the bounded grace.
func configureSharedShutdown(cmd *exec.Cmd) {
	// Own a dedicated process group, never the terminal/operator's group.
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Cancel = func() error {
		err := syscall.Kill(-cmd.Process.Pid, syscall.SIGINT)
		if errors.Is(err, syscall.ESRCH) {
			return os.ErrProcessDone
		}
		return err
	}
	cmd.WaitDelay = 3 * time.Second
}

// Run/Wait reaps only the direct child. Native workers can still hold the
// inherited lease, so drain this owner's group before releasing that lease.
func finishSharedShutdown(cmd *exec.Cmd) error {
	if cmd.Process == nil {
		return nil
	}
	group := -cmd.Process.Pid
	if err := syscall.Kill(group, syscall.SIGKILL); errors.Is(err, syscall.ESRCH) {
		return nil
	} else if err != nil && !errors.Is(err, syscall.EPERM) {
		return err
	}
	deadline := time.NewTimer(3 * time.Second)
	defer deadline.Stop()
	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()
	for {
		// EPERM is not proof of termination. Only ESRCH completes this wait;
		// an unobservable or surviving group fails at the bounded deadline.
		if err := syscall.Kill(group, 0); errors.Is(err, syscall.ESRCH) {
			return nil
		} else if err != nil && !errors.Is(err, syscall.EPERM) {
			return err
		}
		select {
		case <-deadline.C:
			return errors.New("shared App Server workers did not terminate")
		case <-ticker.C:
		}
	}
}
