//go:build windows

package codexapp

import (
	"os"
	"os/exec"
)

func inheritSharedLease(cmd *exec.Cmd, lease *os.File) {}

func configureSharedShutdown(cmd *exec.Cmd) {}

func finishSharedShutdown(cmd *exec.Cmd) error { return nil }
