//go:build !windows

package codexapp

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"
)

func TestSharedShutdownProcess(t *testing.T) {
	mode := os.Getenv("MOAI_SHARED_SHUTDOWN_HELPER")
	if mode == "" {
		return
	}
	signals := make(chan os.Signal, 1)
	signal.Notify(signals, os.Interrupt)
	if mode == "lease-worker" {
		time.AfterFunc(10*time.Second, func() { os.Exit(0) })
		fmt.Println("ready")
		for range signals {
			// Model a worker that does not handle the owner's graceful shutdown.
		}
	}
	if mode == "owner-with-worker" {
		exe, _ := os.Executable()
		worker := exec.Command(exe, "-test.run=^TestSharedShutdownProcess$")
		worker.Env = append(os.Environ(), "MOAI_SHARED_SHUTDOWN_HELPER=lease-worker")
		worker.ExtraFiles = []*os.File{os.NewFile(3, "inherited-lease")}
		out, err := worker.StdoutPipe()
		if err != nil || worker.Start() != nil {
			os.Exit(2)
		}
		ready := bufio.NewScanner(out)
		if !ready.Scan() || ready.Text() != "ready" {
			os.Exit(3)
		}
		fmt.Printf("ready:%d\n", worker.Process.Pid)
		<-signals
		os.Exit(0)
	}
	fmt.Println("ready")
	for range signals {
		if mode == "cooperative" {
			os.Exit(0)
		}
	}
}

func TestSharedShutdownReleasesDescendantLease(t *testing.T) {
	leasePath := filepath.Join(t.TempDir(), "lease")
	lease, err := profileLease(leasePath)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = lease.Close() })
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, exe, "-test.run=^TestSharedShutdownProcess$")
	cmd.Env = append(os.Environ(), "MOAI_SHARED_SHUTDOWN_HELPER=owner-with-worker")
	inheritSharedLease(cmd, lease)
	configureSharedShutdown(cmd)
	out, err := cmd.StdoutPipe()
	if err != nil || cmd.Start() != nil {
		t.Fatal("helper start failed")
	}
	waited := false
	t.Cleanup(func() {
		cancel()
		if !waited {
			_ = cmd.Wait()
			_ = finishSharedShutdown(cmd)
		}
	})
	ready := bufio.NewScanner(out)
	if !ready.Scan() || !strings.HasPrefix(ready.Text(), "ready:") {
		t.Fatal("worker readiness missing")
	}
	workerPID, err := strconv.Atoi(strings.TrimPrefix(ready.Text(), "ready:"))
	if err != nil {
		t.Fatal(err)
	}
	workerDrained := false
	t.Cleanup(func() {
		if workerDrained {
			return
		}
		worker, _ := os.FindProcess(workerPID)
		_ = worker.Kill() // Only the PID returned by this test's own helper.
	})
	group, err := syscall.Getpgid(workerPID)
	if err != nil || group != cmd.Process.Pid || group == syscall.Getpgrp() {
		t.Fatalf("worker is not isolated from the caller: group=%d owner=%d err=%v", group, cmd.Process.Pid, err)
	}
	cancel()
	_ = cmd.Wait()
	waited = true
	if err := finishSharedShutdown(cmd); err != nil {
		t.Fatal(err)
	}
	workerDrained = true
	_ = lease.Close()
	other, err := profileLease(leasePath)
	if err != nil {
		t.Fatalf("descendant retained owner lease after shutdown: %v", err)
	}
	_ = other.Close()
}

func TestSharedShutdownGraceAndForcedFallback(t *testing.T) {
	for _, mode := range []string{"cooperative", "unresponsive"} {
		t.Run(mode, func(t *testing.T) {
			exe, err := os.Executable()
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 6*time.Second)
			defer cancel()
			cmd := exec.CommandContext(ctx, exe, "-test.run=^TestSharedShutdownProcess$")
			cmd.Env = append(os.Environ(), "MOAI_SHARED_SHUTDOWN_HELPER="+mode)
			configureSharedShutdown(cmd)
			if cmd.WaitDelay != 3*time.Second {
				t.Fatal("missing bounded shutdown grace")
			}
			stdout, err := cmd.StdoutPipe()
			if err != nil {
				t.Fatal(err)
			}
			if err := cmd.Start(); err != nil {
				t.Fatal(err)
			}
			waited := false
			t.Cleanup(func() {
				cancel()
				if !waited {
					_ = cmd.Wait()
				}
			})
			ready := bufio.NewScanner(stdout)
			if !ready.Scan() || ready.Text() != "ready" {
				t.Fatal("child readiness missing")
			}
			cancel()
			_ = cmd.Wait() // Context cancellation is expected in both cases.
			waited = true
			if cmd.ProcessState == nil {
				t.Fatal("child was not reaped")
			}
			if mode == "cooperative" && !cmd.ProcessState.Success() {
				t.Fatal("cooperative child was forcibly killed")
			}
			if mode == "unresponsive" && cmd.ProcessState.Success() {
				t.Fatal("unresponsive child escaped forced termination")
			}
		})
	}
}
