package translate

import (
	"errors"
	"testing"
)

func TestUnsupportedFieldClassificationIsRequestOnly(t *testing.T) {
	for _, body := range []string{
		`{"max_tokens":10,"PRIVATE_FIELD":1,"messages":[{"role":"user","content":"hello"}]}`,
		`{"max_tokens":10,"messages":[{"role":"user","content":[{"type":"text","text":"hello","PRIVATE_FIELD":1}]}]}`,
	} {
		_, _, err := Request("gpt-5.6-sol", []byte(body), Limits{})
		var classified interface{ CauseCode() string }
		if !errors.As(err, &classified) || classified.CauseCode() != "request_unsupported_field" || err.Error() != "request_unsupported_field" {
			t.Fatalf("request classification: %v", err)
		}
	}
	_, response, err := Request("gpt-5.6-sol", []byte(`{"max_tokens":10,"messages":[{"role":"user","content":"hello"}]}`), Limits{})
	if err != nil {
		t.Fatal(err)
	}
	_, err = response.Response([]byte(`{"id":"resp1","model":"gpt-5.6-sol","output":[{"id":"msg1","type":"message","status":"completed","role":"assistant","content":[{"type":"output_text","text":"hello","PRIVATE_FIELD":1}]}]}`))
	var unsupported unsupportedFieldError
	var classified interface{ CauseCode() string }
	if !errors.As(err, &unsupported) || errors.As(err, &classified) {
		t.Fatalf("upstream must not be classified as client input: %v", err)
	}
}
