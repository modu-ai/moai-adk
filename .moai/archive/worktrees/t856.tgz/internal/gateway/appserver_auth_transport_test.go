package gateway

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/modu-ai/moai-adk/internal/codexapp"
)

type failingManagedAccount struct {
	calls, failAt int
}

func (a *failingManagedAccount) Account(context.Context) (codexapp.AccountResult, error) {
	a.calls++
	if a.calls == a.failAt {
		return codexapp.AccountResult{}, io.EOF
	}
	return codexapp.AccountResult{Account: &codexapp.Account{Type: "chatgpt"}}, nil
}

func TestManagedAccountTransportFailureIsNotAuthenticationFailure(t *testing.T) {
	for _, failAt := range []int{1, 2, 3} {
		t.Run(fmt.Sprint(failAt), func(t *testing.T) {
			account := &failingManagedAccount{failAt: failAt}
			authority, err := NewAppServerAuthority(account, "chatgpt", func(context.Context) (string, error) { return "scope", nil })
			if err != nil {
				t.Fatal(err)
			}
			adapter := &managedProbeAdapter{authority: authority}
			logger := &lifecycleRejectionRecorder{}
			catalog, err := NewCatalog([]ModelEntry{{RouteID: "gpt-test", UpstreamID: "gpt-test", Provider: ProviderOpenAI, AuthMethod: AuthAppServer}})
			if err != nil {
				t.Fatal(err)
			}
			server, err := NewServer(ServerConfig{SessionHeader: "Authorization", SessionToken: "Bearer local-test", MaxBodyBytes: 4096, Catalog: catalog, ManagedAuthority: authority, Adapters: map[ProviderID]Adapter{ProviderOpenAI: adapter}, RejectionLogger: logger})
			if err != nil {
				t.Fatal(err)
			}
			r := httptest.NewRequest("POST", "/v1/messages", strings.NewReader(`{"model":"gpt-test","max_tokens":100,"messages":[{"role":"user","content":"hello"}]}`))
			r.Header.Set("Authorization", "Bearer local-test")
			w := httptest.NewRecorder()
			server.ServeHTTP(w, r)
			if w.Code != http.StatusServiceUnavailable || !strings.Contains(w.Body.String(), "appserver_account_unavailable") || adapter.called != 0 {
				t.Fatalf("status=%d body=%s generation_calls=%d", w.Code, w.Body.String(), adapter.called)
			}
			if len(logger.rows) != 1 || logger.rows[0]["transport_kind"] != "eof" || logger.rows[0]["digest"] != w.Header().Get("Request-Id") {
				t.Fatalf("missing account transport diagnostic: %+v", logger.rows)
			}
		})
	}
}
