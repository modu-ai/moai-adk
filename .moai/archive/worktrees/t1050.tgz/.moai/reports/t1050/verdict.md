# sync-audit 판정서 — SPEC-SEAM-GREENFIELD-002 (카드 t1050)

- **판정: PASS-WITH-DEBT** (가중 조화평균 **0.913** / Tier S 임계 0.75)
- 감사 트리: `4ffab1948bec1d89252b5603c1928b25484661dc` (브랜치 `WT-greenfield-style`, `git status --porcelain` 무출력)
- 감사 세션: 독립 채널. 구현·문서 세션의 보고는 **주장**으로 취급했고, 아래 모든 행은 이 세션이 이 트리에서 직접 잰 값이다.
- 차단 결함 **0건**. 병합을 막는 사유는 없다. `WITH-DEBT` 는 되돌릴 수 없는 이력 결함 1건과 커버리지 미달 1건을 가시화하기 위한 표기이지, 품질 유보가 아니다.

---

## 1. 차원 점수

| 차원 | 가중 | 점수 | 판정 | 근거 요지 |
|---|---|---|---|---|
| Functionality | 40% | **0.96** | PASS | AC 6건(라벨 셀 7) 전부 재측정 PASS. RED 선행을 커밋 그래프로 확정. 뮤턴트 2방향을 레인보다 **넓은 범위**로 재실행해 재현 |
| Security | 25% | **0.95** | PASS | 신뢰 경계·입력 검증·비밀 취급 표면 없음. 유일한 안전 성질(사용자 문서 무단 재포맷 금지)이 뮤턴트 (b)로 기계 확인됨 |
| Craft | 20% | **0.86** | PASS | 가드 설계가 모범적(각 단정의 형태가 왜 하중을 받는지 주석이 서술). 커버리지 82.9% 로 패키지 목표 85% 에 2.1%p 미달(기존 baseline) |
| Consistency | 15% | **0.82** | PASS | 주변 스타일·커밋 규약·PRESERVE 양방향 준수. 착지한 커밋 메시지 1건이 자기 diff 에 반증됨 |

조화평균: `1 / (0.40/0.96 + 0.25/0.95 + 0.20/0.86 + 0.15/0.82)` = **0.913**.
must-pass(Functionality·Security) 둘 다 임계 상회 — firewall 통과.

---

## 2. 검증 대상별 판정 (전제 아님 — 각각 확립하거나 기각했다)

### 2.1 AC-SGF2-001..006 전부 PASS — **확립**

```
$ go test ./internal/settings/yamlpatch/... -run 'TestPatchFileGreenfieldOutputIsBlockStyle|TestPatchFileGreenfieldSecondSaveStaysBlock|TestPatchFileExistingBlockByteInvariant|TestPatchFileDeliberateFlowPreservedOnUpsert' -count=1 -v
--- PASS: TestPatchFileDeliberateFlowPreservedOnUpsert (0.00s)
--- PASS: TestPatchFileExistingBlockByteInvariant (0.00s)
--- PASS: TestPatchFileGreenfieldOutputIsBlockStyle (0.00s)
    --- PASS: TestPatchFileGreenfieldOutputIsBlockStyle/mcp (0.00s)
    --- PASS: TestPatchFileGreenfieldOutputIsBlockStyle/crosssession (0.00s)
    --- PASS: TestPatchFileGreenfieldOutputIsBlockStyle/cacheStrategy (0.00s)
    --- PASS: TestPatchFileGreenfieldOutputIsBlockStyle/gate (0.00s)
    --- PASS: TestPatchFileGreenfieldOutputIsBlockStyle/report (0.00s)
--- PASS: TestPatchFileGreenfieldSecondSaveStaysBlock (0.00s)
PASS
ok  	github.com/modu-ai/moai-adk/internal/settings/yamlpatch	0.306s
```

**빈 스윕 대조**: `-run` 필터가 실제로 물린 개수는 최상위 4 + 서브 5 = **9행**이며 위 출력에 전부 보인다. 아무것도 매치하지 않은 초록이 아니다.

추가로 **크로스플랫폼 빌드와 lint 를 이 세션이 다시 쟀다**(§E.2/E.5 는 레인 측정이라 인용에 불과했다):

```
$ GOOS=windows GOARCH=amd64 go build ./...
windows-build-exit=0

$ golangci-lint run ./internal/settings/yamlpatch/...
0 issues.
lint-exit=0
```

### 2.2 RED 채득이 수리보다 앞선다 — **확립**

```
$ git show --stat --format="%H%n%s%n%ci" d289130f1
d289130f1c34b1253dbe8b89e5e1eb028322189b
test(SPEC-SEAM-GREENFIELD-002): M2 RED guards for the greenfield flow-style defect
2026-09-22 03:59:28 +0900
 .moai/specs/.../acceptance.md |   2 +-
 .moai/specs/.../plan.md       |   2 +-
 .moai/specs/.../progress.md   |  79 ++++++++-
 .moai/specs/.../spec.md       |   4 +-
 internal/settings/yamlpatch/greenfield_style_test.go | 191 +++++++++++++++++++++

$ git show d289130f1 -- internal/settings/yamlpatch/yamlpatch.go
(무출력)

$ git merge-base --is-ancestor d289130f1 5fbc3baee ; echo $?
0
$ git merge-base --is-ancestor 5fbc3baee d289130f1 ; echo $?
1
```

**양방향으로 쟀다** — 한 방향만 재면 「앞섬」과 「무관」이 갈리지 않는다. RED 커밋은 프로덕션 파일을 한 바이트도 담지 않으며(위 무출력, 같은 커밋의 다른 경로는 5파일 비어 있지 않은 stat 이 양성 대조), 수리 커밋의 **진성 조상**이다. 순서 주장을 커밋 그래프가 증언한다.

### 2.3 뮤턴트 2방향 — **로그를 믿지 않고 재실행했고, 레인보다 넓은 범위로 확장했다**

로그는 과거 실행의 기록이고, 더 중요하게는 **m4-mutant-b.log 가 새 가드 4건만 돌렸다** — 그것으로는 「003b 가 유일 판별자인가」에 답할 수 없다. 그래서 두 뮤턴트를 **호출 가능한 모든 패키지**에 걸쳐 다시 돌렸다.

뮤턴트 주입 전 기준값: `shasum -a 256 internal/settings/yamlpatch/yamlpatch.go` = `572a32a56da9f093769638471e40ba4610e2644d5defd27a0497914fd5bc83ed`

**뮤턴트 (b) — 무조건 해제** (`yamlpatch.go:121` `if greenfield {` → `if greenfield || true {`)

```
$ go test ./internal/settings/... -count=1
ok  	github.com/modu-ai/moai-adk/internal/settings	0.496s
ok  	github.com/modu-ai/moai-adk/internal/settings/agentfm	0.114s
--- FAIL: TestPatchFileDeliberateFlowPreservedOnUpsert (0.02s)
    greenfield_style_test.go:189: deliberate flow style not preserved across an upsert.
        --- got  ---
        mcp: {tools: {a: {enabled: true}, b: {enabled: false}}}
        --- want ---
        {mcp: {tools: {a: {enabled: true}, b: {enabled: false}}}}
FAIL	github.com/modu-ai/moai-adk/internal/settings/yamlpatch	0.305s
```

```
$ go test ./internal/cli/ -count=1 -v -run '<init_workflow_flags_test.go 의 8개 Test 전부>'
--- PASS: TestInitCmd_WorkflowBranchGuardFlagsRegistered / TestApplyWorkflowBranchGuardFlags_ExplicitSet /
          TestApplyWorkflowBranchGuardFlags_UnsetFlagsStayUnset / TestRunWorkflowConfigStep_NonTerminalSkips /
          TestRunWorkflowConfigStep_AbsentWorkflowYAMLSkips / TestBuildWorkflowToggleEdits /
          TestReadWorkflowToggleDefaults / TestApplyWorkflowConfigEditsViaYamlpatch
ok  	github.com/modu-ai/moai-adk/internal/cli	0.974s
```

**판정: SPEC 의 「유일 판별자」 주장은 참이다.** `PatchFile` 을 호출하는 **모든** 패키지 — `internal/settings`(통제군 4건 + `sectionwrite`), `internal/settings/agentfm`, `internal/settings/yamlpatch`, `internal/cli`의 살아 있는 프로덕션 호출점 테스트 — 를 다 돌려도 (b) 를 잡는 것은 `TestPatchFileDeliberateFlowPreservedOnUpsert` **하나뿐**이다. 레인은 4건 필터로만 쟀으므로 이 주장은 레인의 증거로는 성립하지 않았다. 지금은 성립한다.

**뮤턴트 (a) — 해제 제거** (`if greenfield && false {`)

```
$ go test ./internal/settings/... -count=1
ok  	github.com/modu-ai/moai-adk/internal/settings	0.489s
ok  	github.com/modu-ai/moai-adk/internal/settings/agentfm	0.117s
--- FAIL: TestPatchFileGreenfieldSecondSaveStaysBlock (0.01s)
--- FAIL: TestPatchFileGreenfieldOutputIsBlockStyle (0.00s)
FAIL	github.com/modu-ai/moai-adk/internal/settings/yamlpatch	0.300s
```

부수 관측 하나를 덧붙인다 — 기존 통제군 `TestPatchFileGreenfieldCreation` 은 (a) 아래에서 **통과한다**. 즉 이 결함은 수리 전 가드 체계에 원리상 보이지 않았고, 신규 가드 2건이 실제로 새 판별력을 들여왔다. 철자 선택은 구현 세션의 `|| true` 계열을 따랐다 — 래퍼 삭제 철자는 `greenfield` 가 미사용이 되어 `[build failed]` 로 끝나며, 그것은 검출이 아니라 **미측정**이다(§E.9 의 주의를 이 세션도 독립 확인).

**복원 완전성** — 세 경로로 증명:

```
$ sed -n '121p' internal/settings/yamlpatch/yamlpatch.go
	if greenfield {
$ shasum -a 256 internal/settings/yamlpatch/yamlpatch.go
572a32a56da9f093769638471e40ba4610e2644d5defd27a0497914fd5bc83ed   ← 주입 전과 바이트 동일
$ git diff --stat
(무출력)
$ git status --porcelain
(무출력)
$ go test ./internal/settings/... -count=1
ok (3패키지 전부)
```

### 2.4 AC-SGF2-003b 비-공허성 — **확립, 그리고 SPEC 의 논증이 옳다**

세 성질을 따로 쟀다. (i) edit 이 upsert 다 — `{Path: []string{"mcp","tools","b","enabled"}}` 는 문서에 없는 키이므로 `lineSplice` 가 `idx < 0` 로 빠져 재직렬화 경로에 든다. (ii) 단정이 전체 리터럴 바이트 비교다 — `got != want` 한 줄. (iii) 위 2.3 의 넓은 스윕이 「유일 판별자」를 기계로 확정했다.

**「개행/들여쓰기 휴리스틱이 (b) 를 놓친다」는 SPEC 의 경고도 실측으로 확인된다** — 위 (b) 출력의 `got` 은 `mcp: {tools: …}` 이므로 「개행이 들어갔는가」도 「루트가 block 인가」도 **참**이다. 가장 먼저 떠오르는 단정이 하필 실패하는 단정이라는 서술이 맞다.

### 2.5 통제군 6건 무수정 GREEN — **확립**

행 앵커를 줄번호가 아니라 `^func` 콘텐츠 토큰으로 다시 뽑았고, `acceptance.md` 의 기재와 정확히 일치한다:

```
$ /usr/bin/grep -n "^func Test…" internal/settings/write_safety_test.go
29:func TestPatchFileValueInvariantPreservesBytes
52:func TestPatchFileScalarChangePreservesPresentation
320:func TestPatchFileSpliceFallsBackForUpsert
341:func TestPatchFileSpliceQuotedScalarChange
$ /usr/bin/grep -n "^func Test…" internal/settings/yamlpatch/yamlpatch_test.go
395:func TestPatchFileGreenfieldCreation
426:func TestAtomicWriteStatErrorNotWidened

$ git diff --stat 0a23f6a5d^..HEAD -- internal/settings/write_safety_test.go internal/settings/yamlpatch/yamlpatch_test.go
(무출력)
$ git diff --stat 0a23f6a5d^..HEAD -- internal/settings/yamlpatch/yamlpatch.go     ← 같은 형태의 양성 대조
 internal/settings/yamlpatch/yamlpatch.go | 30 +++++++++++++++++++++++++++++-
```

무수정 무출력은 공허하지 않다 — 같은 명령 형태가 바뀐 파일에서는 비어 있지 않다. 6건 전부 PASS(`internal/settings` 4 + `internal/settings/yamlpatch` 2, 양쪽 `ok`).

### 2.6 `@MX:ANCHOR` 주석 대 실측 — **프로덕션 수치는 정확, 테스트 수치는 범위가 불명시(F3)**

```
$ /usr/bin/grep -rn --include='*.go' "yamlpatch\.PatchFile(" .
./internal/settings/write_safety_test.go:35 / :58 / :326 / :354
./internal/settings/sectionwrite.go:18        ← 주석 줄. 호출점 아님
./internal/settings/sectionwrite.go:76        ← 프로덕션 호출점 1
./internal/cli/init_workflow_flags_test.go:234
./internal/cli/init_workflow_flags.go:97      ← 프로덕션 호출점 2
(8행)
```

적중 8행 중 `sectionwrite.go:18` 은 **주석**이다 — 적중 줄을 호출점으로 세면 9/8 이 아니라 3/2 가 된다. 이 함정을 주석 저자가 이미 피해 갔다: 프로덕션 **2파일 2호출점** 정확, 교차 패키지 테스트 **2파일 5호출점**(4+1) 정확.

부재 주장은 양성 대조와 함께 잰다:

```
$ /usr/bin/grep -rn "yamlpatch" internal/core/project/ ; echo "exit=$?"
exit=1                                   ← 0행
$ /usr/bin/grep -rn "settings" internal/core/project/ | head -4
internal/core/project/initializer_test.go:62: …
internal/core/project/autonomy_bundle.go:10: …
(비어 있지 않음 — 경로가 실재하고 계측기가 발화한다)
```

AC-SGF2-006 이 구속하는 두 항목(프로덕션 분포 + `internal/core/project` 부재)은 **정확히 일치**한다. 다만 F3 참조.

### 2.7 자가보고된 공정 결함 2건 — **리드의 처분은 타당하다. 기계적 파급 없음을 독립 확인**

(a) `3720f06db` 가 run 소유자의 `§E.3 run_commit_sha` hunk 를 흡수했고 `Authored-By-Agent: manager-docs` 를 단다 — 확인.
(b) 같은 커밋의 메시지가 「SS E.3's run_commit_sha placeholder is untouched」라고 적는데, **같은 커밋의 diff 가 그 줄을 `pending-backfill-run` → `f47a88d02` 로 바꾼다** — 확인. 자기 diff 에 반증되는 문장이다.

**리드의 기계 논거를 가정하지 않고 검증했다.** `OwnershipTransitionRule` 의 입력은 `spec.md` 에 대한 `git log --follow -p` 걷기다(`lint_ownership.go:202/215/219`, `lint_transition.go:124`):

```
$ git log --follow --oneline -- .moai/specs/SPEC-SEAM-GREENFIELD-002/spec.md
5eb3e493f docs(…): sync-phase artifacts + 3-phase close
d289130f1 test(…): M2 RED guards …
0a23f6a5d docs(…): plan …
          ← 3행 (양성 대조: 걷기가 비어 있지 않다)

$ git log --follow --format=%h -- …/spec.md | /usr/bin/grep -c "^3720f06db$"
0                                             ← 걷기에 없다

$ git log --follow -p … | /usr/bin/grep -E "^COMMIT |^[+-]status:"
COMMIT 5eb3e493f …   -status: in-progress / +status: completed
COMMIT d289130f1 …   -status: draft       / +status: in-progress
COMMIT 0a23f6a5d …                          +status: draft
```

`3720f06db` 는 `progress.md` 만 건드렸으므로 이 걷기에 **원리상 등장하지 않는다.** 따라서 그 트레일러는 어떤 상태 전이에도 귀속되지 않는다 — **리드의 논거 확인**.

전이를 실제로 실은 두 커밋의 트레일러도 따로 쟀고, 소유권이 맞는다:

```
$ git log 0a23f6a5d^..HEAD --format='=== %h %s%n%b' | /usr/bin/grep -E "^=== |^Authored-By-Agent:"
d289130f1 (draft → in-progress)   Authored-By-Agent: manager-develop   ← run 소유자, 일치
5eb3e493f (in-progress → completed) Authored-By-Agent: manager-docs    ← sync 소유자, 일치
```

`moai spec lint SPEC-SEAM-GREENFIELD-002` (트리에서 `go run ./cmd/moai` 로 빌드) = `✓ No findings`, exit 0 — 위 판정과 모순되지 않는다. 다만 이 초록은 **보강 증거일 뿐 하중을 받지 않는다**(G2 참조).

**처분 판정: 타당(sound).** 커밋은 착지했고 불변이며, 그 SHA 가 `progress.md` 의 증거 사슬에 인용돼 있어 이력 재작성은 인용을 무효화한다. 기계적 파급은 0 이다. `§E.4 Gaps` 의 기록은 **정확하고 완전하다** — 특히 「트레일러보다 커밋 메시지 쪽이 더 날카로운 결함」이라는 우선순위 판단에 동의한다. 나중에 누가 무엇을 했는지 복원하려는 독자가 신뢰하는 것이 메시지이기 때문이다. 원인 귀속(같은 턴에 같은 트리로 쓰기 주체 둘을 배차)도 옳다.

### 2.8 범위 규율 — **양방향 확립**

```
$ git diff --stat 0a23f6a5d^..HEAD -- internal/settings/sectionwrite.go internal/settings/sectionapply.go \
    internal/settings/sectionroute.go internal/web/ internal/settings/write_safety_test.go \
    internal/settings/yamlpatch/yamlpatch_test.go
(무출력)   ← plan.md §D PRESERVE 6항목 전부 잔존. 위 2.5 의 양성 대조가 이 명령 형태의 비-공허성을 보인다

$ /usr/bin/grep -n "8개 섹션" internal/settings/sectionwrite.go
3 / 12 / 14 / 57      ← spec.md §5 가 「고치지 말라」고 명명한 스테일 4곳, 손대지 않음
```

**「고치지 않음」도 규율이다** — 눈에 띄는 스테일 수치를 지나가며 고치지 않은 것이 §5 준수다.

`SPEC-SEAM-GREENFIELD-001`:

```
$ git show 0a23f6a5d -- .moai/specs/SPEC-SEAM-GREENFIELD-001/spec.md
  -related_specs: [… 3건]
  +related_specs: [… 3건, SPEC-SEAM-GREENFIELD-002]
  + | — (판 올리지 않음) | 2026-09-20 | GOOS | 범위 표기 추가 … |
  (정확히 2곳. status·본문·updated·progress.md 무변경)

$ git log --oneline 0a23f6a5d..HEAD -- .moai/specs/SPEC-SEAM-GREENFIELD-001/
(무출력)   ← plan 커밋 이후 무접촉
```

선언된 「정확히 두 가지」와 실측이 일치한다.

전체 변경 파일은 8개이며 전부 선언된 범위 안이다: SPEC-002 산출물 4 · SPEC-001 `spec.md` · `CHANGELOG.md` · 신설 테스트 1 · 수리 1.

### 2.9 커밋 규약 — **확립**

9개 커밋 전부 Conventional Commits, 전부 본문에 카드 id `t1050`, 전부 `🗿 MoAI` 트레일러(각각 `grep -c` = 9).

### 2.10 gitignore 된 증거의 생존 — **확립, 그리고 팀의 해소가 옳다**

```
$ git check-ignore -v .moai/reports/t1050/m4-mutant-b.log
.gitignore:227:.moai/reports/*	.moai/reports/t1050/m4-mutant-b.log
```

로그는 어떤 클론·CI 에도 닿지 않는다. 그러나 **판정을 받치는 verbatim 은 추적 파일에 있다**:

```
$ git ls-files --error-unmatch .moai/specs/SPEC-SEAM-GREENFIELD-002/progress.md
.moai/specs/SPEC-SEAM-GREENFIELD-002/progress.md
$ /usr/bin/grep -c "deliberate flow style not preserved across an upsert" …/progress.md
1
```

「인용한 것은 반출하고, 반출하지 않은 것은 인용하지 않는다」가 지켜졌다 — `.log` 는 편의 사본이고 하중은 인라인 verbatim 이 받는다. **중요한 증거는 gitignore 를 넘어 살아남는다.**

---

## 3. 결함 목록 (심각도 순)

| id | 심각도 | 구속 | 위치 | 내용 | 요구 수리 |
|---|---|---|---|---|---|
| **F1** | MEDIUM | non-blocking (되돌릴 수 없음) | 커밋 `3720f06db` 메시지 | 「SS E.3's run_commit_sha placeholder is untouched」가 **같은 커밋의 diff 에 반증**된다. 이력 복원자가 가장 신뢰하는 표면에 거짓 문장이 영구히 남는다 | **수리 없음이 옳다.** 착지·불변이고 SHA 가 증거 사슬에 인용돼 이력 재작성이 인용을 깬다. `§E.4 Gaps` 의 기록이 이미 정본 반증이며, 그것이 유효한 해소다 |
| **F2** | LOW | non-blocking | `internal/settings/yamlpatch` 커버리지 82.9% | `quality.yaml` 패키지 목표 85% 에 2.1%p 미달. 미달분은 `setScalar` 25.0% · `atomicWrite` 72.0% · `replaceScalarInLine` 71.4% · `renderScalar` 75.0% 네 함수에 몰려 있고 **넷 다 본 카드 무접촉**. 본 카드는 +0.3%p 올렸다 | 별도 카드. 본 카드에 귀속되지 않는 baseline 이며, 그 판정이 추측이 아니라 `go tool cover -func` 프로파일로 잰 것임을 확인했다 |
| **F3** | LOW | optional | `yamlpatch.go:52-55` `@MX:ANCHOR` | 「테스트 호출점 2파일 5호출점」에 **범위 수식어가 없다**. 실제로는 교차 패키지 호출점의 수이고, 패키지 내부 테스트 호출점(`greenfield_style_test.go` 5 · `yamlpatch_test.go` 17)은 세지 않았다. 「전체 테스트 호출점」으로 읽으면 22개를 놓친다 | 선택. 고친다면 「교차 패키지 테스트 호출점」으로 한정어 한 개 추가. AC-SGF2-006 이 구속하는 두 수치는 정확하므로 AC 판정에 영향 없음 |
| **F4** | INFO | non-blocking | 저장소 전역 규약 | `Authored-By-Agent:` 블록 뒤에 `🗿 MoAI` 가 오므로 **git 자신의 trailer 파서는 블록을 폐기한다** — `git log --format='%(trailers:key=Authored-By-Agent,valueonly)'` 가 9개 커밋 전부 빈 값을 낸다. 실제 소비자는 정규식(`lint_ownership.go:256`)이라 읽히지만, git 도구로 소유권을 재려는 사람은 0 을 얻는다 | 본 카드 범위 밖(저장소 전역 트레일러 관용구). 기록만 — **git 트레일러 도구를 이 축의 계측기로 쓰지 마라**가 이 항목의 행동 지침 |

**차단 결함 0건.** F1 은 `blocking` 으로 분류하지 않는다 — 수리 가능한 결함이 아니라 **이미 올바르게 처분된 영구 기록**이기 때문이다.

---

## 4. Gaps — 이 감사가 **관측하지 않은** 것

- **G1 — 전체 스위트를 재실행하지 않았다.** 배차 지시(`go test ./...` 금지, `./internal/cli/...` 17분)에 따랐다. `CHANGELOG` 와 `§E.3` 의 「21 패키지 exit 0」은 레인의 1차 관측을 **인용**한 것이며 이 세션의 측정이 아니다. 판단 근거: 변경은 `yamlpatch` 스타일 결정 한 곳이고, 그것을 관측할 수 있는 패키지는 `PatchFile` 호출자뿐이라 §2.3 의 표적 스윕이 같은 결론을 더 싸게 낸다. 전 패키지 판정은 `origin/develop` CI 몫이다.
- **G2 — `OwnershipTransitionRule` 이 이 문서에서 발화하는 것을 직접 보지 못했다.** `moai spec lint` 의 `✓ No findings` 는 **양성 대조 없는 0** 이다(그 룰이 이 코퍼스에서 발화하는 사례를 따로 잡지 않았다). 그래서 §2.7 의 판정은 lint 초록이 아니라 **걷기 측정**(`git log --follow`, 3행 비-공허 + `3720f06db` 부재)에 하중을 두었다. lint 초록은 모순 없음을 확인하는 보강일 뿐이다.
- **G3 — 저장소 전역 lint 미측정.** `golangci-lint run` 을 `./internal/settings/yamlpatch/...` 한정으로 돌렸다. 이 `0 issues.` 를 「저장소에 지적 없음」으로 읽으면 재지 않은 범위를 잰 것으로 승격시키는 오독이다.
- **G4 — 워크트리 가드에 명령 2건이 거부됐다.** (i) `for c in …; do … git log -1 …; done` 루프, (ii) `sed -n "$(grep -n … | cut -d: -f1),+25p"` 런타임 계산 인자. **둘 다 우회하지 않고 평문 단일 명령으로 다시 써서 같은 값을 얻었다**(각각 `git log <range> --format=…` 와 `awk` 범위 추출). 대체 수단이 추론이 아니라 동등한 측정이므로 결과에 미측정이 남지 않았다. 거부는 런타임 결함이 아니라 가드가 명령을 읽은 것이다.
- **G5 — 변경 전 트리에서 커버리지를 직접 재지 않았다.** 82.6% → 82.9% 는 현재 프로파일로부터의 역산이라고 `§E.3` 이 스스로 표시했고, 이 세션도 역산을 재현하지 않았다. 82.9% 자체는 직접 쟀다.
- **G6 — 뮤턴트 스윕 범위는 `PatchFile` 호출자에 한정된다.** `internal/settings/...` 전량 + `internal/cli` 의 `init_workflow_flags_test.go` 8건. `internal/cli` 의 나머지 테스트는 돌리지 않았다 — 그 패키지의 다른 코드가 `PatchFile` 을 호출하지 않음은 §2.6 의 저장소 전역 grep 이 받친다.

---

## 5. 잔여 위험

- **관측한 것에도 불구하고 틀릴 수 있는 지점**: §2.3 의 「유일 판별자」는 **현재 테스트 자산 기준**이다. 앞으로 누군가 `003b` 셀을 스칼라 교체로 되돌리거나 단정을 휴리스틱으로 바꾸면, 그 순간 (b) 방향 과잉 수리가 **저장소 전체에서 무검출**이 된다 — 두 번째 그물이 없다. 가드 파일의 주석이 이 사실을 서술하고 있으나 주석은 기계가 아니다.
- `PatchFile` 이 만드는 파일의 **들여쓰기 폭**은 어떤 AC 도 단정하지 않는다(`acceptance.md §D` 가 의도적으로 열어 둠). 형제 파일 관례와 어긋나도 이 감사는 그것을 결함으로 보지 않았다.
- F1 이 남긴 위험은 기계가 아니라 **사람**에게 있다: 이 브랜치 이력을 읽는 다음 사람이 `3720f06db` 의 메시지를 믿고 `§E.3` 의 저자를 오인할 수 있다. 완화는 `§E.4 Gaps` 의 기록이 발견될 확률에 달려 있다.
- 미푸시 브랜치다. 9개 커밋 전부 이 워크트리에만 있으므로 **원격 병합이 확인되기 전 폐기 금지**.

---

## 6. 감사 무결성

- 이 세션이 만진 것: 뮤턴트 주입 2회(`yamlpatch.go:121` 한 줄), 각각 복원. 최종 `shasum` 이 주입 전과 바이트 동일하고 `git diff --stat` · `git status --porcelain` 양쪽 무출력.
- 이 세션이 쓴 파일: 본 판정서 1개뿐. 소스·테스트·SPEC 산출물 무변경.
- 모든 부재 주장은 `/usr/bin/grep` 으로 채득했고 같은 경로의 비-공허 양성 대조를 나란히 인용했다.
- 모든 인용은 커맨드 + verbatim + 트리 SHA `4ffab1948` 를 동반한다.
