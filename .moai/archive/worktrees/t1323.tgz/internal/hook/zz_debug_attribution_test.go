package hook

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func TestZZDebugAttributionScan(t *testing.T) {
	_, thisFile, _, _ := runtime.Caller(0)
	t.Logf("caller file: %s", thisFile)
	dir := filepath.Dir(thisFile)
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			t.Logf("module root: %s", dir)
			break
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("no go.mod")
		}
		dir = parent
	}
	path := filepath.Join(dir, ".moai", "config", "sections", "workflow.yaml")
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read %s: %v", path, err)
	}
	inBlock := false
	for i, line := range strings.Split(string(data), "\n") {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "commit_identity_guard:") {
			t.Logf("line %d: block entry (%q)", i+1, line)
			inBlock = true
			continue
		}
		if inBlock {
			if line != "" && !strings.HasPrefix(line, " ") && !strings.HasPrefix(line, "\t") {
				t.Logf("line %d: block exit (%q)", i+1, line)
				inBlock = false
				continue
			}
			if strings.HasPrefix(trimmed, "enabled:") {
				t.Logf("line %d: enabled = %q", i+1, strings.TrimSpace(strings.TrimPrefix(trimmed, "enabled:")))
			}
		}
	}
}
