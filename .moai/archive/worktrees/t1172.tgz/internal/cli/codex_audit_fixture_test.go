//go:build !windows

package cli

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestCodexAuditCar010FixtureUsesOptInWriter(t *testing.T) {
	root := t.TempDir()
	config := codexAuditProjectConfig(t, root, filepath.Join(root, "moai-wrapper"))
	if strings.Count(config, "[mcp_servers.moai.tools.codex_role_audit]") != 1 ||
		strings.Count(config, "approval_mode = \"approve\"") != 1 {
		t.Fatalf("expected one per-tool approval, got %q", config)
	}
	if !strings.Contains(config, "default_tools_approval_mode = \"writes\"") ||
		strings.Contains(config, "default_tools_approval_mode = \"approve\"") {
		t.Fatalf("server-wide approval changed: %q", config)
	}
	workflow, err := os.ReadFile(filepath.Join(root, ".moai", "config", "sections", "workflow.yaml"))
	if err != nil || !strings.Contains(string(workflow), "enabled: true") {
		t.Fatalf("project opt-in missing: %v %q", err, workflow)
	}
	decoy := codexAuditDecoyConfig(filepath.Join(root, "decoy-wrapper"))
	if !strings.Contains(decoy, `enabled_tools = ["spec_progress"]`) ||
		strings.Contains(decoy, "codex_role_audit") {
		t.Fatalf("decoy exposes audit tool: %q", decoy)
	}
}
