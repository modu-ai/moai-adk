package hook

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/modu-ai/moai-adk/internal/config"
	"github.com/modu-ai/moai-adk/pkg/models"
)

// testFixedNow is a stable reference time for staleness tests.
var testFixedNow = time.Date(2026, 4, 25, 12, 0, 0, 0, time.UTC)

// Model-id expectations follow SPEC-MODEL-MATRIX-UPDATE-001 DR-2: the built-in
// glmContextWindows table dropped the seven retired ids (glm-5.2,
// glm-4.5-air, …), so a retired id now resolves to 0 and both hooks leave the
// env keys unset; llm.yaml glm.context_windows is the override path for any
// custom id.
func TestMaybeSet1MAutoCompactWindow(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name       string
		env        map[string]string
		wantWindow string // "" means expect the key unset
	}{
		{name: "glm-5.3 resolves to 1M, no window → sets 1M", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-5.3"}, wantWindow: "1000000"},
		{name: "glm-4.5-air (removed id) resolves to 0, no window → unset", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-4.5-air"}, wantWindow: ""},
		{name: "claude model → unset (ResolveGLMContextWindow returns 0 for claude-prefixed)", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "claude-opus-4-8"}, wantWindow: ""},
		{name: "window already set → preserved, not overwritten", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-5.2", config.EnvClaudeCodeAutoCompactWindow: "500000"}, wantWindow: "500000"},
		{name: "empty opus model → unset", env: map[string]string{}, wantWindow: ""},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			maybeSet1MAutoCompactWindow(tt.env)
			if got := tt.env[config.EnvClaudeCodeAutoCompactWindow]; got != tt.wantWindow {
				t.Errorf("CLAUDE_CODE_AUTO_COMPACT_WINDOW = %q, want %q", got, tt.wantWindow)
			}
		})
	}
}

func TestMaybeDeclareGLMContextWindow(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name     string
		env      map[string]string
		wantDecl string // "" means expect the key unset
	}{
		{name: "glm-5.3 resolves to 1M → declares 1000000", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-5.3"}, wantDecl: "1000000"},
		{name: "glm-4.5-air (removed id) resolves to 0, no declaration → unset", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-4.5-air"}, wantDecl: ""},
		{name: "claude model → unset (ResolveGLMContextWindow returns 0 for claude-prefixed)", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "claude-opus-4-8"}, wantDecl: ""},
		{name: "declaration already set → preserved, not overwritten", env: map[string]string{"ANTHROPIC_DEFAULT_OPUS_MODEL": "glm-5.3", config.EnvClaudeCodeMaxContextTokens: "500000"}, wantDecl: "500000"},
		{name: "empty opus model → unset", env: map[string]string{}, wantDecl: ""},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			maybeDeclareGLMContextWindow(tt.env)
			if got := tt.env[config.EnvClaudeCodeMaxContextTokens]; got != tt.wantDecl {
				t.Errorf("CLAUDE_CODE_MAX_CONTEXT_TOKENS = %q, want %q", got, tt.wantDecl)
			}
		})
	}
}

// TestEnsureGLMCredentials_ExistingTokenDeclaresContextWindow is the PR #1574
// review regression: with credentials already present (the steady state), the
// hook must still ensure the context-window envs — settings written by an
// older binary carry neither window key, and without the declaration Claude
// Code assumes a 200K window for the custom GLM model ID.
//
// `moai glm setup` is NOT such a source, though an earlier revision of this
// comment named it alongside the older binary: it writes ~/.moai/.env.glm only
// and never produces a settings.local.json env block (card t803).
func TestEnsureGLMCredentials_ExistingTokenDeclaresContextWindow(t *testing.T) {
	t.Setenv(config.EnvMoaiLaunchProvider, "")

	dir := t.TempDir()
	claudeDir := filepath.Join(dir, ".claude")
	_ = os.MkdirAll(claudeDir, 0o755)
	settings := `{"env":{"ANTHROPIC_DEFAULT_OPUS_MODEL":"glm-5.3","ANTHROPIC_AUTH_TOKEN":"existing-key"},"other":"preserved"}`
	settingsPath := filepath.Join(claudeDir, "settings.local.json")
	_ = os.WriteFile(settingsPath, []byte(settings), 0o644)

	msg := ensureGLMCredentials(dir)
	if msg != "" {
		t.Errorf("expected empty msg when AUTH_TOKEN exists, got %q", msg)
	}

	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("read settings: %v", err)
	}
	var raw struct {
		Env   map[string]string `json:"env"`
		Other string            `json:"other"`
	}
	if err := json.Unmarshal(data, &raw); err != nil {
		t.Fatalf("parse settings: %v", err)
	}
	if got := raw.Env["CLAUDE_CODE_MAX_CONTEXT_TOKENS"]; got != "1000000" {
		t.Errorf("CLAUDE_CODE_MAX_CONTEXT_TOKENS = %q, want %q", got, "1000000")
	}
	if got := raw.Env["CLAUDE_CODE_AUTO_COMPACT_WINDOW"]; got != "1000000" {
		t.Errorf("CLAUDE_CODE_AUTO_COMPACT_WINDOW = %q, want %q", got, "1000000")
	}
	if raw.Other != "preserved" {
		t.Errorf("non-env key lost on rewrite: other = %q", raw.Other)
	}
}

// TestEnsureGLMCredentials_ExistingTokenNoChurnWhenKeysPresent asserts the
// steady state does not rewrite settings.local.json when both window keys are
// already present — avoiding per-session churn against concurrent sessions
// that mutate the same file.
func TestEnsureGLMCredentials_ExistingTokenNoChurnWhenKeysPresent(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()
	claudeDir := filepath.Join(dir, ".claude")
	_ = os.MkdirAll(claudeDir, 0o755)
	settings := `{"env":{"ANTHROPIC_DEFAULT_OPUS_MODEL":"glm-5.3","ANTHROPIC_AUTH_TOKEN":"existing-key","CLAUDE_CODE_AUTO_COMPACT_WINDOW":"1000000","CLAUDE_CODE_MAX_CONTEXT_TOKENS":"1000000"}}`
	settingsPath := filepath.Join(claudeDir, "settings.local.json")
	_ = os.WriteFile(settingsPath, []byte(settings), 0o644)

	if msg := ensureGLMCredentials(dir); msg != "" {
		t.Errorf("expected empty msg, got %q", msg)
	}

	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("read settings: %v", err)
	}
	if string(data) != settings {
		t.Error("settings.local.json rewritten although window keys were already present")
	}
}

func TestSessionStartHandler_EventType(t *testing.T) {
	t.Parallel()

	cfg := &mockConfigProvider{cfg: newTestConfig()}
	h := NewSessionStartHandler(cfg)

	if got := h.EventType(); got != EventSessionStart {
		t.Errorf("EventType() = %q, want %q", got, EventSessionStart)
	}
}

func TestSessionStartHandler_Handle(t *testing.T) {
	// Not parallel: t.Setenv("ANTHROPIC_BASE_URL", "") isolates the GLM
	// PROCESS env so glmGuardrailReminder() returns "" on a developer
	// machine running CG mode (where the tmux session carries a real
	// z.ai base URL). Without this isolation, the "nil config" and
	// "empty project config" subtests fail because the GLM reminder is
	// injected into HookSpecificOutput.AdditionalContext even when
	// SessionID/ProjectDir is empty. This matches the non-parallel +
	// t.Setenv pattern used by TestGLMGuardrailReminder_* siblings in
	// session_start_glm_guardrail_test.go. The SUT is correct per
	// SPEC-STEERING-ALIGN-GUARDRAIL-HOOK-001 REQ-GH-002 — the test must
	// isolate the env, not weaken the SUT.
	t.Setenv("ANTHROPIC_BASE_URL", "")

	// Isolate the kanban PROCESS env as well: a session launched by the
	// kanban launcher carries MOAI_KANBAN_* variables, and
	// kanbanBootstrapNotice() injects its notice into AdditionalContext even
	// when SessionID/ProjectDir is empty — breaking the "nil config" and
	// "empty project config" subtests below. Same isolation as the kanban
	// notice tests in session_start_kanban_test.go.
	clearKanbanEnv(t)

	tests := []struct {
		name         string
		cfg          *config.Config
		input        *HookInput
		wantDecision string
		wantDataKeys []string
	}{
		{
			name: "normal session initialization with project config",
			cfg: func() *config.Config {
				c := newTestConfig()
				c.Project = models.ProjectConfig{
					Name:     "moai-adk-go",
					Type:     models.ProjectTypeCLI,
					Language: "go",
				}
				return c
			}(),
			input: &HookInput{
				SessionID:     "sess-abc-123",
				CWD:           t.TempDir(),
				HookEventName: "SessionStart",
				ProjectDir:    t.TempDir(),
			},
			wantDecision: DecisionAllow,
			wantDataKeys: []string{"project_name"},
		},
		{
			name: "session start with nil config returns allow",
			cfg:  nil,
			input: &HookInput{
				SessionID:     "sess-nil-cfg",
				CWD:           t.TempDir(),
				HookEventName: "SessionStart",
			},
			wantDecision: DecisionAllow,
		},
		{
			name: "session start with empty project config returns allow",
			cfg:  newTestConfig(),
			input: &HookInput{
				SessionID:     "sess-empty",
				CWD:           t.TempDir(),
				HookEventName: "SessionStart",
			},
			wantDecision: DecisionAllow,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Subtest inherits non-parallel parent (GLM env isolated above).

			cfg := &mockConfigProvider{cfg: tt.cfg}
			h := NewSessionStartHandler(cfg)

			ctx := context.Background()
			got, err := h.Handle(ctx, tt.input)

			if err != nil {
				t.Fatalf("unexpected error: %v", err)
			}
			if got == nil {
				t.Fatal("got nil output")
			}
			// SPEC-V3R6-SESSION-ID-ATTRIBUTION-REPAIR-001 M3 (REQ-RDP-004):
			// SessionStart now legitimately uses hookSpecificOutput.AdditionalContext
			// to surface this orchestrator's own UUID to the Claude Code runtime
			// (the documented SessionStart stdout contract per hooks-system.md
			// § Hook Event stdin/stdout Reference). The injection is gated on
			// SessionID != "" AND ProjectDir != "". When either is empty,
			// HookSpecificOutput remains nil (no UUID to inject).
			if tt.input.SessionID != "" && tt.input.ProjectDir != "" {
				if got.HookSpecificOutput == nil || got.HookSpecificOutput.AdditionalContext == "" {
					t.Errorf("REQ-RDP-004: HookSpecificOutput.AdditionalContext should be set when SessionID+ProjectDir non-empty")
				}
			} else if got.HookSpecificOutput != nil && got.HookSpecificOutput.AdditionalContext != "" {
				t.Errorf("AdditionalContext should NOT be injected when SessionID or ProjectDir is empty, got %+v", got.HookSpecificOutput)
			}

			if len(tt.wantDataKeys) > 0 && got.Data != nil {
				var data map[string]any
				if err := json.Unmarshal(got.Data, &data); err != nil {
					t.Fatalf("unmarshal data: %v", err)
				}
				for _, key := range tt.wantDataKeys {
					if _, ok := data[key]; !ok {
						t.Errorf("data missing key %q", key)
					}
				}
			}
		})
	}
}

func TestEnsureGLMCredentials(t *testing.T) {
	t.Setenv(config.EnvMoaiLaunchProvider, "")
	// .env.glm is staged under a temp HOME; drop the TestMain MOAI_HOME
	// sandbox so the lookup derives from HOME (card t1229).
	t.Setenv(config.EnvHome, "")
	// Not parallel: subtests use t.Setenv which requires non-parallel parent

	t.Run("no settings file", func(t *testing.T) {
		t.Parallel()
		msg := ensureGLMCredentials(t.TempDir())
		if msg != "" {
			t.Errorf("expected empty msg for missing file, got %q", msg)
		}
	})

	t.Run("no GLM models in settings", func(t *testing.T) {
		t.Parallel()
		dir := t.TempDir()
		claudeDir := filepath.Join(dir, ".claude")
		_ = os.MkdirAll(claudeDir, 0o755)
		settings := `{"env":{"SOME_VAR":"value"}}`
		_ = os.WriteFile(filepath.Join(claudeDir, "settings.local.json"), []byte(settings), 0o644)

		msg := ensureGLMCredentials(dir)
		if msg != "" {
			t.Errorf("expected empty msg for non-GLM settings, got %q", msg)
		}
	})

	t.Run("GLM models with AUTH_TOKEN already present", func(t *testing.T) {
		t.Parallel()
		dir := t.TempDir()
		claudeDir := filepath.Join(dir, ".claude")
		_ = os.MkdirAll(claudeDir, 0o755)
		settings := `{"env":{"ANTHROPIC_DEFAULT_OPUS_MODEL":"glm-5.1","ANTHROPIC_AUTH_TOKEN":"existing-key"}}`
		_ = os.WriteFile(filepath.Join(claudeDir, "settings.local.json"), []byte(settings), 0o644)

		msg := ensureGLMCredentials(dir)
		if msg != "" {
			t.Errorf("expected empty msg when AUTH_TOKEN exists, got %q", msg)
		}
	})

	t.Run("GLM models without AUTH_TOKEN auto-injects from env.glm", func(t *testing.T) {
		dir := t.TempDir()
		claudeDir := filepath.Join(dir, ".claude")
		_ = os.MkdirAll(claudeDir, 0o755)
		settings := `{"env":{"ANTHROPIC_DEFAULT_OPUS_MODEL":"glm-5.1","ANTHROPIC_DEFAULT_SONNET_MODEL":"glm-4.7"}}`
		_ = os.WriteFile(filepath.Join(claudeDir, "settings.local.json"), []byte(settings), 0o644)

		// Create fake ~/.moai/.env.glm
		fakeHome := t.TempDir()
		moaiDir := filepath.Join(fakeHome, ".moai")
		_ = os.MkdirAll(moaiDir, 0o755)
		_ = os.WriteFile(filepath.Join(moaiDir, ".env.glm"), []byte("GLM_API_KEY=\"test-glm-key-123\"\n"), 0o600)
		t.Setenv("HOME", fakeHome)
		t.Setenv("USERPROFILE", fakeHome) // Windows: os.UserHomeDir reads USERPROFILE

		msg := ensureGLMCredentials(dir)
		if msg == "" {
			t.Error("expected non-empty msg when credentials auto-injected")
		}

		// Verify settings.local.json was updated
		data, err := os.ReadFile(filepath.Join(claudeDir, "settings.local.json"))
		if err != nil {
			t.Fatalf("read updated settings: %v", err)
		}

		var raw map[string]json.RawMessage
		if err := json.Unmarshal(data, &raw); err != nil {
			t.Fatalf("parse updated settings: %v", err)
		}

		var env map[string]string
		if err := json.Unmarshal(raw["env"], &env); err != nil {
			t.Fatalf("parse env: %v", err)
		}

		if env["ANTHROPIC_AUTH_TOKEN"] != "test-glm-key-123" {
			t.Errorf("AUTH_TOKEN = %q, want %q", env["ANTHROPIC_AUTH_TOKEN"], "test-glm-key-123")
		}
		if env["ANTHROPIC_BASE_URL"] != "https://api.z.ai/api/anthropic" {
			t.Errorf("BASE_URL = %q, want Z.AI endpoint", env["ANTHROPIC_BASE_URL"])
		}
		if env["CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS"] != "1" {
			t.Error("DISABLE_EXPERIMENTAL_BETAS should be set to 1")
		}
	})
}

// T-016: Windows CLAUDE_ENV_FILE injection

// TestInjectCLAUDEEnvFile_WithEnvFile verifies that injectCLAUDEEnvFile sets
// CLAUDE_ENV_FILE in settings.local.json when a .env file exists in the project.
func TestInjectCLAUDEEnvFile_WithEnvFile(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()
	claudeDir := filepath.Join(dir, ".claude")
	if err := os.MkdirAll(claudeDir, 0o755); err != nil {
		t.Fatal(err)
	}
	// Create a .env file in the project root
	envFilePath := filepath.Join(dir, ".env")
	if err := os.WriteFile(envFilePath, []byte("SOME_VAR=value\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	msg := injectCLAUDEEnvFile(dir)
	if msg == "" {
		t.Error("injectCLAUDEEnvFile: expected non-empty message when .env exists")
	}

	// Verify settings.local.json was written with CLAUDE_ENV_FILE
	settingsPath := filepath.Join(claudeDir, "settings.local.json")
	data, err := os.ReadFile(settingsPath)
	if err != nil {
		t.Fatalf("settings.local.json not created: %v", err)
	}
	var settings struct {
		Env map[string]string `json:"env"`
	}
	if err := json.Unmarshal(data, &settings); err != nil {
		t.Fatalf("unmarshal settings.local.json: %v", err)
	}
	if settings.Env["CLAUDE_ENV_FILE"] != envFilePath {
		t.Errorf("CLAUDE_ENV_FILE = %q, want %q", settings.Env["CLAUDE_ENV_FILE"], envFilePath)
	}
}

// TestInjectCLAUDEEnvFile_NoEnvFile verifies that injectCLAUDEEnvFile is a
// no-op when no .env file exists (returns empty string).
func TestInjectCLAUDEEnvFile_NoEnvFile(t *testing.T) {
	t.Parallel()

	dir := t.TempDir()
	msg := injectCLAUDEEnvFile(dir)
	if msg != "" {
		t.Errorf("injectCLAUDEEnvFile: expected empty msg when no .env, got %q", msg)
	}
}

// TestSessionStart_MemoryStaleWrap verifies AC-EXT001-07:
// when a memory file is older than 24h, it is wrapped in <system-reminder>.
func TestSessionStart_MemoryStaleWrap(t *testing.T) {
	t.Parallel()

	projectDir := t.TempDir()
	// Create .claude/agent-memory/expert-backend/ with a stale memory file.
	agentMemDir := filepath.Join(projectDir, ".claude", "agent-memory", "expert-backend")
	if err := os.MkdirAll(agentMemDir, 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}

	memPath := filepath.Join(agentMemDir, "note.md")
	content := "---\nname: test\ndescription: d\ntype: user\n---\nbody\n"
	if err := os.WriteFile(memPath, []byte(content), 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}
	// Set mtime to 25h ago.
	staleTime := testFixedNow.Add(-25 * time.Hour)
	if err := os.Chtimes(memPath, staleTime, staleTime); err != nil {
		t.Fatalf("Chtimes: %v", err)
	}

	result := detectAndWrapStaleMemories(projectDir, testFixedNow)
	if result == "" {
		t.Fatal("detectAndWrapStaleMemories returned empty string; expected staleness caveat")
	}
	if !strings.Contains(result, "<system-reminder>") {
		t.Error("result does not contain <system-reminder>")
	}
	if !strings.Contains(result, "verify against current state") {
		t.Error("result does not contain staleness caveat phrase")
	}
}

// TestSessionStart_AuditDisabled verifies MOAI_MEMORY_AUDIT=0 skips staleness detection.
// Not parallel: uses t.Setenv.
func TestSessionStart_AuditDisabled(t *testing.T) {
	t.Setenv("MOAI_MEMORY_AUDIT", "0")

	projectDir := t.TempDir()
	agentMemDir := filepath.Join(projectDir, ".claude", "agent-memory", "expert-backend")
	if err := os.MkdirAll(agentMemDir, 0o755); err != nil {
		t.Fatalf("MkdirAll: %v", err)
	}
	memPath := filepath.Join(agentMemDir, "note.md")
	if err := os.WriteFile(memPath, []byte("---\nname: t\ndescription: d\ntype: user\n---\nbody\n"), 0o644); err != nil {
		t.Fatalf("WriteFile: %v", err)
	}
	staleTime := testFixedNow.Add(-25 * time.Hour)
	if err := os.Chtimes(memPath, staleTime, staleTime); err != nil {
		t.Fatalf("Chtimes: %v", err)
	}

	result := detectAndWrapStaleMemories(projectDir, testFixedNow)
	if result != "" {
		t.Errorf("detectAndWrapStaleMemories with MOAI_MEMORY_AUDIT=0 = %q, want empty", result)
	}
}
