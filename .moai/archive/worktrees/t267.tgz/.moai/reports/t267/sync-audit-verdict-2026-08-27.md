# Sync-Phase Audit Verdict — SPEC-TEAMMATE-REVIVAL-GUARD-001 (card t267)

- 감사일: 2026-08-27 · 감사자: sync-auditor (독립 신규 컨텍스트 — 구현 물산출물에 관여 없음)
- 대상 범위: branch `WT-taskstop-name-reclaim`, diff `c9eed8ac6..c572fd8a9` (총 13커밋 = plan-phase 4 + run/sync 8 + docs 후속 1; 리드가 열거한 9커밋은 run 체인 `7759b8130`→`c572fd8a9`)
- 범위 연장 이력: 최초 배포 범위는 `c9eed8ac6..90f7ad3e3` — 감사 착수 시점에 이미 HEAD가 `c572fd8a9`였으므로 전 기계적 검증(테스트·커버리지·빌드·린트·grep·로그 판독)은 연장 종점에서 수행됨. 리드의 범위 연장 통보 후 `c572fd8a9`의 정확한 diff를 추가 검증: progress.md §E.4 `close_statement` 1줄(+1/−1) — M1~M3 체인 나열을 §E.3 closure note 인용(종점 `a1a908802`)으로 중복 제거. 동일 SHA들이 §E.3·CHANGELOG에 잔존하므로 주장 변화 없음. docs-only, 코드 표면 무변화, 평정 불변.

## 평정 (Verdict)

**PASS** — 4차원 조화평균 **92.7 / 100**

| 차원 | 가중치 | 점수 | 판정 | 핵심 근거 |
|---|---|---|---|---|
| Functionality | 40% | 94 | PASS | AC-TRG-001..011 전건 재검증 통과 — 단위 25테스트 PASS/0 FAIL, 라이브 감사로그 7행이 §E.2 주장과 행 단위 일치 |
| Security | 25% | 93 | PASS | deny는 "registry hit + gate enabled" 곱조건으로만 도달(코드 검증), 역방향 fail-open 전 경로 테스트 고정, 메시지 본문 미기록 |
| Craft | 20% | 90 | PASS | hook 커버리지 85.1%(base 84.7%→개선, 85% 임계 충족), lint 0건, 양방향 뮤턴트 고정 |
| Consistency | 15% | 94 | PASS | CHANGELOG 기호·경로·커밋 전건 실재 확인, 트윈 동일(Origin 라인만 상이), 레시피 실측 예시 재현 |

조화평균 = 4 / (1/94 + 1/93 + 1/90 + 1/94) = **92.7**

## 1. Claim (주장)

SPEC의 3-phase 종결 주장 — 즉 AC 11개 전건 PASS, fail-open 가드의 기계적 시행, 템플릿 중립 배포, config 캐시 스키마 수선, 그리고 §E.2/§E.4/CHANGELOG의 모든 검증 주장 — 이 트리에서 지지된다.

## 2. Evidence (증거 — 이번 실행에서 관측된 명령 + 출력)

### Functionality

| 관측 | 명령 → 출력 |
|---|---|
| 영향 패키지 스위트+커버리지 | `go test -count=1 -cover ./internal/hook/ ./internal/config/` → `ok internal/hook 33.788s coverage: 85.1%` · `ok internal/config 1.946s coverage: 80.6%` |
| AC 결속 테스트 | `go test -v -run 'TestRecordAgentStop\|TestAgentStopGuard\|TestSpawn…\|TestSessionEndClearsStops\|…' ./internal/hook/` → 최상위 `--- PASS` 25건 / `--- FAIL` 0건 |
| 기본값 테스트 | `go test -run TestWorkflowAgentStopDefaultFalse ./internal/config/ -v` → `--- PASS (0.00s)` |
| 라이브 감사로그 | `.moai/logs/agent-stop-audit.jsonl` 7행: 05:43:06Z `stop_recorded`(세션 612bd790) / 17:12:48Z `stop_recorded` → 17:12:53Z·17:13:10Z `send_denied` ×2 → 17:13:21Z `respawn_cleared` → 17:13:27Z `send_observed`(허용) → 17:13:33Z `send_observed name=main` — §E.2 AC-TRG-010 기술과 행 단위 일치 |
| 코드 대 AC 정독 | `agent_stop_guard.go:386` deny는 `hit != nil && h.agentStopGuardEnabled()` 곱조건 단일 도달경로; `parseSendRecipient`(`agent_stop_guard.go:267-291`)는 `[ref]` 접미사를 비교 전 파싱·제거(불완전 형태는 미조치→미매치→fail-open); `lookupAgentStopEntry`(`:180-197`)는 Name/AgentID **양필드** 매칭 — live shape `{"name":"","agent_id":"<spawn-name>"}`(레지스트리 잔여물 및 `TestExtractTaskStopTargetLiveShape`로 확인)에서 이름 주소_send가 AgentID 경로로 거부됨; `clearStoppedEntryOnRespawn`(`:447`)은 Agent\|Task 분기에서 PreToolUse 시점(스폰 진행 전) 실행; `ClearAgentStops`(`:479`)는 SessionEnd에서 파일 제거+`session_cleared` 행 |
| 배선 | `.claude/settings.json` + 템플릿 트윈 `"matcher": "SendMessage|TaskStop"` 각 1건(기존 pre-tool 래퍼 재사용, 신규 래퍼·신규 하위커맨드 0 — diff 파일목록으로 확인); matcher-less PostToolUse → `handle-harness-observe.sh` dispatch 존재 확인, `internal/cli/hook.go:726-734`가 `ToolName == "TaskStop"` → `RecordAgentStop`을 learning gate **이전**에 호출 |
| 레지스트리 잔여 | `.moai/state/agent-stops/` 빈 디렉터리 — 청소 계약과 일치 |

### Security

- **deny 도달경로**: `checkStopGuard`에서 거부는 "파싱된 수신자 × 동일 세션 레지스트리 생존 엔트리 매칭 × 게이트 활성"의 유일한 곱조건. `agentStopGuardEnabled`(`:338-347`)는 nil cfg / nil Config → false. `TestAgentStopGuardNilConfigNeverDenies`가 이를 고정.
- **역방향 fail-open**(malformed input이 거부하는 경로 부재): 파싱 실패→`parsed=false`→조회 없음→허용; corrupt 레지스트리→`loadAgentStopRegistry` nil→허용. `TestAgentStopGuardUncertainNeverDenies` 3변형 + 미매치 이름/`main`/`notify_when_idle` 허용(`TestAgentStopGuardLiveTeammatesUnaffected`) 고정.
- **비밀 미유출**: 감사 레지스트리 구조체는 `{timestamp, session_id, kind, name, agent_id, decision, advisory}` — 메시지 본문 필드 자체가 없음(설계적으로 미캡처). 로그 실측 7행도 동일.
- **파일 쓰기 표면**: 레지스트리는 `<root>/.moai/state/agent-stops/<session-id>.json` 세션 단일 경로, 감사로그는 고정 파일명. name/agent_id(공격자 영향 가능한 JSON 내용)는 파일 **내용**으로만 존재하고 경로 구성요소가 아님. 권한 0o600/0o750.

### Craft

- **커버리지 귀속**: base `c9eed8ac6` 대조측정(git archive + `go test -C`) → hook **84.7% → 85.1%**(이 카드가 85% 임계를 상회로 끌어올림), config **80.6% → 80.6%**(기존 baseline 불변 — 회귀 아님). base config 대조 중 `TestShippedConfigKeysHaveReaders`는 `git ls-files` 실패(아카이브≠git repo)로 환경적 FAIL — `-skip` 제외 후 측정.
- **테스트 품질**: 쌍방향 뮤턴트 고정(거부해야 할 방향 + 허용해야 할 방향 모두), live-shape 고정(`TestExtractTaskStopTargetLiveShape` + `TestAgentStopGuardLiveShapeLifecycle`, 서브테스트별 root 격리의 사유까지 주석화), nil-config/unwritable-root/idempotent upsert/부분제거 형제보존 등 예외 경형 포괄. 전 테스트 `t.TempDir()` 격리 준수.
- **config 스키마 범프**: `cache.go:25` `configCacheSchemaVersion` 1→2 — 필드 추가 자체가 호환성 파괴라는 근거가 상수 주석에 문서화, `cache.go:101,118`에서 버전 불일치→fail-open 재머지가 실제로 걸리며 `TestCache_SchemaVersionMismatchFailsOpen`이 수직 고정. 최소·주석화된 변경.
- **린트**: `golangci-lint run ./internal/hook/... ./internal/config/...` → `0 issues.` · spec lint(`moai spec lint <spec.md>`) → `✓ No findings`.

### Consistency

- **CHANGELOG ↔ 코드**: 기호 실재 확인 — `STOPPED_TEAMMATE_VIOLATION`(`agent_stop_guard.go:44`), `SendMessage|TaskStop` 매처 트윈 ×1/×1, `configCacheSchemaVersion=2`(`cache.go:25`), `.moai/state/agent-stops/`·`.moai/logs/agent-stop-audit.jsonl` 경로, `workflow.agent_stop_guard.enabled` 키, defaults.go 기본 false + 로컬 workflow.yaml dogfood true, "신규 훅 하위커맨드·래퍼 0", AC 11/11, 커밋 SHA 6개 전부 git log와 일치.
- **템플릿 중립성**(파이프 없는 직접 grep로 재측정 — 파이프 rc 오독 정정): settings.json.tmpl·rules 트윈에서 `SPEC-*`/`REQ-*` 토큰 0건, SHA·내부 날짜 0건. 템플릿 트리 내 `agent_stop_guard` 유일 언급은 rules 트윈의 "template default false" 문구(설명문, enable 아님). `internal/template/...` 스위트 `ok`(23.768s).
- **rules 트윈**: local↔template diff는 기존 의도적 Origin 라인(SPEC-CODEX-SESSION-MSG-001, 로컬 전용)만 잔존 — §E.4 주장과 일치. 적용된 수정문은 proposal §A.1과 본문 동일.
- **레시피**: `.moai/docs/agent-stop-audit-correlation.md` ≡ SPEC-dir 원본(헤더 배치 라인만 상이 — 리드 교정 #1 주장 확인). 실측 예시 재현: `git log --since='2026-08-26T17:12:48Z' --until='2026-08-26T17:13:21Z'` → 0커밋, `f7bd5bdc7`/`70541af5c`는 02:04/02:07 +09:00(창 개방 전) — 문서 기술 그대로.
- **종결 체인**: sync 커밋 `ea9b1f522`가 `status: in-progress → completed` + `updated` 전환을 실제로 반영, `90f7ad3e3`이 `sync_commit_sha: "ea9b1f522"` 백필(D3 self-referential-hazard 패턴). 3-phase close 관례 부합.

## 3. Baseline-attribution (baseline 귀속)

- 전 수치는 이번 실행, 이 트리(HEAD `c572fd8a9`, 코드 표면은 `90f7ad3e3`과 동일)에서 관측. 대조 baseline은 `c9eed8ac6`을 `/tmp` 추출하여 동일 명령으로 측정(hook 84.7% / config 80.6%-skip 1 git의존 테스트).
- 라이브 감사로그 7행은 워크트리 `.moai/logs/agent-stop-audit.jsonl`의 현재 내용을 그대로 판독한 것.

## 4. Gaps (명시적으로 관측하지 못한 것)

1. **"post-respawn send delivered AND acknowledged"** — 감사로그는 `send_observed … allowed`(17:13:27Z)까지 증명하며, 전달+수신확인 자체는 프로브 세션 트랜스크립트에만 존재(감사자 접근 불가). 리드 attestation으로 수용.
2. **lead-issued vs teammate-issued 구분** — 두 `send_denied` 행(17:12:53/17:13:10)은 로그상 형태가 동일하고 발신자 필드가 없어 어느 쪽이 티메이트 발신인지는 독립 검증 불가(거부 동작 자체는 동일하므로 무해). 리드 attestation으로 수용.
3. **`make build` 무디프 재생성** — 쓰기 연산이라 감사(읽기 전용)에서 미실행. 대신 `internal/template/...` 패리티 스위트 `ok`로 갈음.
4. **CI 전체 스위트 판정** — 브랜치 미푸시·PR 미생성(Route B, manager-git 잔여 — §E.4 close_statement가 스스로 명시). CI 근거는 현재 없음.

## 5. Residual-risk (관측 후에도 남는 위험)

1. **registry read-modify-write 무잠금**(`agent_stop_guard.go:147` 주석 명시) — 단일 세션 단일 리드 가정 하 설계. 동시 TaskStop이 극단적으로 겹치면 마지막 쓰기 승리(감사행은 각자 남음). 발생 시 유해도 낮음.
2. **`internal/cli/hook.go` 배선의 회귀 핀 부재** — F1(아래) 참조. 향후 리팩터링이 learning gate를 recorder 위로 되돌리면 learning-disabled 프로젝트에서 기록이 조용히 소멸하며, 이를 잡는 기계적 가드가 없음.
3. **config 패키지 커버리지 80.6%** — 기존 baseline이나(대조측정으로 회귀 아님 확인) 전역 85% 패키지 목표 미달 상태는 지속. 이 카드 소관 밖.
4. **session_id 경로 무살균**(F4) — 위협 모델상(로컬 런타임 생성 UUID) 비착지 가능이나 house pattern과 동일.

## Findings (구조화 결함 목록)

- **F1** [MINOR] [optional] `internal/cli/hook.go:726-734` — TaskStop dispatch + stdin 독해의 learning-gate-선배치에 cli 레이어 회귀 테스트 없음(internal/cli 테스트에서 `RecordAgentStop`/`TaskStop` 참조 0건). AC-TRG-010 라이브 증명은 1회성이며 내구 가드가 아님. 권장 수선: learning-disabled fixture + TaskStop stdin으로 `runHarnessObserve`를 호출해 레지스트리 행 기재를 단언하는 소형 단위 테스트 추가.
- **F2** [MINOR] [optional] `agent_stop_guard.go:299-331` + spec.md REQ-TRG-001 — REQ 문면("every TaskStop completion … exactly one event")은 구현("귀속 가능한 완료만 기록 — 빈 session id/대상 미해결/레지스트리 쓰기 실패 시 무기록")보다 넓게 읽힌다. 코드 주석이 축소를 명시하고 AC의 Given이 named target으로 한정되어 계약상 결함은 아니나, 차기 개정 시 REQ 문면을 "attributable"로 좁히는 것이 정직하다.
- **F3** [MINOR] [optional] `agent_stop_guard_test.go:396-420` — `TestAgentStopAuditRowShape`가 6필드 형상을 M1 종류만 검사; `session_cleared` 행의 6필드 존재는 구조체(omitempty 없음)로 구조적으로 보장되나 테스트 미단언. 1줄 확장으로 고정 가능.
- **F4** [LOW] [optional] `agent_stop_guard.go:122-124` — `agentStopRegistryPath`가 sessionID를 무살균 결합. 이론상 traversal 가능하나 sessionID는 로컬 런타임 생성 값이며 goal/context-usage 등 기존 세션-키 경로 패턴과 동일. 기록 전용.
- **F5** [INFO] 감사로그에 발신자(issuer) 필드 부재 — lead/teammate 발신 구분이 불가(§4 Gaps #2). 향후 필드 추가 후보, 결함 아님.
- **F6** [INFO] spec.md §5 "Out of Scope — Doctrine edits during plan-phase" 본문 말미 "it is not applied by this SPEC"과 sync 단계의 실제 적용(§E.4 `rules_amendment_application`) 사이 문장 긴장 — 적용 경로 자체는 proposal("orchestrator routes the amendment at sync")이 설계한 것이며 §E.4가 투명하게 기록하고 수정문은 proposal과 동일·중립이라 무결성 문제 없음. 문서 명료화 후보.
- **F7** [INFO] §E.2 cross-cutting note "Live tests wrote two audit rows" — 현재 로그는 7행(probe A 1 + probe B 6). 노트가 중간 시점 숫자로 스테일. 로그 자체가 SSOT라 무해.

## Recommendations

1. (F1) cli 레이어 회귀 핀 추가 — 다음 카드 또는 default-flip 검토 시점 전에.
2. (F5) 감사 레지스트리에 선택적 `issuer` 필드 추가 검토 — E4 패리티 주장의 사후 독립 검증 가능화.
3. default-flip 유지 판정(DO-NOT-FLIP)은 증거-게이트 조건 그대로 유지 — probe 규모 2회는 flip 트리거 요건(지속 dogfood)에 미달이라는 §B 판정이 정확하다.

---
분류: sync-phase 독립 감사 평정 (sync-auditor · 대화 언어 ko) · 근거 로그: 본 문서 §2 표 · 트리: `c572fd8a9`
