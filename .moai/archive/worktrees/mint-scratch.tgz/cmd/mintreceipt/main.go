// Command mintreceipt writes mission receipts through the real internal/mission
// writers so digest and mode semantics stay byte-exact with the supervisor's
// readers. Hash mode replicates cli autoGitSnapshotHash inputs.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/modu-ai/moai-adk/internal/mission"
)

func main() {
	kind := flag.String("kind", "", "decision|audit|lease|completion|hash")
	root := flag.String("root", ".", "project root for receipt writers")
	path := flag.String("path", "", "output receipt or lease path")
	missionID := flag.String("mission", "", "mission session id")
	contractHash := flag.String("contract", "", "sealed contract hash")
	snapshotHash := flag.String("snapshot", "", "snapshot hash")
	action := flag.String("action", "", "mission action string")
	targets := flag.String("targets", "", "comma-separated targets (hash mode: the single target)")
	headSHA := flag.String("head", "", "head SHA binding")
	issuer := flag.String("issuer", "", "receipt issuer")
	leaseBase := flag.String("lease-base", "", "integration lease base SHA")
	evidence := flag.String("evidence", "", "comma-separated key=true|false pairs")
	landed := flag.Bool("landed", false, "completion landed ancestry")
	repo := flag.String("repo", "", "hash mode: repository path")
	cardSHA := flag.String("card-sha", "", "hash mode: card SHA")
	flag.Parse()

	switch *kind {
	case "hash":
		resolved, err := filepath.EvalSymlinks(*repo)
		if err != nil {
			fail(err)
		}
		sum := sha256.Sum256([]byte(strings.Join([]string{
			*contractHash, *targets, *action, resolved, *headSHA, *cardSHA,
		}, "\x00")))
		fmt.Println(hex.EncodeToString(sum[:]))
	case "decision", "audit":
		r := mission.GovernanceReceipt{
			Version:      1,
			MissionID:    *missionID,
			ContractHash: *contractHash,
			SnapshotHash: *snapshotHash,
			Action:       mission.Action(*action),
			Targets:      strings.Split(*targets, ","),
			ExpiresAt:    time.Now().Add(time.Hour),
			Issuer:       *issuer,
			HeadSHA:      *headSHA,
		}
		if *kind == "decision" {
			r.Kind, r.Status = mission.GovernanceDecision, mission.GovernanceRecommended
		} else {
			r.Kind, r.Status = mission.GovernanceAudit, mission.GovernancePassed
		}
		fail(mission.WriteGovernanceReceipt(*root, *path, r))
		fmt.Println("minted", *path)
	case "lease":
		fail(mission.WriteIntegrationLease(*path, mission.IntegrationLease{
			SessionID: *missionID,
			BaseSHA:   *leaseBase,
		}))
		fmt.Println("minted", *path)
	case "completion":
		ev := map[string]bool{}
		for _, kv := range strings.Split(*evidence, ",") {
			p := strings.SplitN(kv, "=", 2)
			if len(p) == 2 {
				ev[p[0]] = p[1] == "true"
			}
		}
		fail(mission.WriteCompletionReceipt(*root, *path, mission.CompletionReceipt{
			Version:        1,
			MissionID:      *missionID,
			ContractHash:   *contractHash,
			SnapshotHash:   *snapshotHash,
			HeadSHA:        *headSHA,
			Issuer:         *issuer,
			Status:         "passed",
			Evidence:       ev,
			LandedAncestry: *landed,
			ExpiresAt:      time.Now().Add(time.Hour),
		}))
		fmt.Println("minted", *path)
	default:
		fail(fmt.Errorf("unknown kind %q", *kind))
	}
}

func fail(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "mintreceipt:", err)
		os.Exit(1)
	}
}
