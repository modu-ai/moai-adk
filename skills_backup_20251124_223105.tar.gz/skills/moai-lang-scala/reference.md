# moai-lang-scala - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Scala**: 3.6.0
- **ScalaTest**: 3.2.19
- **sbt**: 1.10.0

---

_For detailed usage, see SKILL.md_
