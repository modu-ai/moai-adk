# moai-docs-unified: Practical Examples

Unified documentation system examples.

---

## Example 1: Unified Documentation System

```python
from moai_docs.unified import UnifiedDocSystem

system = UnifiedDocSystem()
docs = system.generate_unified()
```

---

**Last Updated**: 2025-11-22
