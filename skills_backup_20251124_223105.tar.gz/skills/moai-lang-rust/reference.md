# moai-lang-rust - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Rust**: 1.84.0
- **cargo**: 1.84.0
- **clippy**: 1.84.0
- **rustfmt**: 1.84.0

---

_For detailed usage, see SKILL.md_
