---
name: moai-security-api-versioning
description: API versioning strategies for REST, GraphQL and gRPC with backward compatibility and deprecation management
version: 1.0.0
modularized: true
tags:
  - threat-modeling
  - enterprise
  - versioning
  - security
  - api
updated: 2025-11-24
status: active
---

## Quick Reference

[Quick reference content]

## When to Use

[When to use this skill]
