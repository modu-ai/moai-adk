---
name: command-name
description: Brief description of what the command does
argument-hint: "[param1] [param2]"
tools: Read, Write, Task
model: sonnet
---

# Command Title

Brief description of functionality.

## Usage

`/command-name param1 param2` — Basic usage

## Agent Orchestration

1. Call specific agent for task
2. Handle results
3. Provide user feedback
