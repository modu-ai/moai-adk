# moai-domain-devops - CLI Reference

_Last updated: 2025-10-22_

## Quick Reference

### Installation

```bash
# Installation commands
```

### Common Commands

```bash
# Test
# Lint
# Format
# Build
```

## Tool Versions (2025-10-22)

- **Docker**: 27.4.0
- **Kubernetes**: 1.32.0
- **Terraform**: 1.10.0
- **GitHub Actions**: latest

---

_For detailed usage, see SKILL.md_
