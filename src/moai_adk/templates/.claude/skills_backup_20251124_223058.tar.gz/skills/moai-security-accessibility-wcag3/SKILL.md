---
name: moai-security-accessibility-wcag3
description: WCAG 3.0 accessibility compliance validation using axe-core, Pa11y and automated A11y testing
version: 1.0.0
modularized: true
tags:
  - threat-modeling
  - enterprise
  - security
  - accessibility
  - wcag3
updated: 2025-11-24
status: active
---

## Quick Reference

[Quick reference content]

## When to Use

[When to use this skill]
